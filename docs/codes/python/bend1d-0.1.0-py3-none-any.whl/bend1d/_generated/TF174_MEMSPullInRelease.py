# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF174_MEMSPullInRelease(N=None,pullAmp=None,relCenter=None,relWidth=None,oscAmp=None,oscFreq=None,*args,**kwargs):
    varargin = TF174_MEMSPullInRelease.varargin
    nargin = TF174_MEMSPullInRelease.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:2
    
    if nargin < 2 or isempty(pullAmp):
        pullAmp=0.56
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:3
    
    if nargin < 3 or isempty(relCenter):
        relCenter=0.42
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:4
    
    if nargin < 4 or isempty(relWidth):
        relWidth=0.28
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:5
    
    if nargin < 5 or isempty(oscAmp):
        oscAmp=0.15
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:6
    
    if nargin < 6 or isempty(oscFreq):
        oscFreq=34
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:8
    f=zeros(size(x))
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:9
    m1=x < relCenter
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:10
    m2=logical_and((x >= relCenter),(x < (relCenter + relWidth)))
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:11
    m3=x >= (relCenter + relWidth)
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:12
    u=x(m1) / relCenter
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:13
    f[m1]=0.06 + dot(pullAmp,u ** 2) + dot(0.12,u ** 5)
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:14
    f[m2]=0.98 + dot(0.025,sin(dot(dot(dot(2,pi),2),(x(m2) - relCenter)) / relWidth))
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:15
    u=x(m3) - (relCenter + relWidth)
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:16
    f[m3]=dot(0.24,(1 - (x(m3) - (relCenter + relWidth)) / 0.3)) + 0.05 + multiply(dot(oscAmp,exp(dot(- 16,u))),sin(dot(dot(dot(2,pi),oscFreq),u)))
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:18
    meta.ID = copy('TF174')
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:19
    meta.Name = copy('MEMS Pull-in/Release')
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:20
    meta.Category = copy(9)
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:22
    meta.Parameters = copy(struct('pullAmp',pullAmp,'relCenter',relCenter,'relWidth',relWidth,'oscAmp',oscAmp,'oscFreq',oscFreq))
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:23
    meta.Morphology = copy('Nonlinear pull-in and release with oscillatory decay')
# /tmp/mfuncs/TF174_MEMSPullInRelease.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    