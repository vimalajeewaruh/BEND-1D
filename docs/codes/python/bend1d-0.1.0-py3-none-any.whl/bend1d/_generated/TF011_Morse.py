# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF011_Morse(N=None,De=None,aMorse=None,re=None,*args,**kwargs):
    varargin = TF011_Morse.varargin
    nargin = TF011_Morse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF011_Morse.m:2
    
    if nargin < 2 or isempty(De):
        De=1.0
# /tmp/mfuncs/TF011_Morse.m:3
    
    if nargin < 3 or isempty(aMorse):
        aMorse=2.8
# /tmp/mfuncs/TF011_Morse.m:4
    
    if nargin < 4 or isempty(re):
        re=0.8
# /tmp/mfuncs/TF011_Morse.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF011_Morse.m:6
    r=0.35 + dot(2.0,x)
# /tmp/mfuncs/TF011_Morse.m:7
    f=dot(De,(1 - exp(dot(- aMorse,(r - re)))) ** 2) - De
# /tmp/mfuncs/TF011_Morse.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF011_Morse.m:9
    meta.ID = copy('TF011')
# /tmp/mfuncs/TF011_Morse.m:10
    meta.Name = copy('Morse')
# /tmp/mfuncs/TF011_Morse.m:11
    meta.Category = copy(10)
# /tmp/mfuncs/TF011_Morse.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF011_Morse.m:13
    meta.Parameters = copy(struct('De',De,'aMorse',aMorse,'re',re))
# /tmp/mfuncs/TF011_Morse.m:14
    meta.Morphology = copy('Diatomic bond potential with exponential approach')
# /tmp/mfuncs/TF011_Morse.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    