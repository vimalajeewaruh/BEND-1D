# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF201_CGMMealStack(N=None,baseSin=None,centers=None,amps=None,tau=None,*args,**kwargs):
    varargin = TF201_CGMMealStack.varargin
    nargin = TF201_CGMMealStack.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF201_CGMMealStack.m:2
    
    if nargin < 2 or isempty(baseSin):
        baseSin=0.2
# /tmp/mfuncs/TF201_CGMMealStack.m:3
    
    if nargin < 3 or isempty(centers):
        centers=concat([0.16,0.36,0.54,0.69])
# /tmp/mfuncs/TF201_CGMMealStack.m:4
    
    if nargin < 4 or isempty(amps):
        amps=concat([0.48,0.62,0.45,0.7])
# /tmp/mfuncs/TF201_CGMMealStack.m:5
    
    if nargin < 5 or isempty(tau):
        tau=concat([0.075,0.095,0.08,0.11])
# /tmp/mfuncs/TF201_CGMMealStack.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF201_CGMMealStack.m:7
    f=baseSin + dot(0.03,sin(dot(dot(2,pi),x)))
# /tmp/mfuncs/TF201_CGMMealStack.m:8
    for k in arange(1,numel(centers)).reshape(-1):
        u=max(x - centers(k),0)
# /tmp/mfuncs/TF201_CGMMealStack.m:10
        resp=multiply(multiply((x >= centers(k)),(u / tau(k))),exp(1 - u / tau(k)))
# /tmp/mfuncs/TF201_CGMMealStack.m:11
        f=f + dot(amps(k),resp)
# /tmp/mfuncs/TF201_CGMMealStack.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF201_CGMMealStack.m:14
    meta.ID = copy('TF201')
# /tmp/mfuncs/TF201_CGMMealStack.m:15
    meta.Name = copy('CGM Meal Stack')
# /tmp/mfuncs/TF201_CGMMealStack.m:16
    meta.Category = copy(10)
# /tmp/mfuncs/TF201_CGMMealStack.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF201_CGMMealStack.m:18
    meta.Parameters = copy(struct('baseSin',baseSin,'centers',centers,'amps',amps,'tau',tau))
# /tmp/mfuncs/TF201_CGMMealStack.m:19
    meta.Morphology = copy('Stacked meal responses with gamma-like shape')
# /tmp/mfuncs/TF201_CGMMealStack.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    