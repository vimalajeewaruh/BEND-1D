# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF131_EEGSeizureOnset(N=None,backgroundFreqs=None,backgroundAmps=None,seizureEnvCtr=None,seizureEnvW=None,seizureAmp=None,seizurePhaseCoeff=None,spikeCtr=None,spikeAmp=None,postSuppressionCtr=None,postSuppressionW=None,postSuppressionAmp=None,*args,**kwargs):
    varargin = TF131_EEGSeizureOnset.varargin
    nargin = TF131_EEGSeizureOnset.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:2
    
    if nargin < 2 or isempty(backgroundFreqs):
        backgroundFreqs=concat([5,9])
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:3
    
    if nargin < 3 or isempty(backgroundAmps):
        backgroundAmps=concat([0.035,0.018])
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:4
    
    if nargin < 4 or isempty(seizureEnvCtr):
        seizureEnvCtr=0.62
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:5
    
    if nargin < 5 or isempty(seizureEnvW):
        seizureEnvW=0.05
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:6
    
    if nargin < 6 or isempty(seizureAmp):
        seizureAmp=0.38
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:7
    
    if nargin < 7 or isempty(seizurePhaseCoeff):
        seizurePhaseCoeff=concat([12,12])
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:8
    
    if nargin < 8 or isempty(spikeCtr):
        spikeCtr=0.36
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:9
    
    if nargin < 9 or isempty(spikeAmp):
        spikeAmp=0.18
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:10
    
    if nargin < 10 or isempty(postSuppressionCtr):
        postSuppressionCtr=0.82
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:11
    
    if nargin < 11 or isempty(postSuppressionW):
        postSuppressionW=0.03
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:12
    
    if nargin < 12 or isempty(postSuppressionAmp):
        postSuppressionAmp=0.06
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:15
    backgroundES=dot(backgroundAmps(1),sin(dot(dot(dot(2,pi),backgroundFreqs(1)),x))) + dot(backgroundAmps(2),sin(dot(dot(dot(2,pi),backgroundFreqs(2)),x) + 0.6))
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:16
    envES=S(x,seizureEnvCtr,seizureEnvW) - S(x,postSuppressionCtr,postSuppressionW)
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:17
    phaseES=dot(dot(2,pi),(dot(seizurePhaseCoeff(1),x) + dot(seizurePhaseCoeff(2),x ** 2)))
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:18
    f=backgroundES + multiply(dot(seizureAmp,envES),sin(phaseES)) + dot(spikeAmp,exp(dot(- 0.5,((x - spikeCtr) / 0.008) ** 2))) - dot(postSuppressionAmp,S(x,postSuppressionCtr,postSuppressionW))
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:20
    meta.ID = copy('TF131')
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:21
    meta.Name = copy('EEG Seizure Onset')
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:22
    meta.Category = copy(9)
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:25
    meta.Morphology = copy('Low-frequency background with localized high‑frequency seizure onset and transient spike')
# /tmp/mfuncs/TF131_EEGSeizureOnset.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    