# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF153_SymmetryBreak(N=None,mainAmp=None,mainCtr=None,mainWid=None,cosAmp=None,cosFreq=None,pertAmp=None,pertCtr=None,pertWid=None,*args,**kwargs):
    varargin = TF153_SymmetryBreak.varargin
    nargin = TF153_SymmetryBreak.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF153_SymmetryBreak.m:2
    
    if nargin < 2 or isempty(mainAmp):
        mainAmp=0.58
# /tmp/mfuncs/TF153_SymmetryBreak.m:3
    
    if nargin < 3 or isempty(mainCtr):
        mainCtr=0.5
# /tmp/mfuncs/TF153_SymmetryBreak.m:4
    
    if nargin < 4 or isempty(mainWid):
        mainWid=0.18
# /tmp/mfuncs/TF153_SymmetryBreak.m:5
    
    if nargin < 5 or isempty(cosAmp):
        cosAmp=0.15
# /tmp/mfuncs/TF153_SymmetryBreak.m:6
    
    if nargin < 6 or isempty(cosFreq):
        cosFreq=4
# /tmp/mfuncs/TF153_SymmetryBreak.m:7
    
    if nargin < 7 or isempty(pertAmp):
        pertAmp=0.055
# /tmp/mfuncs/TF153_SymmetryBreak.m:8
    
    if nargin < 8 or isempty(pertCtr):
        pertCtr=0.635
# /tmp/mfuncs/TF153_SymmetryBreak.m:9
    
    if nargin < 9 or isempty(pertWid):
        pertWid=0.009
# /tmp/mfuncs/TF153_SymmetryBreak.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF153_SymmetryBreak.m:12
    f=dot(mainAmp,exp(dot(- 0.5,((x - mainCtr) / mainWid) ** 2))) + dot(cosAmp,cos(dot(dot(dot(2,pi),cosFreq),(x - mainCtr)))) + dot(pertAmp,exp(dot(- 0.5,((x - pertCtr) / pertWid) ** 2)))
# /tmp/mfuncs/TF153_SymmetryBreak.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF153_SymmetryBreak.m:14
    meta.ID = copy('TF153')
# /tmp/mfuncs/TF153_SymmetryBreak.m:15
    meta.Name = copy('Symmetry Break')
# /tmp/mfuncs/TF153_SymmetryBreak.m:16
    meta.Category = copy(9)
# /tmp/mfuncs/TF153_SymmetryBreak.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF153_SymmetryBreak.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF153_SymmetryBreak.m:19
    meta.Morphology = copy('Nearly symmetric bump with a small asymmetric perturbation')
# /tmp/mfuncs/TF153_SymmetryBreak.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    