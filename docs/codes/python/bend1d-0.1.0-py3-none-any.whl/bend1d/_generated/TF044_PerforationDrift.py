# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF044_PerforationDrift(N=None,offset=None,slope=None,a1=None,f1=None,a2=None,f2=None,bad_amp=None,bad_ctr=None,bad_w=None,bad2_amp=None,bad2_ctr=None,bad2_w=None,*args,**kwargs):
    varargin = TF044_PerforationDrift.varargin
    nargin = TF044_PerforationDrift.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF044_PerforationDrift.m:2
    
    if nargin < 2 or isempty(offset):
        offset=1.0
# /tmp/mfuncs/TF044_PerforationDrift.m:3
    
    if nargin < 3 or isempty(slope):
        slope=0.055
# /tmp/mfuncs/TF044_PerforationDrift.m:4
    
    if nargin < 4 or isempty(a1):
        a1=0.03
# /tmp/mfuncs/TF044_PerforationDrift.m:5
    
    if nargin < 5 or isempty(f1):
        f1=8
# /tmp/mfuncs/TF044_PerforationDrift.m:6
    
    if nargin < 6 or isempty(a2):
        a2=0.012
# /tmp/mfuncs/TF044_PerforationDrift.m:7
    
    if nargin < 7 or isempty(f2):
        f2=31
# /tmp/mfuncs/TF044_PerforationDrift.m:8
    
    if nargin < 8 or isempty(bad_amp):
        bad_amp=0.18
# /tmp/mfuncs/TF044_PerforationDrift.m:9
    
    if nargin < 9 or isempty(bad_ctr):
        bad_ctr=0.63
# /tmp/mfuncs/TF044_PerforationDrift.m:10
    
    if nargin < 10 or isempty(bad_w):
        bad_w=0.007
# /tmp/mfuncs/TF044_PerforationDrift.m:11
    
    if nargin < 11 or isempty(bad2_amp):
        bad2_amp=- 0.1
# /tmp/mfuncs/TF044_PerforationDrift.m:12
    
    if nargin < 12 or isempty(bad2_ctr):
        bad2_ctr=0.648
# /tmp/mfuncs/TF044_PerforationDrift.m:13
    
    if nargin < 13 or isempty(bad2_w):
        bad2_w=0.005
# /tmp/mfuncs/TF044_PerforationDrift.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF044_PerforationDrift.m:16
    f=offset + dot(slope,(x - 0.5)) + dot(a1,sin(dot(dot(dot(2,pi),f1),x))) + dot(a2,sin(dot(dot(dot(2,pi),f2),x) + 0.4))
# /tmp/mfuncs/TF044_PerforationDrift.m:17
    f=f + dot(bad_amp,exp(dot(- 0.5,((x - bad_ctr) / bad_w) ** 2))) + dot(bad2_amp,exp(dot(- 0.5,((x - bad2_ctr) / bad2_w) ** 2)))
# /tmp/mfuncs/TF044_PerforationDrift.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF044_PerforationDrift.m:19
    meta.ID = copy('TF044')
# /tmp/mfuncs/TF044_PerforationDrift.m:20
    meta.Name = copy('Perforation Drift')
# /tmp/mfuncs/TF044_PerforationDrift.m:21
    meta.Category = copy(4)
# /tmp/mfuncs/TF044_PerforationDrift.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF044_PerforationDrift.m:23
    meta.Parameters = copy(struct('offset',offset,'slope',slope,'a1',a1,'f1',f1,'a2',a2,'f2',f2,'bad_amp',bad_amp,'bad_ctr',bad_ctr,'bad_w',bad_w,'bad2_amp',bad2_amp,'bad2_ctr',bad2_ctr,'bad2_w',bad2_w))
# /tmp/mfuncs/TF044_PerforationDrift.m:24
    meta.Morphology = copy('Nominal pitch with slow drift, periodic eccentricity and a bad pin')
# /tmp/mfuncs/TF044_PerforationDrift.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    