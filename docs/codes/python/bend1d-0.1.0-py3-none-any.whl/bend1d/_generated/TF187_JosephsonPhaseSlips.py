# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF187_JosephsonPhaseSlips(N=None,baseFreq=None,slipPhases=None,slipLocations=None,*args,**kwargs):
    varargin = TF187_JosephsonPhaseSlips.varargin
    nargin = TF187_JosephsonPhaseSlips.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:2
    
    if nargin < 2 or isempty(baseFreq):
        baseFreq=12
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:3
    
    if nargin < 3 or isempty(slipPhases):
        slipPhases=concat([dot(0.75,pi),dot(- 1.05,pi),dot(0.6,pi)])
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:4
    
    if nargin < 4 or isempty(slipLocations):
        slipLocations=concat([0.28,0.53,0.78])
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:6
    phi=dot(dot(dot(2,pi),baseFreq),x)
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:7
    for k in arange(1,numel(slipLocations)).reshape(-1):
        phi=phi + dot(slipPhases(k),double(x >= slipLocations(k)))
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:9
    
    f=dot(0.75,sin(phi)) + dot(0.12,sin(dot(2,phi) + 0.4))
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:11
    meta=copy(struct)
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:12
    meta.ID = copy('TF187')
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:13
    meta.Name = copy('Josephson Phase Slips')
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:14
    meta.Category = copy(10)
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:16
    meta.Parameters = copy(struct('baseFreq',baseFreq,'slipPhases',slipPhases,'slipLocations',slipLocations))
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:17
    meta.Morphology = copy('Discrete phase slips producing harmonic content')
# /tmp/mfuncs/TF187_JosephsonPhaseSlips.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    