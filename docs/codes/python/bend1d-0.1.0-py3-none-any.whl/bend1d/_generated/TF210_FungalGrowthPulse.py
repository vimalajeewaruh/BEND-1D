# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF210_FungalGrowthPulse(N=None,*args,**kwargs):
    varargin = TF210_FungalGrowthPulse.varargin
    nargin = TF210_FungalGrowthPulse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:3
    f=0.06 + dot(0.12,x) + dot(0.19,S(x,0.19,0.035)) + dot(0.15,S(x,0.39,0.018)) + dot(0.27,S(x,0.63,0.05)) + dot(0.12,S(x,0.84,0.02))
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:4
    f=f + multiply(dot(0.018,sin(dot(dot(dot(2,pi),9),x))),(S(x,0.17,0.03) - S(x,0.88,0.03)))
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:8
    meta.ID = copy('TF210')
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:9
    meta.Name = copy('Fungal Growth Pulses')
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:10
    meta.Category = copy(10)
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:11
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:12
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:13
    meta.Morphology = copy('Pulsed growth responses with gated higher-frequency ripples')
# /tmp/mfuncs/TF210_FungalGrowthPulse.m:14
    return x,f,meta
    
if __name__ == '__main__':
    pass
    