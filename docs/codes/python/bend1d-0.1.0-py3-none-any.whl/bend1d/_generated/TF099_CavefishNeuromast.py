# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF099_CavefishNeuromast(N=None,baseAmp=None,baseOscFreq=None,onC=None,onW=None,onAmp=None,susC=None,susW=None,adaptAmp=None,adaptRate=None,secAmp=None,off1Amp=None,off1W=None,off2Amp=None,off2W=None,*args,**kwargs):
    varargin = TF099_CavefishNeuromast.varargin
    nargin = TF099_CavefishNeuromast.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF099_CavefishNeuromast.m:2
    
    if nargin < 2 or isempty(baseAmp):
        baseAmp=0.1
# /tmp/mfuncs/TF099_CavefishNeuromast.m:3
    
    if nargin < 3 or isempty(baseOscFreq):
        baseOscFreq=4
# /tmp/mfuncs/TF099_CavefishNeuromast.m:4
    
    if nargin < 4 or isempty(onC):
        onC=0.3
# /tmp/mfuncs/TF099_CavefishNeuromast.m:5
    
    if nargin < 5 or isempty(onW):
        onW=0.012
# /tmp/mfuncs/TF099_CavefishNeuromast.m:6
    
    if nargin < 6 or isempty(onAmp):
        onAmp=0.62
# /tmp/mfuncs/TF099_CavefishNeuromast.m:7
    
    if nargin < 7 or isempty(susC):
        susC=0.31
# /tmp/mfuncs/TF099_CavefishNeuromast.m:8
    
    if nargin < 8 or isempty(susW):
        susW=0.01
# /tmp/mfuncs/TF099_CavefishNeuromast.m:9
    
    if nargin < 9 or isempty(adaptAmp):
        adaptAmp=- 0.12
# /tmp/mfuncs/TF099_CavefishNeuromast.m:10
    
    if nargin < 10 or isempty(adaptRate):
        adaptRate=6
# /tmp/mfuncs/TF099_CavefishNeuromast.m:11
    
    if nargin < 11 or isempty(secAmp):
        secAmp=0.16
# /tmp/mfuncs/TF099_CavefishNeuromast.m:12
    
    if nargin < 12 or isempty(off1Amp):
        off1Amp=- 0.18
# /tmp/mfuncs/TF099_CavefishNeuromast.m:13
    
    if nargin < 13 or isempty(off1W):
        off1W=0.016
# /tmp/mfuncs/TF099_CavefishNeuromast.m:14
    
    if nargin < 14 or isempty(off2Amp):
        off2Amp=0.1
# /tmp/mfuncs/TF099_CavefishNeuromast.m:15
    
    if nargin < 15 or isempty(off2W):
        off2W=0.025
# /tmp/mfuncs/TF099_CavefishNeuromast.m:16
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF099_CavefishNeuromast.m:18
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:19
    base=baseAmp + dot(0.018,sin(dot(dot(dot(2,pi),baseOscFreq),x)))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:20
    on=dot(onAmp,exp(dot(- 0.5,((x - onC) / onW) ** 2)))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:21
    sustained=dot(0.3,(sigmoid(x,susC,susW) - sigmoid(x,0.69,0.018)))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:22
    adapt=multiply(dot(adaptAmp,(1 - exp(dot(- adaptRate,max(x - 0.33,0))))),(logical_and((x >= 0.33),(x < 0.69))))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:23
    secondary=dot(secAmp,exp(dot(- 0.5,((x - 0.52) / 0.025) ** 2)))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:24
    off=dot(off1Amp,exp(dot(- 0.5,((x - 0.71) / off1W) ** 2))) + dot(off2Amp,exp(dot(- 0.5,((x - 0.755) / off2W) ** 2)))
# /tmp/mfuncs/TF099_CavefishNeuromast.m:25
    f=base + on + sustained + adapt + secondary + off
# /tmp/mfuncs/TF099_CavefishNeuromast.m:26
    meta=copy(struct)
# /tmp/mfuncs/TF099_CavefishNeuromast.m:27
    meta.ID = copy('TF099')
# /tmp/mfuncs/TF099_CavefishNeuromast.m:28
    meta.Name = copy('Cavefish Neuromast')
# /tmp/mfuncs/TF099_CavefishNeuromast.m:29
    meta.Category = copy(6)
# /tmp/mfuncs/TF099_CavefishNeuromast.m:30
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF099_CavefishNeuromast.m:31
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF099_CavefishNeuromast.m:32
    meta.Morphology = copy('On response, sustained plateau, adaptation and off features')
# /tmp/mfuncs/TF099_CavefishNeuromast.m:33
    return x,f,meta
    
if __name__ == '__main__':
    pass
    