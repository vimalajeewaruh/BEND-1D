# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF180_HolderLadder(N=None,cHL=None,alphaHL=None,wHL=None,ampHL=None,*args,**kwargs):
    varargin = TF180_HolderLadder.varargin
    nargin = TF180_HolderLadder.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF180_HolderLadder.m:2
    
    if nargin < 2 or isempty(cHL):
        cHL=concat([0.1,0.29,0.49,0.69,0.89])
# /tmp/mfuncs/TF180_HolderLadder.m:3
    
    if nargin < 3 or isempty(alphaHL):
        alphaHL=concat([0.25,0.5,1.0,1.5,2.5])
# /tmp/mfuncs/TF180_HolderLadder.m:4
    
    if nargin < 4 or isempty(wHL):
        wHL=0.04
# /tmp/mfuncs/TF180_HolderLadder.m:5
    
    if nargin < 5 or isempty(ampHL):
        ampHL=0.42
# /tmp/mfuncs/TF180_HolderLadder.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF180_HolderLadder.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF180_HolderLadder.m:8
    for k in arange(1,numel(cHL)).reshape(-1):
        z=(x - cHL(k)) / wHL
# /tmp/mfuncs/TF180_HolderLadder.m:10
        phi=multiply(exp(dot(- 0.5,z ** 2)),(1 - dot(0.62,abs(z) ** alphaHL(k))))
# /tmp/mfuncs/TF180_HolderLadder.m:11
        phi=phi / max(abs(phi))
# /tmp/mfuncs/TF180_HolderLadder.m:12
        f=f + dot(ampHL,phi)
# /tmp/mfuncs/TF180_HolderLadder.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF180_HolderLadder.m:15
    meta.ID = copy('TF180')
# /tmp/mfuncs/TF180_HolderLadder.m:16
    meta.Name = copy('Holder Ladder')
# /tmp/mfuncs/TF180_HolderLadder.m:17
    meta.Category = copy(9)
# /tmp/mfuncs/TF180_HolderLadder.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF180_HolderLadder.m:19
    meta.Parameters = copy(struct('centers',cHL,'alpha',alphaHL,'width',wHL,'amp',ampHL))
# /tmp/mfuncs/TF180_HolderLadder.m:20
    meta.Morphology = copy('Summed localized Holder-like pulses with varying regularity')
# /tmp/mfuncs/TF180_HolderLadder.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 10: 181- 230
    