# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF030_CheyneStokes(N=None,episode=None,phaseCoef=None,*args,**kwargs):
    varargin = TF030_CheyneStokes.varargin
    nargin = TF030_CheyneStokes.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF030_CheyneStokes.m:2
    
    if nargin < 2 or isempty(episode):
        episode=concat([[0.0,0.26],[0.34,0.6],[0.68,0.94]])
# /tmp/mfuncs/TF030_CheyneStokes.m:3
    
    if nargin < 3 or isempty(phaseCoef):
        phaseCoef=struct('a',12,'b',0.55)
# /tmp/mfuncs/TF030_CheyneStokes.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF030_CheyneStokes.m:5
    env=zeros(size(x))
# /tmp/mfuncs/TF030_CheyneStokes.m:6
    for k in arange(1,size(episode,1)).reshape(-1):
        a0=episode(k,1)
# /tmp/mfuncs/TF030_CheyneStokes.m:8
        b0=episode(k,2)
# /tmp/mfuncs/TF030_CheyneStokes.m:8
        ind=logical_and((x >= a0),(x <= b0))
# /tmp/mfuncs/TF030_CheyneStokes.m:9
        u=(x(ind) - a0) / (b0 - a0)
# /tmp/mfuncs/TF030_CheyneStokes.m:10
        env[ind]=sin(dot(pi,u)) ** 1.65
# /tmp/mfuncs/TF030_CheyneStokes.m:11
    
    phaseCS=dot(dot(2,pi),(dot(phaseCoef.a,x) + dot(phaseCoef.b,x ** 2)))
# /tmp/mfuncs/TF030_CheyneStokes.m:13
    f=multiply(env,(sin(phaseCS) + dot(0.13,sin(dot(2,phaseCS) - 0.35))))
# /tmp/mfuncs/TF030_CheyneStokes.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF030_CheyneStokes.m:15
    meta.ID = copy('TF030')
# /tmp/mfuncs/TF030_CheyneStokes.m:16
    meta.Name = copy('Cheyne-Stokes Respiration')
# /tmp/mfuncs/TF030_CheyneStokes.m:17
    meta.Category = copy(3)
# /tmp/mfuncs/TF030_CheyneStokes.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF030_CheyneStokes.m:19
    meta.Parameters = copy(struct('episode',episode,'phaseCoef',phaseCoef))
# /tmp/mfuncs/TF030_CheyneStokes.m:20
    meta.Morphology = copy('Crescendo-decrescendo breathing episodes separated by apnea')
# /tmp/mfuncs/TF030_CheyneStokes.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
