# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF074_RadarMicroDoppler(N=None,phase_a=None,phase_b=None,phase_c=None,env_lo=None,env_hi=None,env_ctr=None,env_w=None,side_amp=None,side_fm=None,side_modf=None,*args,**kwargs):
    varargin = TF074_RadarMicroDoppler.varargin
    nargin = TF074_RadarMicroDoppler.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:2
    
    if nargin < 2 or isempty(phase_a):
        phase_a=12
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:3
    
    if nargin < 3 or isempty(phase_b):
        phase_b=24
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:4
    
    if nargin < 4 or isempty(phase_c):
        phase_c=0.5
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:5
    
    if nargin < 5 or isempty(env_lo):
        env_lo=0.32
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:6
    
    if nargin < 6 or isempty(env_hi):
        env_hi=0.68
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:7
    
    if nargin < 7 or isempty(env_ctr):
        env_ctr=0.58
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:8
    
    if nargin < 8 or isempty(env_w):
        env_w=0.3
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:9
    
    if nargin < 9 or isempty(side_amp):
        side_amp=0.16
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:10
    
    if nargin < 10 or isempty(side_fm):
        side_fm=62
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:11
    
    if nargin < 11 or isempty(side_modf):
        side_modf=3
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:14
    phaseRM=dot(dot(2,pi),(dot(phase_a,x) + dot(phase_b,x ** 2) + dot(phase_c,sin(dot(dot(dot(2,pi),3),x)))))
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:15
    envRM=env_lo + dot(env_hi,exp(dot(- 0.5,((x - env_ctr) / env_w) ** 2)))
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:16
    sideRM=dot(side_amp,sin(dot(dot(2,pi),(dot(side_fm,x) + dot(side_modf,sin(dot(dot(dot(2,pi),2),x)))))))
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:17
    f=multiply(envRM,sin(phaseRM)) + sideRM
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:19
    meta.ID = copy('TF074')
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:20
    meta.Name = copy('Radar Micro-Doppler')
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:21
    meta.Category = copy(6)
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:24
    meta.Morphology = copy('Time-varying phase with envelope and sideband modulation')
# /tmp/mfuncs/TF074_RadarMicroDoppler.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    