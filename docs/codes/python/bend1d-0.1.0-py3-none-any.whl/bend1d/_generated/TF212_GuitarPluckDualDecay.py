# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF212_GuitarPluckDualDecay(N=None,u0=None,gateCenter=None,gateWidth=None,*args,**kwargs):
    varargin = TF212_GuitarPluckDualDecay.varargin
    nargin = TF212_GuitarPluckDualDecay.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:2
    
    if nargin < 2 or isempty(u0):
        u0=0.045
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:3
    
    if nargin < 3 or isempty(gateCenter):
        gateCenter=0.045
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:4
    
    if nargin < 4 or isempty(gateWidth):
        gateWidth=0.002
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:6
    u=max(x - u0,0)
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:7
    gate=S(x,gateCenter,gateWidth)
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:8
    f=multiply(gate,(multiply(dot(0.72,exp(dot(- 1.8,u))),sin(dot(dot(dot(2,pi),6.5),u))) + multiply(dot(0.32,exp(dot(- 5.5,u))),sin(dot(dot(dot(2,pi),13),u) + 0.2)) + multiply(dot(0.22,exp(dot(- 8.0,u))),sin(dot(dot(dot(2,pi),19.5),u) + 0.5)) + multiply(dot(0.12,exp(dot(- 11,u))),sin(dot(dot(dot(2,pi),32.5),u)))))
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:14
    meta.ID = copy('TF212')
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:15
    meta.Name = copy('Guitar Pluck Dual Decay')
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:16
    meta.Category = copy(11)
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:18
    meta.Parameters = copy(struct('u0',u0,'gateCenter',gateCenter,'gateWidth',gateWidth))
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:19
    meta.Morphology = copy('Dual-decay pluck with multiple partials')
# /tmp/mfuncs/TF212_GuitarPluckDualDecay.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    