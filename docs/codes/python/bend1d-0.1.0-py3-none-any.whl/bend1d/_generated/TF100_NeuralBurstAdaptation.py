# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF100_NeuralBurstAdaptation(N=None,slowBase=None,slowFreq=None,c=None,a_base=None,widthBase=None,oscBase=None,oscRate=None,sigC=None,sigW=None,*args,**kwargs):
    varargin = TF100_NeuralBurstAdaptation.varargin
    nargin = TF100_NeuralBurstAdaptation.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:2
    
    if nargin < 2 or isempty(slowBase):
        slowBase=0.08
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:3
    
    if nargin < 3 or isempty(slowFreq):
        slowFreq=1.8
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:4
    
    if nargin < 4 or isempty(c):
        c=concat([0.12,0.24,0.355,0.465,0.57,0.67,0.765,0.855,0.935])
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:5
    
    if nargin < 5 or isempty(a_base):
        a_base=concat([0.7,0.64,0.58,0.54,0.49,0.45,0.42,0.39,0.36])
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:6
    
    if nargin < 6 or isempty(widthBase):
        widthBase=0.01
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:7
    
    if nargin < 7 or isempty(oscBase):
        oscBase=0.6
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:8
    
    if nargin < 8 or isempty(oscRate):
        oscRate=72
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:9
    
    if nargin < 9 or isempty(sigC):
        sigC=0.52
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:10
    
    if nargin < 10 or isempty(sigW):
        sigW=0.12
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:13
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:14
    slow=slowBase + dot(0.035,sin(dot(dot(dot(2,pi),slowFreq),x)))
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:15
    f=copy(slow)
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:16
    for k in arange(1,numel(c)).reshape(-1):
        width=widthBase + dot(0.0025,k)
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:18
        env=exp(dot(- 0.5,((x - c(k)) / width) ** 2))
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:19
        localOsc=dot(oscBase,sin(dot(dot(2,pi),(dot(oscRate,x) + dot(0.8,k)))))
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:20
        f=f + multiply(dot(a_base(k),env),(0.75 + dot(0.25,localOsc)))
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:21
    
    f=f - dot(0.1,sigmoid(x,sigC,sigW))
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:24
    meta.ID = copy('TF100')
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:25
    meta.Name = copy('Neural Burst Adaptation')
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:26
    meta.Category = copy(6)
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:28
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:29
    meta.Morphology = copy('Bursting events with adaptation and baseline oscillation')
# /tmp/mfuncs/TF100_NeuralBurstAdaptation.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 7: 101 - 125
    