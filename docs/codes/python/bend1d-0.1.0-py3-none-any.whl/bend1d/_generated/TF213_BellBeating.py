# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF213_BellBeating(N=None,decay1=None,decay2=None,amp2=None,*args,**kwargs):
    varargin = TF213_BellBeating.varargin
    nargin = TF213_BellBeating.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF213_BellBeating.m:2
    
    if nargin < 2 or isempty(decay1):
        decay1=2.3
# /tmp/mfuncs/TF213_BellBeating.m:3
    
    if nargin < 3 or isempty(decay2):
        decay2=6.9
# /tmp/mfuncs/TF213_BellBeating.m:4
    
    if nargin < 4 or isempty(amp2):
        amp2=0.35
# /tmp/mfuncs/TF213_BellBeating.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF213_BellBeating.m:6
    f=multiply(exp(dot(- decay1,x)),(sin(dot(dot(dot(2,pi),11),x)) + dot(0.92,sin(dot(dot(dot(2,pi),11.75),x) + 0.12)))) + multiply(dot(amp2,exp(dot(- decay2,x))),sin(dot(dot(dot(2,pi),27.3),x) + 0.5))
# /tmp/mfuncs/TF213_BellBeating.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF213_BellBeating.m:9
    meta.ID = copy('TF213')
# /tmp/mfuncs/TF213_BellBeating.m:10
    meta.Name = copy('Bell Beating')
# /tmp/mfuncs/TF213_BellBeating.m:11
    meta.Category = copy(11)
# /tmp/mfuncs/TF213_BellBeating.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF213_BellBeating.m:13
    meta.Parameters = copy(struct('decay1',decay1,'decay2',decay2,'amp2',amp2))
# /tmp/mfuncs/TF213_BellBeating.m:14
    meta.Morphology = copy('Beating between close partials with faster overtone')
# /tmp/mfuncs/TF213_BellBeating.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    