# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF162_DiffusionMRIIVIM(N=None,A1=None,k1=None,A2=None,k2=None,*args,**kwargs):
    varargin = TF162_DiffusionMRIIVIM.varargin
    nargin = TF162_DiffusionMRIIVIM.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:2
    
    if nargin < 2 or isempty(A1):
        A1=0.12
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:3
    
    if nargin < 3 or isempty(k1):
        k1=15
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:4
    
    if nargin < 4 or isempty(A2):
        A2=0.88
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:5
    
    if nargin < 5 or isempty(k2):
        k2=2.15
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:7
    f=dot(A1,exp(dot(- k1,x))) + dot(A2,exp(dot(- k2,x)))
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:9
    meta.ID = copy('TF162')
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:10
    meta.Name = copy('Diffusion MRI IVIM')
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:11
    meta.Category = copy(9)
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:13
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:14
    meta.Morphology = copy('Sum of two decaying exponentials')
# /tmp/mfuncs/TF162_DiffusionMRIIVIM.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    