# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF185_XrayQPODrift(N=None,ampScale=None,*args,**kwargs):
    varargin = TF185_XrayQPODrift.varargin
    nargin = TF185_XrayQPODrift.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF185_XrayQPODrift.m:2
    
    if nargin < 2 or isempty(ampScale):
        ampScale=1.0
# /tmp/mfuncs/TF185_XrayQPODrift.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF185_XrayQPODrift.m:4
    amp=dot((0.12 + dot(0.35,S(x,0.18,0.06)) - dot(0.22,S(x,0.78,0.05))),ampScale)
# /tmp/mfuncs/TF185_XrayQPODrift.m:5
    phase=dot(dot(2,pi),(dot(10,x) + dot(8,x ** 2) + dot(1.8,x ** 3))) + dot(0.7,sin(dot(dot(dot(2,pi),1.3),x)))
# /tmp/mfuncs/TF185_XrayQPODrift.m:6
    f=multiply(amp,sin(phase))
# /tmp/mfuncs/TF185_XrayQPODrift.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF185_XrayQPODrift.m:8
    meta.ID = copy('TF185')
# /tmp/mfuncs/TF185_XrayQPODrift.m:9
    meta.Name = copy('X-ray QPO Drift')
# /tmp/mfuncs/TF185_XrayQPODrift.m:10
    meta.Category = copy(10)
# /tmp/mfuncs/TF185_XrayQPODrift.m:11
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF185_XrayQPODrift.m:12
    meta.Parameters = copy(struct('ampScale',ampScale))
# /tmp/mfuncs/TF185_XrayQPODrift.m:13
    meta.Morphology = copy('Amplitude-modulated quasi-periodic oscillation with drifting phase')
# /tmp/mfuncs/TF185_XrayQPODrift.m:14
    return x,f,meta
    
if __name__ == '__main__':
    pass
    