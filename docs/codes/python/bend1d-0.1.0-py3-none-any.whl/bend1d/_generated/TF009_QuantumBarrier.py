# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF009_QuantumBarrier(N=None,aQB=None,V0=None,*args,**kwargs):
    varargin = TF009_QuantumBarrier.varargin
    nargin = TF009_QuantumBarrier.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF009_QuantumBarrier.m:2
    
    if nargin < 2 or isempty(aQB):
        aQB=7.0
# /tmp/mfuncs/TF009_QuantumBarrier.m:3
    
    if nargin < 3 or isempty(V0):
        V0=1.0
# /tmp/mfuncs/TF009_QuantumBarrier.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF009_QuantumBarrier.m:5
    E=0.15 + dot(1.7,x)
# /tmp/mfuncs/TF009_QuantumBarrier.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF009_QuantumBarrier.m:7
    below=E < V0 - 1e-10
# /tmp/mfuncs/TF009_QuantumBarrier.m:8
    above=E > V0 + 1e-10
# /tmp/mfuncs/TF009_QuantumBarrier.m:9
    near=logical_not((logical_or(below,above)))
# /tmp/mfuncs/TF009_QuantumBarrier.m:10
    Eb=E(below)
# /tmp/mfuncs/TF009_QuantumBarrier.m:11
    if logical_not(isempty(Eb)):
        ka=sqrt(V0 - Eb)
# /tmp/mfuncs/TF009_QuantumBarrier.m:13
        f[below]=1 / (1 + dot(V0 ** 2,sinh(dot(aQB,ka)) ** 2) / (multiply(dot(4,Eb),(V0 - Eb))))
# /tmp/mfuncs/TF009_QuantumBarrier.m:14
    
    Ea=E(above)
# /tmp/mfuncs/TF009_QuantumBarrier.m:16
    if logical_not(isempty(Ea)):
        qq=sqrt(Ea - V0)
# /tmp/mfuncs/TF009_QuantumBarrier.m:18
        f[above]=1 / (1 + dot(V0 ** 2,sin(dot(aQB,qq)) ** 2) / (multiply(dot(4,Ea),(Ea - V0))))
# /tmp/mfuncs/TF009_QuantumBarrier.m:19
    
    f[near]=1 / (1 + dot(V0,aQB ** 2) / 4)
# /tmp/mfuncs/TF009_QuantumBarrier.m:21
    meta=copy(struct)
# /tmp/mfuncs/TF009_QuantumBarrier.m:22
    meta.ID = copy('TF009')
# /tmp/mfuncs/TF009_QuantumBarrier.m:23
    meta.Name = copy('Quantum Barrier')
# /tmp/mfuncs/TF009_QuantumBarrier.m:24
    meta.Category = copy(8)
# /tmp/mfuncs/TF009_QuantumBarrier.m:25
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF009_QuantumBarrier.m:26
    meta.Parameters = copy(struct('aQB',aQB,'V0',V0))
# /tmp/mfuncs/TF009_QuantumBarrier.m:27
    meta.Morphology = copy('Transmission probability with tunneling and resonances')
# /tmp/mfuncs/TF009_QuantumBarrier.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    