# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF126_MultiScaleSteps(N=None,levels=None,baseAmp=None,*args,**kwargs):
    varargin = TF126_MultiScaleSteps.varargin
    nargin = TF126_MultiScaleSteps.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF126_MultiScaleSteps.m:2
    
    if nargin < 2 or isempty(levels):
        levels=5
# /tmp/mfuncs/TF126_MultiScaleSteps.m:3
    
    if nargin < 3 or isempty(baseAmp):
        baseAmp=0.5
# /tmp/mfuncs/TF126_MultiScaleSteps.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF126_MultiScaleSteps.m:6
    f=dot(baseAmp,zeros(size(x)))
# /tmp/mfuncs/TF126_MultiScaleSteps.m:7
    rng(0)
    for k in arange(1,levels).reshape(-1):
        c=dot(rand(),(1 - 1 / levels)) + (k - 1) / levels
# /tmp/mfuncs/TF126_MultiScaleSteps.m:10
        w=0.02 / (2 ** (k - 1))
# /tmp/mfuncs/TF126_MultiScaleSteps.m:11
        a=baseAmp / (2 ** (k - 1))
# /tmp/mfuncs/TF126_MultiScaleSteps.m:12
        f=f + a / (1 + exp(- (x - c) / w))
# /tmp/mfuncs/TF126_MultiScaleSteps.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF126_MultiScaleSteps.m:15
    meta.ID = copy('TF126')
# /tmp/mfuncs/TF126_MultiScaleSteps.m:16
    meta.Name = copy('Multi-Scale Steps')
# /tmp/mfuncs/TF126_MultiScaleSteps.m:17
    meta.Category = copy(8)
# /tmp/mfuncs/TF126_MultiScaleSteps.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF126_MultiScaleSteps.m:19
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF126_MultiScaleSteps.m:20
    meta.Morphology = copy('Superposition of logistic steps at multiple scales')
# /tmp/mfuncs/TF126_MultiScaleSteps.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
