# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF165_TurbulenceIntermittency(N=None,phaseTI=None,*args,**kwargs):
    varargin = TF165_TurbulenceIntermittency.varargin
    nargin = TF165_TurbulenceIntermittency.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:2
    
    if nargin < 2 or isempty(phaseTI):
        phaseTI=concat([0.2,1.1,2.0,0.7,2.7,1.6,0.4,2.3,1.3])
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:4
    f=zeros(size(x))
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:5
    for m in arange(0,8).reshape(-1):
        freq=2 ** m
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:7
        amp=dot(0.13,2 ** (- m / 3))
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:8
        f=f + dot(amp,sin(dot(dot(dot(2,pi),freq),x) + phaseTI(m + 1)))
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:9
    
    f=f + multiply(dot(0.2,exp(dot(- 0.5,((x - 0.24) / 0.055) ** 2))),sin(dot(dot(dot(2,pi),73),x) + 0.3)) + multiply(dot(0.16,exp(dot(- 0.5,((x - 0.56) / 0.04) ** 2))),sin(dot(dot(dot(2,pi),119),x) + 1.1)) + multiply(dot(0.13,exp(dot(- 0.5,((x - 0.81) / 0.028) ** 2))),sin(dot(dot(dot(2,pi),181),x) + 0.8))
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:11
    meta=copy(struct)
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:14
    meta.ID = copy('TF165')
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:15
    meta.Name = copy('Turbulence Intermittency')
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:16
    meta.Category = copy(9)
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:18
    meta.Parameters = copy(struct('phaseTI',phaseTI))
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:19
    meta.Morphology = copy('Multiscale oscillatory combination with localized high-frequency bursts')
# /tmp/mfuncs/TF165_TurbulenceIntermittency.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    