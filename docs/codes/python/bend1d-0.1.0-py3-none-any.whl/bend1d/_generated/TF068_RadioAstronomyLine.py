# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF068_RadioAstronomyLine(N=None,continuum_a=None,continuum_b=None,continuum_c=None,continuum_osc=None,lineWeak_a=None,lineWeak_ctr=None,lineWeak_w=None,lineBroad_a=None,lineBroad_ctr=None,lineBroad_w=None,linePair1_a=None,linePair1_ctr=None,linePair1_w=None,linePair2_a=None,linePair2_ctr=None,linePair2_w=None,absorption_a=None,absorption_ctr=None,absorption_w=None,*args,**kwargs):
    varargin = TF068_RadioAstronomyLine.varargin
    nargin = TF068_RadioAstronomyLine.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:2
    
    if nargin < 2 or isempty(continuum_a):
        continuum_a=0.3
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:3
    
    if nargin < 3 or isempty(continuum_b):
        continuum_b=0.1
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:4
    
    if nargin < 4 or isempty(continuum_c):
        continuum_c=- 0.055
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:5
    
    if nargin < 5 or isempty(continuum_osc):
        continuum_osc=0.012
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:6
    
    if nargin < 6 or isempty(lineWeak_a):
        lineWeak_a=0.095
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:7
    
    if nargin < 7 or isempty(lineWeak_ctr):
        lineWeak_ctr=0.235
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:8
    
    if nargin < 8 or isempty(lineWeak_w):
        lineWeak_w=0.007
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:9
    
    if nargin < 9 or isempty(lineBroad_a):
        lineBroad_a=0.24
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:10
    
    if nargin < 10 or isempty(lineBroad_ctr):
        lineBroad_ctr=0.565
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:11
    
    if nargin < 11 or isempty(lineBroad_w):
        lineBroad_w=0.045
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:12
    
    if nargin < 12 or isempty(linePair1_a):
        linePair1_a=0.13
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:13
    
    if nargin < 13 or isempty(linePair1_ctr):
        linePair1_ctr=0.745
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:14
    
    if nargin < 14 or isempty(linePair1_w):
        linePair1_w=0.01
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:15
    
    if nargin < 15 or isempty(linePair2_a):
        linePair2_a=0.1
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:16
    
    if nargin < 16 or isempty(linePair2_ctr):
        linePair2_ctr=0.77
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:17
    
    if nargin < 17 or isempty(linePair2_w):
        linePair2_w=0.009
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:18
    
    if nargin < 18 or isempty(absorption_a):
        absorption_a=- 0.075
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:19
    
    if nargin < 19 or isempty(absorption_ctr):
        absorption_ctr=0.885
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:20
    
    if nargin < 20 or isempty(absorption_w):
        absorption_w=0.012
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:21
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:23
    continuum=continuum_a + dot(continuum_b,x) + dot(continuum_c,x ** 2) + dot(continuum_osc,sin(dot(dot(dot(2,pi),1.5),x)))
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:24
    lineWeak=dot(lineWeak_a,exp(dot(- 0.5,((x - lineWeak_ctr) / lineWeak_w) ** 2)))
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:25
    lineBroad=dot(lineBroad_a,exp(dot(- 0.5,((x - lineBroad_ctr) / lineBroad_w) ** 2)))
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:26
    linePair1=dot(linePair1_a,exp(dot(- 0.5,((x - linePair1_ctr) / linePair1_w) ** 2)))
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:27
    linePair2=dot(linePair2_a,exp(dot(- 0.5,((x - linePair2_ctr) / linePair2_w) ** 2)))
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:28
    absorption=dot(absorption_a,exp(dot(- 0.5,((x - absorption_ctr) / absorption_w) ** 2)))
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:29
    f=continuum + lineWeak + lineBroad + linePair1 + linePair2 + absorption
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:30
    meta=copy(struct)
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:31
    meta.ID = copy('TF068')
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:32
    meta.Name = copy('Radio-Astronomy Spectral Line')
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:33
    meta.Category = copy(6)
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:34
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:35
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:36
    meta.Morphology = copy('Continuum with narrow and broad lines, close pair, and absorption notch')
# /tmp/mfuncs/TF068_RadioAstronomyLine.m:37
    return x,f,meta
    
if __name__ == '__main__':
    pass
    