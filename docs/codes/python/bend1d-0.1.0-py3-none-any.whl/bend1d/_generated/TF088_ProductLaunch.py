# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF088_ProductLaunch(N=None,adoptAmp=None,adoptC=None,adoptW=None,viralAmp=None,viralC=None,viralW=None,satAmp=None,satC=None,satW=None,decayAmp=None,decayC=None,decayRate=None,baseLevel=None,*args,**kwargs):
    varargin = TF088_ProductLaunch.varargin
    nargin = TF088_ProductLaunch.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF088_ProductLaunch.m:2
    
    if nargin < 2 or isempty(adoptAmp):
        adoptAmp=0.68
# /tmp/mfuncs/TF088_ProductLaunch.m:3
    
    if nargin < 3 or isempty(adoptC):
        adoptC=0.37
# /tmp/mfuncs/TF088_ProductLaunch.m:4
    
    if nargin < 4 or isempty(adoptW):
        adoptW=0.055
# /tmp/mfuncs/TF088_ProductLaunch.m:5
    
    if nargin < 5 or isempty(viralAmp):
        viralAmp=0.28
# /tmp/mfuncs/TF088_ProductLaunch.m:6
    
    if nargin < 6 or isempty(viralC):
        viralC=0.52
# /tmp/mfuncs/TF088_ProductLaunch.m:7
    
    if nargin < 7 or isempty(viralW):
        viralW=0.028
# /tmp/mfuncs/TF088_ProductLaunch.m:8
    
    if nargin < 8 or isempty(satAmp):
        satAmp=- 0.12
# /tmp/mfuncs/TF088_ProductLaunch.m:9
    
    if nargin < 9 or isempty(satC):
        satC=0.74
# /tmp/mfuncs/TF088_ProductLaunch.m:10
    
    if nargin < 10 or isempty(satW):
        satW=0.045
# /tmp/mfuncs/TF088_ProductLaunch.m:11
    
    if nargin < 11 or isempty(decayAmp):
        decayAmp=- 0.1
# /tmp/mfuncs/TF088_ProductLaunch.m:12
    
    if nargin < 12 or isempty(decayC):
        decayC=0.83
# /tmp/mfuncs/TF088_ProductLaunch.m:13
    
    if nargin < 13 or isempty(decayRate):
        decayRate=1
# /tmp/mfuncs/TF088_ProductLaunch.m:14
    
    if nargin < 14 or isempty(baseLevel):
        baseLevel=0.08
# /tmp/mfuncs/TF088_ProductLaunch.m:15
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF088_ProductLaunch.m:17
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF088_ProductLaunch.m:18
    adoptPL=dot(adoptAmp,sigmoid(x,adoptC,adoptW))
# /tmp/mfuncs/TF088_ProductLaunch.m:19
    viralPL=dot(viralAmp,exp(dot(- 0.5,((x - viralC) / viralW) ** 2)))
# /tmp/mfuncs/TF088_ProductLaunch.m:20
    saturationPL=dot(satAmp,sigmoid(x,satC,satW))
# /tmp/mfuncs/TF088_ProductLaunch.m:21
    decayPL=dot(decayAmp,max(x - decayC,0) ** decayRate)
# /tmp/mfuncs/TF088_ProductLaunch.m:22
    f=baseLevel + adoptPL + viralPL + saturationPL + decayPL
# /tmp/mfuncs/TF088_ProductLaunch.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF088_ProductLaunch.m:25
    meta.ID = copy('TF088')
# /tmp/mfuncs/TF088_ProductLaunch.m:26
    meta.Name = copy('Product Launch')
# /tmp/mfuncs/TF088_ProductLaunch.m:27
    meta.Category = copy(6)
# /tmp/mfuncs/TF088_ProductLaunch.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF088_ProductLaunch.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF088_ProductLaunch.m:30
    meta.Morphology = copy('Adoption S-curve, viral spike, saturation and late decay')
# /tmp/mfuncs/TF088_ProductLaunch.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    