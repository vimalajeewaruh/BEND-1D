# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF069_OceanThermocline(N=None,mixed_slope=None,thermo_amp=None,thermo_ctr=None,thermo_k=None,deep_grad_amp=None,inversion_a=None,inversion_ctr=None,inversion_w=None,fs_amp=None,fs_freq=None,fs_ctr=None,fs_decay=None,*args,**kwargs):
    varargin = TF069_OceanThermocline.varargin
    nargin = TF069_OceanThermocline.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF069_OceanThermocline.m:2
    
    if nargin < 2 or isempty(mixed_slope):
        mixed_slope=- 0.025
# /tmp/mfuncs/TF069_OceanThermocline.m:3
    
    if nargin < 3 or isempty(thermo_amp):
        thermo_amp=- 0.62
# /tmp/mfuncs/TF069_OceanThermocline.m:4
    
    if nargin < 4 or isempty(thermo_ctr):
        thermo_ctr=0.43
# /tmp/mfuncs/TF069_OceanThermocline.m:5
    
    if nargin < 5 or isempty(thermo_k):
        thermo_k=42
# /tmp/mfuncs/TF069_OceanThermocline.m:6
    
    if nargin < 6 or isempty(deep_grad_amp):
        deep_grad_amp=- 0.14
# /tmp/mfuncs/TF069_OceanThermocline.m:7
    
    if nargin < 7 or isempty(inversion_a):
        inversion_a=0.075
# /tmp/mfuncs/TF069_OceanThermocline.m:8
    
    if nargin < 8 or isempty(inversion_ctr):
        inversion_ctr=0.69
# /tmp/mfuncs/TF069_OceanThermocline.m:9
    
    if nargin < 9 or isempty(inversion_w):
        inversion_w=0.035
# /tmp/mfuncs/TF069_OceanThermocline.m:10
    
    if nargin < 10 or isempty(fs_amp):
        fs_amp=0.015
# /tmp/mfuncs/TF069_OceanThermocline.m:11
    
    if nargin < 11 or isempty(fs_freq):
        fs_freq=10
# /tmp/mfuncs/TF069_OceanThermocline.m:12
    
    if nargin < 12 or isempty(fs_ctr):
        fs_ctr=0.46
# /tmp/mfuncs/TF069_OceanThermocline.m:13
    
    if nargin < 13 or isempty(fs_decay):
        fs_decay=0.2
# /tmp/mfuncs/TF069_OceanThermocline.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF069_OceanThermocline.m:16
    mixedLayer=1.0 + dot(mixed_slope,x)
# /tmp/mfuncs/TF069_OceanThermocline.m:17
    thermocline=thermo_amp / (1 + exp(dot(- thermo_k,(x - thermo_ctr))))
# /tmp/mfuncs/TF069_OceanThermocline.m:18
    deepGradient=dot(deep_grad_amp,max(x - 0.46,0))
# /tmp/mfuncs/TF069_OceanThermocline.m:19
    inversion=dot(inversion_a,exp(dot(- 0.5,((x - inversion_ctr) / inversion_w) ** 2)))
# /tmp/mfuncs/TF069_OceanThermocline.m:20
    fineStructure=multiply(dot(fs_amp,sin(dot(dot(dot(2,pi),fs_freq),x))),exp(dot(- 0.5,((x - fs_ctr) / fs_decay) ** 2)))
# /tmp/mfuncs/TF069_OceanThermocline.m:21
    f=mixedLayer + thermocline + deepGradient + inversion + fineStructure
# /tmp/mfuncs/TF069_OceanThermocline.m:22
    meta=copy(struct)
# /tmp/mfuncs/TF069_OceanThermocline.m:23
    meta.ID = copy('TF069')
# /tmp/mfuncs/TF069_OceanThermocline.m:24
    meta.Name = copy('Ocean Thermocline')
# /tmp/mfuncs/TF069_OceanThermocline.m:25
    meta.Category = copy(6)
# /tmp/mfuncs/TF069_OceanThermocline.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF069_OceanThermocline.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF069_OceanThermocline.m:28
    meta.Morphology = copy('Surface mixed layer, sharp thermocline, deep gradient and weak inversion')
# /tmp/mfuncs/TF069_OceanThermocline.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    