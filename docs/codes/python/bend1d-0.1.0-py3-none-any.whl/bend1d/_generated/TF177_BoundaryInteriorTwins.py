# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF177_BoundaryInteriorTwins(N=None,centers=None,ampBIT=None,sigmaBIT=None,freqBIT=None,*args,**kwargs):
    varargin = TF177_BoundaryInteriorTwins.varargin
    nargin = TF177_BoundaryInteriorTwins.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:2
    
    if nargin < 2 or isempty(centers):
        centers=concat([0.025,0.5,0.975])
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:3
    
    if nargin < 3 or isempty(ampBIT):
        ampBIT=1.0
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:4
    
    if nargin < 4 or isempty(sigmaBIT):
        sigmaBIT=0.013
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:5
    
    if nargin < 5 or isempty(freqBIT):
        freqBIT=31
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:8
    for c in centers.reshape(-1):
        u=x - c
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:10
        f=f + multiply(dot(ampBIT,exp(dot(- 0.5,(u / sigmaBIT) ** 2))),cos(dot(dot(dot(2,pi),freqBIT),u)))
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:11
    
    meta=copy(struct)
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:13
    meta.ID = copy('TF177')
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:14
    meta.Name = copy('Boundary/Interior Twins')
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:17
    meta.Parameters = copy(struct('centers',centers,'amp',ampBIT,'sigma',sigmaBIT,'freq',freqBIT))
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:18
    meta.Morphology = copy('Localized oscillatory twins at boundaries and interior')
# /tmp/mfuncs/TF177_BoundaryInteriorTwins.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    