# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF158_XAFSEdge(N=None,edgeCtr=None,edgeWidth=None,baseA=None,linA=None,stepA=None,oscA=None,oscDecay=None,oscPhase=None,*args,**kwargs):
    varargin = TF158_XAFSEdge.varargin
    nargin = TF158_XAFSEdge.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF158_XAFSEdge.m:2
    
    if nargin < 2 or isempty(edgeCtr):
        edgeCtr=0.34
# /tmp/mfuncs/TF158_XAFSEdge.m:3
    
    if nargin < 3 or isempty(edgeWidth):
        edgeWidth=0.004
# /tmp/mfuncs/TF158_XAFSEdge.m:4
    
    if nargin < 4 or isempty(baseA):
        baseA=0.08
# /tmp/mfuncs/TF158_XAFSEdge.m:5
    
    if nargin < 5 or isempty(linA):
        linA=0.1
# /tmp/mfuncs/TF158_XAFSEdge.m:6
    
    if nargin < 6 or isempty(stepA):
        stepA=0.72
# /tmp/mfuncs/TF158_XAFSEdge.m:7
    
    if nargin < 7 or isempty(oscA):
        oscA=0.16
# /tmp/mfuncs/TF158_XAFSEdge.m:8
    
    if nargin < 8 or isempty(oscDecay):
        oscDecay=2.6
# /tmp/mfuncs/TF158_XAFSEdge.m:9
    
    if nargin < 9 or isempty(oscPhase):
        oscPhase=0
# /tmp/mfuncs/TF158_XAFSEdge.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF158_XAFSEdge.m:11
    u=max(x - edgeCtr,0)
# /tmp/mfuncs/TF158_XAFSEdge.m:12
    f=baseA + dot(linA,x) + dot(stepA,S(x,edgeCtr,edgeWidth))
# /tmp/mfuncs/TF158_XAFSEdge.m:13
    f=f + multiply(multiply(multiply((x >= edgeCtr),oscA),exp(dot(- oscDecay,u))),sin(dot(dot(2,pi),(dot(12,u) + dot(18,u ** 2))) + oscPhase))
# /tmp/mfuncs/TF158_XAFSEdge.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF158_XAFSEdge.m:15
    meta.ID = copy('TF158')
# /tmp/mfuncs/TF158_XAFSEdge.m:16
    meta.Name = copy('XAFS Edge')
# /tmp/mfuncs/TF158_XAFSEdge.m:17
    meta.Category = copy(9)
# /tmp/mfuncs/TF158_XAFSEdge.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF158_XAFSEdge.m:19
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF158_XAFSEdge.m:20
    meta.Morphology = copy('Edge with decaying chirped oscillations')
# /tmp/mfuncs/TF158_XAFSEdge.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    