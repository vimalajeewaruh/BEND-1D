# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF040_WhaleClicks(N=None,clickTimes=None,clickAmp=None,*args,**kwargs):
    varargin = TF040_WhaleClicks.varargin
    nargin = TF040_WhaleClicks.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF040_WhaleClicks.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF040_WhaleClicks.m:3
    if nargin < 2 or isempty(clickTimes):
        clickTimes=concat([0.105,0.205,0.298,0.397,0.515,0.655,0.815,0.925])
# /tmp/mfuncs/TF040_WhaleClicks.m:5
    else:
        if isscalar(clickTimes):
            clickTimes=repmat(clickTimes,1,1)
# /tmp/mfuncs/TF040_WhaleClicks.m:7
    
    if nargin < 3 or isempty(clickAmp):
        clickAmp=concat([1.0,0.82,1.08,0.9,0.72,1.03,0.86,0.76])
# /tmp/mfuncs/TF040_WhaleClicks.m:10
    else:
        if isscalar(clickAmp):
            clickAmp=repmat(clickAmp,1,numel(clickTimes))
# /tmp/mfuncs/TF040_WhaleClicks.m:12
    
    # Ensure vectors align to x via interpolation if lengths mismatch with intended positions
    if numel(clickAmp) != numel(clickTimes):
        clickAmp=interp1(linspace(0,1,numel(clickAmp)),clickAmp,linspace(0,1,numel(clickTimes)),'linear',clickAmp(end()))
# /tmp/mfuncs/TF040_WhaleClicks.m:16
    
    f=zeros(size(x))
# /tmp/mfuncs/TF040_WhaleClicks.m:18
    for k in arange(1,numel(clickTimes)).reshape(-1):
        tk=clickTimes(k)
# /tmp/mfuncs/TF040_WhaleClicks.m:20
        ak=clickAmp(k)
# /tmp/mfuncs/TF040_WhaleClicks.m:20
        s1=0.0022
# /tmp/mfuncs/TF040_WhaleClicks.m:21
        u1=(x - tk) / s1
# /tmp/mfuncs/TF040_WhaleClicks.m:22
        click1=multiply(dot(ak,u1),exp(dot(- 0.5,u1 ** 2)))
# /tmp/mfuncs/TF040_WhaleClicks.m:23
        te=tk + 0.012 + dot(0.002,sin(k))
# /tmp/mfuncs/TF040_WhaleClicks.m:24
        s2=0.003
# /tmp/mfuncs/TF040_WhaleClicks.m:25
        u2=(x - te) / s2
# /tmp/mfuncs/TF040_WhaleClicks.m:26
        echo=multiply(dot(dot(0.25,ak),u2),exp(dot(- 0.5,u2 ** 2)))
# /tmp/mfuncs/TF040_WhaleClicks.m:27
        f=f + click1 + echo
# /tmp/mfuncs/TF040_WhaleClicks.m:28
    
    meta=copy(struct)
# /tmp/mfuncs/TF040_WhaleClicks.m:30
    meta.ID = copy('TF040')
# /tmp/mfuncs/TF040_WhaleClicks.m:31
    meta.Name = copy('Whale Clicks')
# /tmp/mfuncs/TF040_WhaleClicks.m:32
    meta.Category = copy(3)
# /tmp/mfuncs/TF040_WhaleClicks.m:33
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF040_WhaleClicks.m:34
    meta.Parameters = copy(struct('clickTimes',clickTimes,'clickAmp',clickAmp))
# /tmp/mfuncs/TF040_WhaleClicks.m:35
    meta.Morphology = copy('Irregular train of bipolar clicks with delayed echoes')
# /tmp/mfuncs/TF040_WhaleClicks.m:36
    return x,f,meta
    
if __name__ == '__main__':
    pass
    