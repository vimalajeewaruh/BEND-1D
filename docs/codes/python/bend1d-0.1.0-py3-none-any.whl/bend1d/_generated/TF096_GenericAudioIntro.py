# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF096_GenericAudioIntro(N=None,ambFreq=None,ambAmp=None,bassC=None,bassW=None,bassAmp=None,bassFreq=None,harmC=None,harmW=None,harmAmp=None,harmFreq=None,beatCenters=None,beatAmp=None,beatDecay=None,cresAmp=None,*args,**kwargs):
    varargin = TF096_GenericAudioIntro.varargin
    nargin = TF096_GenericAudioIntro.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF096_GenericAudioIntro.m:2
    
    if nargin < 2 or isempty(ambFreq):
        ambFreq=4
# /tmp/mfuncs/TF096_GenericAudioIntro.m:3
    
    if nargin < 3 or isempty(ambAmp):
        ambAmp=0.04
# /tmp/mfuncs/TF096_GenericAudioIntro.m:4
    
    if nargin < 4 or isempty(bassC):
        bassC=0.18
# /tmp/mfuncs/TF096_GenericAudioIntro.m:5
    
    if nargin < 5 or isempty(bassW):
        bassW=0.02
# /tmp/mfuncs/TF096_GenericAudioIntro.m:6
    
    if nargin < 6 or isempty(bassAmp):
        bassAmp=0.14
# /tmp/mfuncs/TF096_GenericAudioIntro.m:7
    
    if nargin < 7 or isempty(bassFreq):
        bassFreq=9
# /tmp/mfuncs/TF096_GenericAudioIntro.m:8
    
    if nargin < 8 or isempty(harmC):
        harmC=0.38
# /tmp/mfuncs/TF096_GenericAudioIntro.m:9
    
    if nargin < 9 or isempty(harmW):
        harmW=0.025
# /tmp/mfuncs/TF096_GenericAudioIntro.m:10
    
    if nargin < 10 or isempty(harmAmp):
        harmAmp=0.12
# /tmp/mfuncs/TF096_GenericAudioIntro.m:11
    
    if nargin < 11 or isempty(harmFreq):
        harmFreq=23
# /tmp/mfuncs/TF096_GenericAudioIntro.m:12
    
    if nargin < 12 or isempty(beatCenters):
        beatCenters=arange(0.42,0.96,0.085)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:13
    
    if nargin < 13 or isempty(beatAmp):
        beatAmp=0.2
# /tmp/mfuncs/TF096_GenericAudioIntro.m:14
    
    if nargin < 14 or isempty(beatDecay):
        beatDecay=70
# /tmp/mfuncs/TF096_GenericAudioIntro.m:15
    
    if nargin < 15 or isempty(cresAmp):
        cresAmp=0.1
# /tmp/mfuncs/TF096_GenericAudioIntro.m:16
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF096_GenericAudioIntro.m:18
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:19
    amb=dot(ambAmp,sin(dot(dot(dot(2,pi),ambFreq),x)))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:20
    bassEnv=sigmoid(x,bassC,bassW)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:21
    bass=multiply(dot(bassAmp,bassEnv),sin(dot(dot(dot(2,pi),bassFreq),x)))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:22
    harmEnv=sigmoid(x,harmC,harmW)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:23
    harm=multiply(dot(harmAmp,harmEnv),sin(dot(dot(dot(2,pi),harmFreq),x) + 0.4))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:24
    rhythm=zeros(size(x))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:25
    for k in arange(1,numel(beatCenters)).reshape(-1):
        c=beatCenters(k)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:27
        u=max(x - c,0)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:28
        rhythm=rhythm + multiply(multiply(dot(beatAmp,(x >= c)),exp(dot(- beatDecay,u))),sin(dot(dot(dot(2,pi),beatDecay),u)))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:29
    
    cres=multiply(dot(cresAmp,x),sin(dot(dot(2,pi),(dot(14,x) + dot(5,x ** 2)))))
# /tmp/mfuncs/TF096_GenericAudioIntro.m:31
    f=amb + bass + harm + rhythm + cres
# /tmp/mfuncs/TF096_GenericAudioIntro.m:32
    meta=copy(struct)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:33
    meta.ID = copy('TF096')
# /tmp/mfuncs/TF096_GenericAudioIntro.m:34
    meta.Name = copy('Generic Audio Intro')
# /tmp/mfuncs/TF096_GenericAudioIntro.m:35
    meta.Category = copy(6)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:36
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:37
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF096_GenericAudioIntro.m:38
    meta.Morphology = copy('Layered audio intro with beats and crescendos')
# /tmp/mfuncs/TF096_GenericAudioIntro.m:39
    return x,f,meta
    
if __name__ == '__main__':
    pass
    