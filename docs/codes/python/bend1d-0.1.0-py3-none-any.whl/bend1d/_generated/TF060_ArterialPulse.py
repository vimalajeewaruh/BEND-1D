# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF060_ArterialPulse(N=None,baseline=None,main_amp=None,main_shift=None,main_pow=None,main_scale=None,notch_a=None,notch_ctr=None,notch_w=None,rebound_a=None,rebound_ctr=None,rebound_w=None,tail_a=None,tail_start=None,tail_k=None,*args,**kwargs):
    varargin = TF060_ArterialPulse.varargin
    nargin = TF060_ArterialPulse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF060_ArterialPulse.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.065
# /tmp/mfuncs/TF060_ArterialPulse.m:3
    
    if nargin < 3 or isempty(main_amp):
        main_amp=0.92
# /tmp/mfuncs/TF060_ArterialPulse.m:4
    
    if nargin < 4 or isempty(main_shift):
        main_shift=0.07
# /tmp/mfuncs/TF060_ArterialPulse.m:5
    
    if nargin < 5 or isempty(main_pow):
        main_pow=2.15
# /tmp/mfuncs/TF060_ArterialPulse.m:6
    
    if nargin < 6 or isempty(main_scale):
        main_scale=8.8
# /tmp/mfuncs/TF060_ArterialPulse.m:7
    
    if nargin < 7 or isempty(notch_a):
        notch_a=- 0.115
# /tmp/mfuncs/TF060_ArterialPulse.m:8
    
    if nargin < 8 or isempty(notch_ctr):
        notch_ctr=0.5
# /tmp/mfuncs/TF060_ArterialPulse.m:9
    
    if nargin < 9 or isempty(notch_w):
        notch_w=0.012
# /tmp/mfuncs/TF060_ArterialPulse.m:10
    
    if nargin < 10 or isempty(rebound_a):
        rebound_a=0.06
# /tmp/mfuncs/TF060_ArterialPulse.m:11
    
    if nargin < 11 or isempty(rebound_ctr):
        rebound_ctr=0.545
# /tmp/mfuncs/TF060_ArterialPulse.m:12
    
    if nargin < 12 or isempty(rebound_w):
        rebound_w=0.021
# /tmp/mfuncs/TF060_ArterialPulse.m:13
    
    if nargin < 13 or isempty(tail_a):
        tail_a=0.065
# /tmp/mfuncs/TF060_ArterialPulse.m:14
    
    if nargin < 14 or isempty(tail_start):
        tail_start=0.53
# /tmp/mfuncs/TF060_ArterialPulse.m:15
    
    if nargin < 15 or isempty(tail_k):
        tail_k=4.8
# /tmp/mfuncs/TF060_ArterialPulse.m:16
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF060_ArterialPulse.m:18
    uAP=max(x - main_shift,0)
# /tmp/mfuncs/TF060_ArterialPulse.m:19
    mainPulse=multiply((uAP ** main_pow),exp(dot(- main_scale,uAP)))
# /tmp/mfuncs/TF060_ArterialPulse.m:20
    mainPulse=mainPulse / max(mainPulse)
# /tmp/mfuncs/TF060_ArterialPulse.m:21
    dicroticNotch=dot(notch_a,exp(dot(- 0.5,((x - notch_ctr) / notch_w) ** 2)))
# /tmp/mfuncs/TF060_ArterialPulse.m:22
    dicroticRebound=dot(rebound_a,exp(dot(- 0.5,((x - rebound_ctr) / rebound_w) ** 2)))
# /tmp/mfuncs/TF060_ArterialPulse.m:23
    diastolicTail=multiply(dot(tail_a,(x >= tail_start)),exp(dot(- tail_k,(x - tail_start))))
# /tmp/mfuncs/TF060_ArterialPulse.m:24
    f=baseline + dot(main_amp,mainPulse) + dicroticNotch + dicroticRebound + diastolicTail
# /tmp/mfuncs/TF060_ArterialPulse.m:25
    meta=copy(struct)
# /tmp/mfuncs/TF060_ArterialPulse.m:27
    meta.ID = copy('TF060')
# /tmp/mfuncs/TF060_ArterialPulse.m:28
    meta.Name = copy('Arterial Pulse')
# /tmp/mfuncs/TF060_ArterialPulse.m:29
    meta.Category = copy(5)
# /tmp/mfuncs/TF060_ArterialPulse.m:30
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF060_ArterialPulse.m:31
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF060_ArterialPulse.m:32
    meta.Morphology = copy('Fast systolic rise, rounded peak, dicrotic notch, rebound, slow decay')
# /tmp/mfuncs/TF060_ArterialPulse.m:33
    return x,f,meta
    
if __name__ == '__main__':
    pass
    