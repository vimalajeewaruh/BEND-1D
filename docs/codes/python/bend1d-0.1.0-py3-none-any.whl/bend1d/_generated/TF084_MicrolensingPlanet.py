# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF084_MicrolensingPlanet(N=None,center_u=None,width_u=None,base_ml=None,planet1_a=None,planet1_c=None,planet1_w=None,planet2_a=None,planet2_c=None,planet2_w=None,*args,**kwargs):
    varargin = TF084_MicrolensingPlanet.varargin
    nargin = TF084_MicrolensingPlanet.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:2
    
    if nargin < 2 or isempty(center_u):
        center_u=0.52
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:3
    
    if nargin < 3 or isempty(width_u):
        width_u=0.115
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:4
    
    if nargin < 4 or isempty(base_ml):
        base_ml=0.1
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:5
    
    if nargin < 5 or isempty(planet1_a):
        planet1_a=0.095
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:6
    
    if nargin < 6 or isempty(planet1_c):
        planet1_c=0.585
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:7
    
    if nargin < 7 or isempty(planet1_w):
        planet1_w=0.01
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:8
    
    if nargin < 8 or isempty(planet2_a):
        planet2_a=- 0.035
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:9
    
    if nargin < 9 or isempty(planet2_c):
        planet2_c=0.605
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:10
    
    if nargin < 10 or isempty(planet2_w):
        planet2_w=0.016
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:13
    u=(x - center_u) / width_u
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:14
    smoothML=base_ml + 0.82 / sqrt(1 + u ** 2)
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:15
    planetML=dot(planet1_a,exp(dot(- 0.5,((x - planet1_c) / planet1_w) ** 2))) + dot(planet2_a,exp(dot(- 0.5,((x - planet2_c) / planet2_w) ** 2)))
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:16
    f=smoothML + planetML
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:18
    meta.ID = copy('TF084')
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:19
    meta.Name = copy('Microlensing with Planetary Anomaly')
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:23
    meta.Morphology = copy('Smooth lensing curve with localized planetary deviation')
# /tmp/mfuncs/TF084_MicrolensingPlanet.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    