# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF022_Titration(N=None,*args,**kwargs):
    varargin = TF022_Titration.varargin
    nargin = TF022_Titration.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF022_Titration.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF022_Titration.m:3
    f=dot(0.08,log(1 + dot(20,x))) + dot(0.55,tanh((x - 0.31) / 0.018)) + dot(0.32,tanh((x - 0.69) / 0.06)) + dot(0.13,tanh((x - 0.84) / 0.014))
# /tmp/mfuncs/TF022_Titration.m:4
    f=f + dot(0.07,exp(- ((x - 0.5) / 0.028) ** 2))
# /tmp/mfuncs/TF022_Titration.m:5
    meta=copy(struct)
# /tmp/mfuncs/TF022_Titration.m:6
    meta.ID = copy('TF022')
# /tmp/mfuncs/TF022_Titration.m:7
    meta.Name = copy('Titration')
# /tmp/mfuncs/TF022_Titration.m:8
    meta.Category = copy(2)
# /tmp/mfuncs/TF022_Titration.m:9
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF022_Titration.m:10
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF022_Titration.m:11
    meta.Morphology = copy('Log background with multiple smooth equivalence transitions')
# /tmp/mfuncs/TF022_Titration.m:12
    return x,f,meta
    
if __name__ == '__main__':
    pass
    