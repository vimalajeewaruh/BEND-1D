# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF188_TokamakELMTrain(N=None,qSlope=None,qPertAmp=None,c=None,a=None,w=None,*args,**kwargs):
    varargin = TF188_TokamakELMTrain.varargin
    nargin = TF188_TokamakELMTrain.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF188_TokamakELMTrain.m:2
    
    if nargin < 2 or isempty(qSlope):
        qSlope=6.4
# /tmp/mfuncs/TF188_TokamakELMTrain.m:3
    
    if nargin < 3 or isempty(qPertAmp):
        qPertAmp=0.07
# /tmp/mfuncs/TF188_TokamakELMTrain.m:4
    
    if nargin < 4 or isempty(c):
        c=concat([0.156,0.312,0.468,0.625,0.782,0.937])
# /tmp/mfuncs/TF188_TokamakELMTrain.m:5
    
    if nargin < 5 or isempty(a):
        a=concat([0.12,0.08,0.15,0.1,0.16,0.08])
# /tmp/mfuncs/TF188_TokamakELMTrain.m:6
    
    if nargin < 6 or isempty(w):
        w=0.006
# /tmp/mfuncs/TF188_TokamakELMTrain.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF188_TokamakELMTrain.m:8
    q=dot(qSlope,x) + dot(qPertAmp,sin(dot(dot(2,pi),x)))
# /tmp/mfuncs/TF188_TokamakELMTrain.m:9
    ramp=q - floor(q)
# /tmp/mfuncs/TF188_TokamakELMTrain.m:10
    f=0.12 + multiply(dot(0.78,ramp),(1 + dot(0.1,sin(dot(dot(dot(2,pi),1.1),x)))))
# /tmp/mfuncs/TF188_TokamakELMTrain.m:11
    for k in arange(1,numel(c)).reshape(-1):
        f=f + dot(a(k),G(x,c(k),w))
# /tmp/mfuncs/TF188_TokamakELMTrain.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF188_TokamakELMTrain.m:15
    meta.ID = copy('TF188')
# /tmp/mfuncs/TF188_TokamakELMTrain.m:16
    meta.Name = copy('Tokamak ELM Train')
# /tmp/mfuncs/TF188_TokamakELMTrain.m:17
    meta.Category = copy(10)
# /tmp/mfuncs/TF188_TokamakELMTrain.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF188_TokamakELMTrain.m:19
    meta.Parameters = copy(struct('qSlope',qSlope,'qPertAmp',qPertAmp,'centers',c,'amps',a,'width',w))
# /tmp/mfuncs/TF188_TokamakELMTrain.m:20
    meta.Morphology = copy('Periodic ramp-like ELMs with localized spikes')
# /tmp/mfuncs/TF188_TokamakELMTrain.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    