# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF019_WaterHammer(N=None,xWH=None,*args,**kwargs):
    varargin = TF019_WaterHammer.varargin
    nargin = TF019_WaterHammer.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF019_WaterHammer.m:2
    
    if nargin < 2 or isempty(xWH):
        xWH=0.3
# /tmp/mfuncs/TF019_WaterHammer.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF019_WaterHammer.m:4
    u=max(x - xWH,0)
# /tmp/mfuncs/TF019_WaterHammer.m:5
    front=dot(0.65,(1 + tanh(dot(120,(x - xWH)))))
# /tmp/mfuncs/TF019_WaterHammer.m:6
    ring=multiply(multiply(dot(0.38,(x >= xWH)),exp(dot(- 6,u))),cos(dot(dot(54,pi),u)))
# /tmp/mfuncs/TF019_WaterHammer.m:7
    f=front + ring
# /tmp/mfuncs/TF019_WaterHammer.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF019_WaterHammer.m:9
    meta.ID = copy('TF019')
# /tmp/mfuncs/TF019_WaterHammer.m:10
    meta.Name = copy('Water Hammer')
# /tmp/mfuncs/TF019_WaterHammer.m:11
    meta.Category = copy(2)
# /tmp/mfuncs/TF019_WaterHammer.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF019_WaterHammer.m:13
    meta.Parameters = copy(struct('xWH',xWH))
# /tmp/mfuncs/TF019_WaterHammer.m:14
    meta.Morphology = copy('Steep smooth pressure rise with damped acoustic ringing')
# /tmp/mfuncs/TF019_WaterHammer.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    