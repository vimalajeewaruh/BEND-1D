# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF147_FrequencyCrossing(N=None,envAmp=None,envCtr=None,envW=None,ampUp=None,ampDn=None,*args,**kwargs):
    varargin = TF147_FrequencyCrossing.varargin
    nargin = TF147_FrequencyCrossing.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF147_FrequencyCrossing.m:2
    
    if nargin < 2 or isempty(envAmp):
        envAmp=0.75
# /tmp/mfuncs/TF147_FrequencyCrossing.m:3
    
    if nargin < 3 or isempty(envCtr):
        envCtr=0.5
# /tmp/mfuncs/TF147_FrequencyCrossing.m:4
    
    if nargin < 4 or isempty(envW):
        envW=0.3
# /tmp/mfuncs/TF147_FrequencyCrossing.m:5
    
    if nargin < 5 or isempty(ampUp):
        ampUp=0.25
# /tmp/mfuncs/TF147_FrequencyCrossing.m:6
    
    if nargin < 6 or isempty(ampDn):
        ampDn=0.25
# /tmp/mfuncs/TF147_FrequencyCrossing.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF147_FrequencyCrossing.m:9
    phiUp=dot(dot(2,pi),(dot(8,x) + dot(20,x ** 2)))
# /tmp/mfuncs/TF147_FrequencyCrossing.m:10
    phiDn=dot(dot(2,pi),(dot(28,x) - dot(20,x ** 2)))
# /tmp/mfuncs/TF147_FrequencyCrossing.m:11
    f=multiply((envAmp + dot((1 - envAmp),exp(dot(- 0.5,((x - envCtr) / envW) ** 2)))),(dot(ampUp,sin(phiUp)) + dot(ampDn,sin(phiDn + 0.35))))
# /tmp/mfuncs/TF147_FrequencyCrossing.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF147_FrequencyCrossing.m:13
    meta.ID = copy('TF147')
# /tmp/mfuncs/TF147_FrequencyCrossing.m:14
    meta.Name = copy('Frequency Crossing')
# /tmp/mfuncs/TF147_FrequencyCrossing.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF147_FrequencyCrossing.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF147_FrequencyCrossing.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF147_FrequencyCrossing.m:18
    meta.Morphology = copy('Two crossing instantaneous frequency components with amplitude windowing')
# /tmp/mfuncs/TF147_FrequencyCrossing.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    