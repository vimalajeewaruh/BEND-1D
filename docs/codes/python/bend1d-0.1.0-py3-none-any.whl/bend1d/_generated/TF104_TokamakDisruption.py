# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF104_TokamakDisruption(N=None,growAmp=None,growFreq=None,growQuad=None,lockAmp=None,lockFreq=None,lockC=None,lockW=None,collapseAmp=None,collapseC=None,collapseW=None,base=None,*args,**kwargs):
    varargin = TF104_TokamakDisruption.varargin
    nargin = TF104_TokamakDisruption.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF104_TokamakDisruption.m:2
    
    if nargin < 2 or isempty(growAmp):
        growAmp=0.04
# /tmp/mfuncs/TF104_TokamakDisruption.m:3
    
    if nargin < 3 or isempty(growFreq):
        growFreq=8
# /tmp/mfuncs/TF104_TokamakDisruption.m:4
    
    if nargin < 4 or isempty(growQuad):
        growQuad=10
# /tmp/mfuncs/TF104_TokamakDisruption.m:5
    
    if nargin < 5 or isempty(lockAmp):
        lockAmp=0.16
# /tmp/mfuncs/TF104_TokamakDisruption.m:6
    
    if nargin < 6 or isempty(lockFreq):
        lockFreq=2.5
# /tmp/mfuncs/TF104_TokamakDisruption.m:7
    
    if nargin < 7 or isempty(lockC):
        lockC=0.58
# /tmp/mfuncs/TF104_TokamakDisruption.m:8
    
    if nargin < 8 or isempty(lockW):
        lockW=0.02
# /tmp/mfuncs/TF104_TokamakDisruption.m:9
    
    if nargin < 9 or isempty(collapseAmp):
        collapseAmp=- 0.95
# /tmp/mfuncs/TF104_TokamakDisruption.m:10
    
    if nargin < 10 or isempty(collapseC):
        collapseC=0.79
# /tmp/mfuncs/TF104_TokamakDisruption.m:11
    
    if nargin < 11 or isempty(collapseW):
        collapseW=0.006
# /tmp/mfuncs/TF104_TokamakDisruption.m:12
    
    if nargin < 12 or isempty(base):
        base=0.55
# /tmp/mfuncs/TF104_TokamakDisruption.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF104_TokamakDisruption.m:15
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF104_TokamakDisruption.m:16
    growTD=multiply((growAmp + dot(0.3,x)),sin(dot(dot(2,pi),(dot(growFreq,x) + dot(growQuad,x ** 2)))))
# /tmp/mfuncs/TF104_TokamakDisruption.m:17
    lockTD=multiply(dot(lockAmp,sin(dot(dot(dot(2,pi),lockFreq),x))),S(x,lockC,lockW))
# /tmp/mfuncs/TF104_TokamakDisruption.m:18
    collapseTD=dot(collapseAmp,S(x,collapseC,collapseW))
# /tmp/mfuncs/TF104_TokamakDisruption.m:19
    f=base + growTD + lockTD + collapseTD
# /tmp/mfuncs/TF104_TokamakDisruption.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF104_TokamakDisruption.m:21
    meta.ID = copy('TF104')
# /tmp/mfuncs/TF104_TokamakDisruption.m:22
    meta.Name = copy('Tokamak Disruption')
# /tmp/mfuncs/TF104_TokamakDisruption.m:23
    meta.Category = copy(6)
# /tmp/mfuncs/TF104_TokamakDisruption.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF104_TokamakDisruption.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF104_TokamakDisruption.m:26
    meta.Morphology = copy('Growth, mode locking and abrupt collapse')
# /tmp/mfuncs/TF104_TokamakDisruption.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    