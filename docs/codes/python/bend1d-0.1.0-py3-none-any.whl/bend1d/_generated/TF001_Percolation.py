# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF001_Percolation(N=None,pc=None,beta=None,*args,**kwargs):
    varargin = TF001_Percolation.varargin
    nargin = TF001_Percolation.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF001_Percolation.m:2
    
    if nargin < 2 or isempty(pc):
        pc=0.38
# /tmp/mfuncs/TF001_Percolation.m:3
    
    if nargin < 3 or isempty(beta):
        beta=0.41
# /tmp/mfuncs/TF001_Percolation.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF001_Percolation.m:5
    f=max(x - pc,0) ** beta
# /tmp/mfuncs/TF001_Percolation.m:6
    meta=copy(struct)
# /tmp/mfuncs/TF001_Percolation.m:7
    meta.ID = copy('TF001')
# /tmp/mfuncs/TF001_Percolation.m:8
    meta.Name = copy('Percolation')
# /tmp/mfuncs/TF001_Percolation.m:9
    meta.Category = copy(1)
# /tmp/mfuncs/TF001_Percolation.m:10
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF001_Percolation.m:11
    meta.Parameters = copy(struct('pc',pc,'beta',beta))
# /tmp/mfuncs/TF001_Percolation.m:12
    meta.Morphology = copy('Continuous onset with a singular derivative')
# /tmp/mfuncs/TF001_Percolation.m:13
    return x,f,meta
    
if __name__ == '__main__':
    pass
    