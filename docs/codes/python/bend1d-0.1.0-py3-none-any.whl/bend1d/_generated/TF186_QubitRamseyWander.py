# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF186_QubitRamseyWander(N=None,visBase=None,visDipCenter=None,visDipWidth=None,*args,**kwargs):
    varargin = TF186_QubitRamseyWander.varargin
    nargin = TF186_QubitRamseyWander.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF186_QubitRamseyWander.m:2
    
    if nargin < 2 or isempty(visBase):
        visBase=0.92
# /tmp/mfuncs/TF186_QubitRamseyWander.m:3
    
    if nargin < 3 or isempty(visDipCenter):
        visDipCenter=0.56
# /tmp/mfuncs/TF186_QubitRamseyWander.m:4
    
    if nargin < 4 or isempty(visDipWidth):
        visDipWidth=0.055
# /tmp/mfuncs/TF186_QubitRamseyWander.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF186_QubitRamseyWander.m:6
    vis=multiply((visBase - dot(0.35,x)),(1 - dot(0.78,G(x,visDipCenter,visDipWidth))))
# /tmp/mfuncs/TF186_QubitRamseyWander.m:7
    phase=dot(dot(2,pi),(dot(8,x) + dot(2.8,x ** 2))) + dot(0.55,sin(dot(dot(dot(2,pi),1.4),x)))
# /tmp/mfuncs/TF186_QubitRamseyWander.m:8
    f=multiply(vis,cos(phase))
# /tmp/mfuncs/TF186_QubitRamseyWander.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF186_QubitRamseyWander.m:10
    meta.ID = copy('TF186')
# /tmp/mfuncs/TF186_QubitRamseyWander.m:11
    meta.Name = copy('Qubit Ramsey Wander')
# /tmp/mfuncs/TF186_QubitRamseyWander.m:12
    meta.Category = copy(10)
# /tmp/mfuncs/TF186_QubitRamseyWander.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF186_QubitRamseyWander.m:14
    meta.Parameters = copy(struct('visBase',visBase,'visDipCenter',visDipCenter,'visDipWidth',visDipWidth))
# /tmp/mfuncs/TF186_QubitRamseyWander.m:15
    meta.Morphology = copy('Visibility envelope with wandering phase')
# /tmp/mfuncs/TF186_QubitRamseyWander.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    