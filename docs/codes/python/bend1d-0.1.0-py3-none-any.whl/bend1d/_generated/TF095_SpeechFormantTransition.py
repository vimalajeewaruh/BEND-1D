# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF095_SpeechFormantTransition(N=None,envC1=None,envW1=None,envC2=None,envW2=None,ph1_coef=None,ph2_coef=None,ph3_coef=None,ampScale=None,ampCenter=None,ampWidth=None,*args,**kwargs):
    varargin = TF095_SpeechFormantTransition.varargin
    nargin = TF095_SpeechFormantTransition.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:2
    
    if nargin < 2 or isempty(envC1):
        envC1=0.07
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:3
    
    if nargin < 3 or isempty(envW1):
        envW1=0.025
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:4
    
    if nargin < 4 or isempty(envC2):
        envC2=0.93
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:5
    
    if nargin < 5 or isempty(envW2):
        envW2=0.03
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:6
    
    if nargin < 6 or isempty(ph1_coef):
        ph1_coef=concat([8,7])
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:7
    
    if nargin < 7 or isempty(ph2_coef):
        ph2_coef=concat([22,- 5])
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:8
    
    if nargin < 8 or isempty(ph3_coef):
        ph3_coef=concat([38,4])
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:9
    
    if nargin < 9 or isempty(ampScale):
        ampScale=concat([0.42,0.27,0.14])
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:10
    
    if nargin < 10 or isempty(ampCenter):
        ampCenter=0.58
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:11
    
    if nargin < 11 or isempty(ampWidth):
        ampWidth=0.22
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:14
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:15
    env=sigmoid(x,envC1,envW1) - sigmoid(x,envC2,envW2)
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:16
    ph1=dot(dot(2,pi),(dot(ph1_coef(1),x) + dot(ph1_coef(2),x ** 2)))
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:17
    ph2=dot(dot(2,pi),(dot(ph2_coef(1),x) + dot(ph2_coef(2),x ** 2)))
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:18
    ph3=dot(dot(2,pi),(dot(ph3_coef(1),x) + dot(ph3_coef(2),x ** 2)))
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:19
    f=multiply(env,(dot(ampScale(1),sin(ph1)) + dot(ampScale(2),sin(ph2 + 0.3)) + dot(ampScale(3),sin(ph3 - 0.5))))
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:20
    f=multiply(f,(0.78 + dot(0.22,exp(dot(- 0.5,((x - ampCenter) / ampWidth) ** 2)))))
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:21
    meta=copy(struct)
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:22
    meta.ID = copy('TF095')
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:23
    meta.Name = copy('Speech Formant Transition')
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:24
    meta.Category = copy(6)
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:25
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:26
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:27
    meta.Morphology = copy('Formant transitions with amplitude shaping')
# /tmp/mfuncs/TF095_SpeechFormantTransition.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    