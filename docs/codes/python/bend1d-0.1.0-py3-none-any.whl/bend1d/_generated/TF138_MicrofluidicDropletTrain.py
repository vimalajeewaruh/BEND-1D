# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF138_MicrofluidicDropletTrain(N=None,baseline=None,cMD=None,aMD=None,wMD=None,*args,**kwargs):
    varargin = TF138_MicrofluidicDropletTrain.varargin
    nargin = TF138_MicrofluidicDropletTrain.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.03
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:3
    
    if nargin < 3 or isempty(cMD):
        cMD=concat([0.1,0.2,0.3,0.405,0.435,0.58,0.7,0.82,0.92])
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:4
    
    if nargin < 4 or isempty(aMD):
        aMD=concat([0.45,0.5,0.47,0.44,0.39,0.76,0.12,0.49,0.46])
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:5
    
    if nargin < 5 or isempty(wMD):
        wMD=concat([0.015,0.014,0.016,0.013,0.013,0.03,0.012,0.015,0.014])
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:8
    f=dot(baseline,ones(size(x)))
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:9
    for k in arange(1,numel(cMD)).reshape(-1):
        f=f + dot(aMD(k),exp(dot(- 0.5,((x - cMD(k)) / wMD(k)) ** 2)))
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:11
    
    meta=copy(struct)
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:13
    meta.ID = copy('TF138')
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:14
    meta.Name = copy('Microfluidic Droplet Train')
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:18
    meta.Morphology = copy('Train of Gaussian droplets on small baseline')
# /tmp/mfuncs/TF138_MicrofluidicDropletTrain.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    