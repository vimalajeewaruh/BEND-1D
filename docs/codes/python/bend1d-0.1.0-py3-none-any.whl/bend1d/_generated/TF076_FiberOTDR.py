# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF076_FiberOTDR(N=None,decay_a=None,decay_rate=None,refC=None,refA=None,refW=None,loss_amp=None,loss_ctr=None,loss_w=None,osc_amp=None,osc_f=None,*args,**kwargs):
    varargin = TF076_FiberOTDR.varargin
    nargin = TF076_FiberOTDR.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF076_FiberOTDR.m:2
    
    if nargin < 2 or isempty(decay_a):
        decay_a=1.02
# /tmp/mfuncs/TF076_FiberOTDR.m:3
    
    if nargin < 3 or isempty(decay_rate):
        decay_rate=1.25
# /tmp/mfuncs/TF076_FiberOTDR.m:4
    
    if nargin < 4 or isempty(refC):
        refC=concat([0.17,0.43,0.69,0.865])
# /tmp/mfuncs/TF076_FiberOTDR.m:5
    
    if nargin < 5 or isempty(refA):
        refA=concat([0.08,0.14,0.24,0.11])
# /tmp/mfuncs/TF076_FiberOTDR.m:6
    
    if nargin < 6 or isempty(refW):
        refW=concat([0.0035,0.0045,0.003,0.004])
# /tmp/mfuncs/TF076_FiberOTDR.m:7
    
    if nargin < 7 or isempty(loss_amp):
        loss_amp=- 0.18
# /tmp/mfuncs/TF076_FiberOTDR.m:8
    
    if nargin < 8 or isempty(loss_ctr):
        loss_ctr=0.705
# /tmp/mfuncs/TF076_FiberOTDR.m:9
    
    if nargin < 9 or isempty(loss_w):
        loss_w=0.0025
# /tmp/mfuncs/TF076_FiberOTDR.m:10
    
    if nargin < 10 or isempty(osc_amp):
        osc_amp=0.01
# /tmp/mfuncs/TF076_FiberOTDR.m:11
    
    if nargin < 11 or isempty(osc_f):
        osc_f=4
# /tmp/mfuncs/TF076_FiberOTDR.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF076_FiberOTDR.m:14
    f=dot(decay_a,exp(dot(- decay_rate,x)))
# /tmp/mfuncs/TF076_FiberOTDR.m:15
    for k in arange(1,numel(refC)).reshape(-1):
        f=f + dot(refA(k),exp(dot(- 0.5,((x - refC(k)) / refW(k)) ** 2)))
# /tmp/mfuncs/TF076_FiberOTDR.m:17
    
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF076_FiberOTDR.m:19
    lossStep=dot(loss_amp,sigmoid(x,loss_ctr,loss_w))
# /tmp/mfuncs/TF076_FiberOTDR.m:20
    f=f + lossStep + dot(osc_amp,sin(dot(dot(dot(2,pi),osc_f),x)))
# /tmp/mfuncs/TF076_FiberOTDR.m:21
    meta=copy(struct)
# /tmp/mfuncs/TF076_FiberOTDR.m:22
    meta.ID = copy('TF076')
# /tmp/mfuncs/TF076_FiberOTDR.m:23
    meta.Name = copy('Fiber OTDR')
# /tmp/mfuncs/TF076_FiberOTDR.m:24
    meta.Category = copy(6)
# /tmp/mfuncs/TF076_FiberOTDR.m:25
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF076_FiberOTDR.m:26
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF076_FiberOTDR.m:27
    meta.Morphology = copy('Exponential decay with localized reflections and loss step')
# /tmp/mfuncs/TF076_FiberOTDR.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    