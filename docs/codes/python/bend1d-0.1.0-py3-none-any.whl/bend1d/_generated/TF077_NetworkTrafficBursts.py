# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF077_NetworkTrafficBursts(N=None,base_a=None,base_b=None,base_c=None,broad_params=None,cNT=None,aNT=None,wNT=None,*args,**kwargs):
    varargin = TF077_NetworkTrafficBursts.varargin
    nargin = TF077_NetworkTrafficBursts.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=0.25
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:3
    
    if nargin < 3 or isempty(base_b):
        base_b=0.08
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:4
    
    if nargin < 4 or isempty(base_c):
        base_c=0.045
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:5
    
    if nargin < 5 or isempty(broad_params):
        broad_params=struct('a1',0.28,'c1',0.2,'w1',0.012,'c2',0.4,'w2',0.018,'a2',0.34,'c3',0.57,'w3',0.015,'c4',0.83,'w4',0.02)
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:7
    
    if nargin < 6 or isempty(cNT):
        cNT=concat([0.235,0.275,0.338,0.615,0.658,0.705,0.774])
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:10
    
    if nargin < 7 or isempty(aNT):
        aNT=concat([0.18,0.11,0.21,0.16,0.25,0.14,0.22])
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:11
    
    if nargin < 8 or isempty(wNT):
        wNT=concat([0.009,0.006,0.01,0.008,0.011,0.006,0.009])
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:14
    baseNT=base_a + dot(base_b,sin(dot(dot(dot(2,pi),2),x))) + dot(base_c,x)
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:15
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:16
    broadNT=dot(broad_params.a1,(sigmoid(x,broad_params.c1,broad_params.w1) - sigmoid(x,broad_params.c2,broad_params.w2))) + dot(broad_params.a2,(sigmoid(x,broad_params.c3,broad_params.w3) - sigmoid(x,broad_params.c4,broad_params.w4)))
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:17
    f=baseNT + broadNT
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:19
    for k in arange(1,numel(cNT)).reshape(-1):
        f=f + dot(aNT(k),exp(dot(- 0.5,((x - cNT(k)) / wNT(k)) ** 2)))
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:21
    
    meta=copy(struct)
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:23
    meta.ID = copy('TF077')
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:24
    meta.Name = copy('Network Traffic Bursts')
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:25
    meta.Category = copy(6)
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:28
    meta.Morphology = copy('Baseline trend with broad bursts and narrow spikes')
# /tmp/mfuncs/TF077_NetworkTrafficBursts.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    