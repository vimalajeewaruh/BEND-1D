# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF094_ChordBeating(N=None,envC1=None,envW1=None,envC2=None,envW2=None,a1=None,a2=None,a3=None,f1=None,f2=None,f3=None,phi2=None,phi3=None,*args,**kwargs):
    varargin = TF094_ChordBeating.varargin
    nargin = TF094_ChordBeating.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF094_ChordBeating.m:2
    
    if nargin < 2 or isempty(envC1):
        envC1=0.1
# /tmp/mfuncs/TF094_ChordBeating.m:3
    
    if nargin < 3 or isempty(envW1):
        envW1=0.03
# /tmp/mfuncs/TF094_ChordBeating.m:4
    
    if nargin < 4 or isempty(envC2):
        envC2=0.9
# /tmp/mfuncs/TF094_ChordBeating.m:5
    
    if nargin < 5 or isempty(envW2):
        envW2=0.04
# /tmp/mfuncs/TF094_ChordBeating.m:6
    
    if nargin < 6 or isempty(a1):
        a1=0.42
# /tmp/mfuncs/TF094_ChordBeating.m:7
    
    if nargin < 7 or isempty(a2):
        a2=0.39
# /tmp/mfuncs/TF094_ChordBeating.m:8
    
    if nargin < 8 or isempty(a3):
        a3=0.23
# /tmp/mfuncs/TF094_ChordBeating.m:9
    
    if nargin < 9 or isempty(f1):
        f1=27
# /tmp/mfuncs/TF094_ChordBeating.m:10
    
    if nargin < 10 or isempty(f2):
        f2=29
# /tmp/mfuncs/TF094_ChordBeating.m:11
    
    if nargin < 11 or isempty(f3):
        f3=41
# /tmp/mfuncs/TF094_ChordBeating.m:12
    
    if nargin < 12 or isempty(phi2):
        phi2=0.2
# /tmp/mfuncs/TF094_ChordBeating.m:13
    
    if nargin < 13 or isempty(phi3):
        phi3=- 0.4
# /tmp/mfuncs/TF094_ChordBeating.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF094_ChordBeating.m:16
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF094_ChordBeating.m:17
    env=sigmoid(x,envC1,envW1) - sigmoid(x,envC2,envW2)
# /tmp/mfuncs/TF094_ChordBeating.m:18
    f=multiply(env,(dot(a1,sin(dot(dot(dot(2,pi),f1),x))) + dot(a2,sin(dot(dot(dot(2,pi),f2),x) + phi2)) + dot(a3,sin(dot(dot(dot(2,pi),f3),x) + phi3))))
# /tmp/mfuncs/TF094_ChordBeating.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF094_ChordBeating.m:20
    meta.ID = copy('TF094')
# /tmp/mfuncs/TF094_ChordBeating.m:21
    meta.Name = copy('Chord Beating')
# /tmp/mfuncs/TF094_ChordBeating.m:22
    meta.Category = copy(6)
# /tmp/mfuncs/TF094_ChordBeating.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF094_ChordBeating.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF094_ChordBeating.m:25
    meta.Morphology = copy('Beating chords under an envelope')
# /tmp/mfuncs/TF094_ChordBeating.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    