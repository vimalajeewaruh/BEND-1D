# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF075_MeltPoolInstability(N=None,thermal_a=None,thermal_b=None,thermal_c=None,osc_a0=None,osc_a1=None,osc_f=None,osc_f2=None,spatter_a1=None,spatter_a2=None,spatter_c1=None,spatter_c2=None,spatter_w1=None,spatter_w2=None,trans_a=None,trans_c1=None,trans_w1=None,trans_c2=None,trans_w2=None,*args,**kwargs):
    varargin = TF075_MeltPoolInstability.varargin
    nargin = TF075_MeltPoolInstability.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF075_MeltPoolInstability.m:2
    
    if nargin < 2 or isempty(thermal_a):
        thermal_a=0.35
# /tmp/mfuncs/TF075_MeltPoolInstability.m:3
    
    if nargin < 3 or isempty(thermal_b):
        thermal_b=0.28
# /tmp/mfuncs/TF075_MeltPoolInstability.m:4
    
    if nargin < 4 or isempty(thermal_c):
        thermal_c=- 0.1
# /tmp/mfuncs/TF075_MeltPoolInstability.m:5
    
    if nargin < 5 or isempty(osc_a0):
        osc_a0=0.025
# /tmp/mfuncs/TF075_MeltPoolInstability.m:6
    
    if nargin < 6 or isempty(osc_a1):
        osc_a1=0.035
# /tmp/mfuncs/TF075_MeltPoolInstability.m:7
    
    if nargin < 7 or isempty(osc_f):
        osc_f=8
# /tmp/mfuncs/TF075_MeltPoolInstability.m:8
    
    if nargin < 8 or isempty(osc_f2):
        osc_f2=3
# /tmp/mfuncs/TF075_MeltPoolInstability.m:9
    
    if nargin < 9 or isempty(spatter_a1):
        spatter_a1=0.52
# /tmp/mfuncs/TF075_MeltPoolInstability.m:10
    
    if nargin < 10 or isempty(spatter_a2):
        spatter_a2=- 0.2
# /tmp/mfuncs/TF075_MeltPoolInstability.m:11
    
    if nargin < 11 or isempty(spatter_c1):
        spatter_c1=0.61
# /tmp/mfuncs/TF075_MeltPoolInstability.m:12
    
    if nargin < 12 or isempty(spatter_c2):
        spatter_c2=0.635
# /tmp/mfuncs/TF075_MeltPoolInstability.m:13
    
    if nargin < 13 or isempty(spatter_w1):
        spatter_w1=0.01
# /tmp/mfuncs/TF075_MeltPoolInstability.m:14
    
    if nargin < 14 or isempty(spatter_w2):
        spatter_w2=0.016
# /tmp/mfuncs/TF075_MeltPoolInstability.m:15
    
    if nargin < 15 or isempty(trans_a):
        trans_a=0.12
# /tmp/mfuncs/TF075_MeltPoolInstability.m:16
    
    if nargin < 16 or isempty(trans_c1):
        trans_c1=0.72
# /tmp/mfuncs/TF075_MeltPoolInstability.m:17
    
    if nargin < 17 or isempty(trans_w1):
        trans_w1=0.012
# /tmp/mfuncs/TF075_MeltPoolInstability.m:18
    
    if nargin < 18 or isempty(trans_c2):
        trans_c2=0.86
# /tmp/mfuncs/TF075_MeltPoolInstability.m:19
    
    if nargin < 19 or isempty(trans_w2):
        trans_w2=0.018
# /tmp/mfuncs/TF075_MeltPoolInstability.m:20
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF075_MeltPoolInstability.m:22
    thermalMP=thermal_a + dot(thermal_b,x) + dot(thermal_c,x ** 2)
# /tmp/mfuncs/TF075_MeltPoolInstability.m:23
    oscMP=multiply((osc_a0 + dot(osc_a1,x)),sin(dot(dot(2,pi),(dot(osc_f,x) + dot(osc_f2,x ** 2)))))
# /tmp/mfuncs/TF075_MeltPoolInstability.m:24
    spatterMP=dot(spatter_a1,exp(dot(- 0.5,((x - spatter_c1) / spatter_w1) ** 2))) + dot(spatter_a2,exp(dot(- 0.5,((x - spatter_c2) / spatter_w2) ** 2)))
# /tmp/mfuncs/TF075_MeltPoolInstability.m:25
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF075_MeltPoolInstability.m:26
    transitionMP=dot(trans_a,(sigmoid(x,trans_c1,trans_w1) - sigmoid(x,trans_c2,trans_w2)))
# /tmp/mfuncs/TF075_MeltPoolInstability.m:27
    f=thermalMP + oscMP + spatterMP + transitionMP
# /tmp/mfuncs/TF075_MeltPoolInstability.m:28
    meta=copy(struct)
# /tmp/mfuncs/TF075_MeltPoolInstability.m:29
    meta.ID = copy('TF075')
# /tmp/mfuncs/TF075_MeltPoolInstability.m:30
    meta.Name = copy('Melt Pool Instability')
# /tmp/mfuncs/TF075_MeltPoolInstability.m:31
    meta.Category = copy(6)
# /tmp/mfuncs/TF075_MeltPoolInstability.m:32
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF075_MeltPoolInstability.m:33
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF075_MeltPoolInstability.m:34
    meta.Morphology = copy('Thermal trend, oscillation, spatter peaks and transition')
# /tmp/mfuncs/TF075_MeltPoolInstability.m:35
    return x,f,meta
    
if __name__ == '__main__':
    pass
    