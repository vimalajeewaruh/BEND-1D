# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF003_StickSlip(N=None,b=None,h=None,*args,**kwargs):
    varargin = TF003_StickSlip.varargin
    nargin = TF003_StickSlip.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF003_StickSlip.m:2
    
    if nargin < 2 or isempty(b):
        b=concat([0.0,0.16,0.34,0.52,0.73,1.0])
# /tmp/mfuncs/TF003_StickSlip.m:3
    
    if nargin < 3 or isempty(h):
        h=concat([0.8,1.15,0.75,1.35,0.95])
# /tmp/mfuncs/TF003_StickSlip.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF003_StickSlip.m:5
    f=zeros(size(x))
# /tmp/mfuncs/TF003_StickSlip.m:6
    for k in arange(1,numel(h)).reshape(-1):
        if k < numel(h):
            ind=logical_and((x >= b(k)),(x < b(k + 1)))
# /tmp/mfuncs/TF003_StickSlip.m:9
        else:
            ind=logical_and((x >= b(k)),(x <= b(k + 1)))
# /tmp/mfuncs/TF003_StickSlip.m:11
        f[ind]=multiply(h(k),(x(ind) - b(k))) / (b(k + 1) - b(k))
# /tmp/mfuncs/TF003_StickSlip.m:13
    
    f[end()]=0
# /tmp/mfuncs/TF003_StickSlip.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF003_StickSlip.m:16
    meta.ID = copy('TF003')
# /tmp/mfuncs/TF003_StickSlip.m:17
    meta.Name = copy('Stick-Slip')
# /tmp/mfuncs/TF003_StickSlip.m:18
    meta.Category = copy(2)
# /tmp/mfuncs/TF003_StickSlip.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF003_StickSlip.m:20
    meta.Parameters = copy(struct('b',b,'h',h))
# /tmp/mfuncs/TF003_StickSlip.m:21
    meta.Morphology = copy('Piecewise-linear segments with abrupt changes')
# /tmp/mfuncs/TF003_StickSlip.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    