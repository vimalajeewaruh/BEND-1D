# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF121_CuspChirpStep(N=None,cuspAmp=None,chirpAmp=None,chirpA=None,chirpB=None,stepAmp=None,stepC=None,stepW=None,trendAmp=None,*args,**kwargs):
    varargin = TF121_CuspChirpStep.varargin
    nargin = TF121_CuspChirpStep.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF121_CuspChirpStep.m:2
    
    if nargin < 2 or isempty(cuspAmp):
        cuspAmp=0.45
# /tmp/mfuncs/TF121_CuspChirpStep.m:3
    
    if nargin < 3 or isempty(chirpAmp):
        chirpAmp=0.22
# /tmp/mfuncs/TF121_CuspChirpStep.m:4
    
    if nargin < 4 or isempty(chirpA):
        chirpA=8
# /tmp/mfuncs/TF121_CuspChirpStep.m:5
    
    if nargin < 5 or isempty(chirpB):
        chirpB=18
# /tmp/mfuncs/TF121_CuspChirpStep.m:6
    
    if nargin < 6 or isempty(stepAmp):
        stepAmp=0.28
# /tmp/mfuncs/TF121_CuspChirpStep.m:7
    
    if nargin < 7 or isempty(stepC):
        stepC=0.68
# /tmp/mfuncs/TF121_CuspChirpStep.m:8
    
    if nargin < 8 or isempty(stepW):
        stepW=0.004
# /tmp/mfuncs/TF121_CuspChirpStep.m:9
    
    if nargin < 9 or isempty(trendAmp):
        trendAmp=0.1
# /tmp/mfuncs/TF121_CuspChirpStep.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF121_CuspChirpStep.m:12
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF121_CuspChirpStep.m:13
    cusp=dot(cuspAmp,sqrt(abs(x - 0.3)))
# /tmp/mfuncs/TF121_CuspChirpStep.m:14
    chirp=dot(chirpAmp,sin(dot(dot(2,pi),(dot(chirpA,x) + dot(chirpB,x ** 2)))))
# /tmp/mfuncs/TF121_CuspChirpStep.m:15
    step=dot(stepAmp,S(x,stepC,stepW))
# /tmp/mfuncs/TF121_CuspChirpStep.m:16
    trend=dot(trendAmp,x)
# /tmp/mfuncs/TF121_CuspChirpStep.m:17
    f=cusp + chirp + step + trend
# /tmp/mfuncs/TF121_CuspChirpStep.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF121_CuspChirpStep.m:19
    meta.ID = copy('TF121')
# /tmp/mfuncs/TF121_CuspChirpStep.m:20
    meta.Name = copy('Cusp Chirp Step')
# /tmp/mfuncs/TF121_CuspChirpStep.m:21
    meta.Category = copy(6)
# /tmp/mfuncs/TF121_CuspChirpStep.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF121_CuspChirpStep.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF121_CuspChirpStep.m:24
    meta.Morphology = copy('Cusp-like baseline with chirp and step')
# /tmp/mfuncs/TF121_CuspChirpStep.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    