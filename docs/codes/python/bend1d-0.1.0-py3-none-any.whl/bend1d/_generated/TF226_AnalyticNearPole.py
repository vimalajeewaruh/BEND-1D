# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF226_AnalyticNearPole(N=None,xc=None,width=None,*args,**kwargs):
    varargin = TF226_AnalyticNearPole.varargin
    nargin = TF226_AnalyticNearPole.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF226_AnalyticNearPole.m:2
    
    if nargin < 2 or isempty(xc):
        xc=0.52
# /tmp/mfuncs/TF226_AnalyticNearPole.m:3
    
    if nargin < 3 or isempty(width):
        width=0.015
# /tmp/mfuncs/TF226_AnalyticNearPole.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF226_AnalyticNearPole.m:5
    raw=1.0 / ((x - xc) ** 2 + width ** 2)
# /tmp/mfuncs/TF226_AnalyticNearPole.m:6
    f=raw / max(raw)
# /tmp/mfuncs/TF226_AnalyticNearPole.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF226_AnalyticNearPole.m:8
    meta.ID = copy('TF226')
# /tmp/mfuncs/TF226_AnalyticNearPole.m:9
    meta.Name = copy('Analytic Near-Pole')
# /tmp/mfuncs/TF226_AnalyticNearPole.m:10
    meta.Category = copy(12)
# /tmp/mfuncs/TF226_AnalyticNearPole.m:11
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF226_AnalyticNearPole.m:12
    meta.Parameters = copy(struct('xc',xc,'width',width))
# /tmp/mfuncs/TF226_AnalyticNearPole.m:13
    meta.Morphology = copy('Normalized sharp peak from near-pole singularity')
# /tmp/mfuncs/TF226_AnalyticNearPole.m:14
    return x,f,meta
    
if __name__ == '__main__':
    pass
    