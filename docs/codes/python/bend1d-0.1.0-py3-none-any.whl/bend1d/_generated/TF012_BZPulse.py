# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF012_BZPulse(N=None,*args,**kwargs):
    varargin = TF012_BZPulse.varargin
    nargin = TF012_BZPulse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF012_BZPulse.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF012_BZPulse.m:3
    riseBZ=1 / (1 + exp(dot(- 100,(x - 0.25))))
# /tmp/mfuncs/TF012_BZPulse.m:4
    fallBZ=1 / (1 + exp(dot(- 40,(x - 0.55))))
# /tmp/mfuncs/TF012_BZPulse.m:5
    u=max(x - 0.55,0)
# /tmp/mfuncs/TF012_BZPulse.m:6
    relaxBZ=multiply(multiply(dot(0.2,(x >= 0.55)),exp(dot(- 9,u))),sin(dot(dot(45,pi),u)))
# /tmp/mfuncs/TF012_BZPulse.m:7
    f=riseBZ - fallBZ + relaxBZ
# /tmp/mfuncs/TF012_BZPulse.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF012_BZPulse.m:9
    meta.ID = copy('TF012')
# /tmp/mfuncs/TF012_BZPulse.m:10
    meta.Name = copy('BZ Pulse')
# /tmp/mfuncs/TF012_BZPulse.m:11
    meta.Category = copy(11)
# /tmp/mfuncs/TF012_BZPulse.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF012_BZPulse.m:13
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF012_BZPulse.m:14
    meta.Morphology = copy('Excitable pulse with damped relaxation')
# /tmp/mfuncs/TF012_BZPulse.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    