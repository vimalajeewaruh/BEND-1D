# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF227_ChirpCuspCollision(N=None,xc=None,pow1=None,pow2=None,chirpAmp=None,chirpScale=None,chirpOffset=None,*args,**kwargs):
    varargin = TF227_ChirpCuspCollision.varargin
    nargin = TF227_ChirpCuspCollision.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:2
    
    if nargin < 2 or isempty(xc):
        xc=0.52
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:3
    
    if nargin < 3 or isempty(pow1):
        pow1=0.5
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:4
    
    if nargin < 4 or isempty(pow2):
        pow2=1 / 3
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:5
    
    if nargin < 5 or isempty(chirpAmp):
        chirpAmp=0.48
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:6
    
    if nargin < 6 or isempty(chirpScale):
        chirpScale=0.18
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:7
    
    if nargin < 7 or isempty(chirpOffset):
        chirpOffset=0.004
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:9
    u=x - xc
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:10
    au=abs(u)
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:10
    f=au ** pow1 + multiply(dot(chirpAmp,au ** pow2),sin(chirpScale / (au + chirpOffset)))
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:11
    f=f - mean(f)
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:12
    f=f / max(abs(f))
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:14
    meta.ID = copy('TF227')
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:15
    meta.Name = copy('Chirp-Cusp Collision')
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:16
    meta.Category = copy(12)
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:18
    meta.Parameters = copy(struct('xc',xc,'pow1',pow1,'pow2',pow2,'chirpAmp',chirpAmp,'chirpScale',chirpScale,'chirpOffset',chirpOffset))
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:19
    meta.Morphology = copy('Cusp with embedded short-scale chirp')
# /tmp/mfuncs/TF227_ChirpCuspCollision.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    