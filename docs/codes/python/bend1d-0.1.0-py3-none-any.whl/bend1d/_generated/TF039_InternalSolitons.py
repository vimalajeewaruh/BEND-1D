# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF039_InternalSolitons(N=None,baseOsc=None,solCenter=None,solAmp=None,solWidth=None,*args,**kwargs):
    varargin = TF039_InternalSolitons.varargin
    nargin = TF039_InternalSolitons.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF039_InternalSolitons.m:2
    
    if nargin < 2 or isempty(baseOsc):
        baseOsc=0.025
# /tmp/mfuncs/TF039_InternalSolitons.m:3
    
    if nargin < 3 or isempty(solCenter):
        solCenter=concat([0.28,0.405,0.515,0.612,0.7])
# /tmp/mfuncs/TF039_InternalSolitons.m:4
    
    if nargin < 4 or isempty(solAmp):
        solAmp=concat([1.0,0.78,0.61,0.47,0.34])
# /tmp/mfuncs/TF039_InternalSolitons.m:5
    
    if nargin < 5 or isempty(solWidth):
        solWidth=concat([0.028,0.024,0.022,0.02,0.018])
# /tmp/mfuncs/TF039_InternalSolitons.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF039_InternalSolitons.m:7
    if isscalar(baseOsc):
        f=dot(baseOsc,sin(dot(dot(dot(2,pi),1.2),x)))
# /tmp/mfuncs/TF039_InternalSolitons.m:9
    else:
        baseOsc=interp1(linspace(0,1,numel(baseOsc)),baseOsc,x,'linear',baseOsc(end()))
# /tmp/mfuncs/TF039_InternalSolitons.m:11
        f=multiply(baseOsc,sin(dot(dot(dot(2,pi),1.2),x)))
# /tmp/mfuncs/TF039_InternalSolitons.m:12
    
    nc=numel(solCenter)
# /tmp/mfuncs/TF039_InternalSolitons.m:14
    for k in arange(1,nc).reshape(-1):
        u=(x - solCenter(k)) / solWidth(k)
# /tmp/mfuncs/TF039_InternalSolitons.m:16
        f=f - solAmp(k) / (cosh(u) ** 2)
# /tmp/mfuncs/TF039_InternalSolitons.m:17
    
    meta=copy(struct)
# /tmp/mfuncs/TF039_InternalSolitons.m:19
    meta.ID = copy('TF039')
# /tmp/mfuncs/TF039_InternalSolitons.m:20
    meta.Name = copy('Internal Solitons')
# /tmp/mfuncs/TF039_InternalSolitons.m:21
    meta.Category = copy(3)
# /tmp/mfuncs/TF039_InternalSolitons.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF039_InternalSolitons.m:23
    meta.Parameters = copy(struct('baseOsc',baseOsc,'solCenter',solCenter,'solAmp',solAmp,'solWidth',solWidth))
# /tmp/mfuncs/TF039_InternalSolitons.m:24
    meta.Morphology = copy('Deep-ocean internal solitary-wave packet (negative sech^2 pulses)')
# /tmp/mfuncs/TF039_InternalSolitons.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    