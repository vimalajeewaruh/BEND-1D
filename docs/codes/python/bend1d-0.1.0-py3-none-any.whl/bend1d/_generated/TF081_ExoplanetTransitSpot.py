# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF081_ExoplanetTransitSpot(N=None,base_amp=None,base_freq=None,transit_c=None,transit_w=None,bottom_depth=None,limb_amp=None,limb_pos1=None,limb_pos2=None,spot_amp=None,spot_pos=None,spot_w=None,*args,**kwargs):
    varargin = TF081_ExoplanetTransitSpot.varargin
    nargin = TF081_ExoplanetTransitSpot.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:2
    
    if nargin < 2 or isempty(base_amp):
        base_amp=0.012
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:3
    
    if nargin < 3 or isempty(base_freq):
        base_freq=1.2
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:4
    
    if nargin < 4 or isempty(transit_c):
        transit_c=0.51
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:5
    
    if nargin < 5 or isempty(transit_w):
        transit_w=0.17
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:6
    
    if nargin < 6 or isempty(bottom_depth):
        bottom_depth=0.2
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:7
    
    if nargin < 7 or isempty(limb_amp):
        limb_amp=0.035
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:8
    
    if nargin < 8 or isempty(limb_pos1):
        limb_pos1=0.37
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:9
    
    if nargin < 9 or isempty(limb_pos2):
        limb_pos2=0.65
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:10
    
    if nargin < 10 or isempty(spot_amp):
        spot_amp=0.05
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:11
    
    if nargin < 11 or isempty(spot_pos):
        spot_pos=0.535
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:12
    
    if nargin < 12 or isempty(spot_w):
        spot_w=0.016
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:15
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:16
    baselineET=1.0 + dot(base_amp,sin(dot(dot(dot(2,pi),base_freq),x)))
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:17
    transitWin=sigmoid(x,transit_c,transit_w) - sigmoid(x,transit_c + dot(transit_w,2),transit_w)
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:18
    
    bottomET=dot(- bottom_depth,transitWin)
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:19
    limbET=dot(- limb_amp,exp(dot(- 0.5,((x - limb_pos1) / 0.022) ** 2))) - dot(limb_amp,exp(dot(- 0.5,((x - limb_pos2) / 0.022) ** 2)))
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:20
    spotET=dot(spot_amp,exp(dot(- 0.5,((x - spot_pos) / spot_w) ** 2)))
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:21
    f=baselineET + bottomET + limbET + spotET
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:22
    meta=copy(struct)
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:23
    meta.ID = copy('TF081')
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:24
    meta.Name = copy('Exoplanet Transit with Spot Crossing')
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:25
    meta.Category = copy(6)
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:28
    meta.Morphology = copy('Transit baseline with limb effects and spot crossing')
# /tmp/mfuncs/TF081_ExoplanetTransitSpot.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    