# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF058_Chromatogram(N=None,baseline_slope=None,baseline_intercept=None,pkC=None,pkA=None,pkW=None,tail_a=None,tail_start=None,tail_k=None,*args,**kwargs):
    varargin = TF058_Chromatogram.varargin
    nargin = TF058_Chromatogram.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF058_Chromatogram.m:2
    
    if nargin < 2 or isempty(baseline_slope):
        baseline_slope=0.018
# /tmp/mfuncs/TF058_Chromatogram.m:3
    
    if nargin < 3 or isempty(baseline_intercept):
        baseline_intercept=0.035
# /tmp/mfuncs/TF058_Chromatogram.m:4
    
    if nargin < 4 or isempty(pkC):
        pkC=concat([0.16,0.29,0.43,0.5,0.67,0.81,0.87]).T
# /tmp/mfuncs/TF058_Chromatogram.m:5
    
    if nargin < 5 or isempty(pkA):
        pkA=concat([0.42,0.78,0.33,0.54,1.0,0.47,0.29]).T
# /tmp/mfuncs/TF058_Chromatogram.m:6
    
    if nargin < 6 or isempty(pkW):
        pkW=concat([0.012,0.018,0.011,0.022,0.016,0.02,0.013]).T
# /tmp/mfuncs/TF058_Chromatogram.m:7
    
    if nargin < 7 or isempty(tail_a):
        tail_a=0.1
# /tmp/mfuncs/TF058_Chromatogram.m:8
    
    if nargin < 8 or isempty(tail_start):
        tail_start=0.67
# /tmp/mfuncs/TF058_Chromatogram.m:9
    
    if nargin < 9 or isempty(tail_k):
        tail_k=18
# /tmp/mfuncs/TF058_Chromatogram.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF058_Chromatogram.m:12
    f=baseline_intercept + dot(baseline_slope,x)
# /tmp/mfuncs/TF058_Chromatogram.m:13
    for k in arange(1,numel(pkC)).reshape(-1):
        f=f + dot(pkA(k),exp(dot(- 0.5,((x - pkC(k)) / pkW(k)) ** 2)))
# /tmp/mfuncs/TF058_Chromatogram.m:15
    
    f=f + multiply(dot(tail_a,(x > tail_start)),exp(dot(- tail_k,(x - tail_start))))
# /tmp/mfuncs/TF058_Chromatogram.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF058_Chromatogram.m:18
    meta.ID = copy('TF058')
# /tmp/mfuncs/TF058_Chromatogram.m:19
    meta.Name = copy('Chromatogram')
# /tmp/mfuncs/TF058_Chromatogram.m:20
    meta.Category = copy(4)
# /tmp/mfuncs/TF058_Chromatogram.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF058_Chromatogram.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF058_Chromatogram.m:23
    meta.Morphology = copy('Stable baseline with unequal Gaussian-like peaks and weak tail')
# /tmp/mfuncs/TF058_Chromatogram.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 5: 59 - 70
    