# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF016_MarketCrash(N=None,xcCrash=None,*args,**kwargs):
    varargin = TF016_MarketCrash.varargin
    nargin = TF016_MarketCrash.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF016_MarketCrash.m:2
    
    if nargin < 2 or isempty(xcCrash):
        xcCrash=0.72
# /tmp/mfuncs/TF016_MarketCrash.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF016_MarketCrash.m:4
    f=zeros(size(x))
# /tmp/mfuncs/TF016_MarketCrash.m:5
    pre=x < xcCrash
# /tmp/mfuncs/TF016_MarketCrash.m:6
    dx=xcCrash - x(pre)
# /tmp/mfuncs/TF016_MarketCrash.m:7
    f[pre]=1.5 - multiply(dot(0.8,dx ** 0.42),(1 + dot(0.12,cos(dot(9,log(dx))))))
# /tmp/mfuncs/TF016_MarketCrash.m:8
    post=logical_not(pre)
# /tmp/mfuncs/TF016_MarketCrash.m:9
    uCrash=x(post) - xcCrash
# /tmp/mfuncs/TF016_MarketCrash.m:10
    crashLevel=0.92
# /tmp/mfuncs/TF016_MarketCrash.m:11
    f[post]=crashLevel + dot(0.42,(1 - exp(dot(- 8,uCrash))))
# /tmp/mfuncs/TF016_MarketCrash.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF016_MarketCrash.m:13
    meta.ID = copy('TF016')
# /tmp/mfuncs/TF016_MarketCrash.m:14
    meta.Name = copy('Market Crash')
# /tmp/mfuncs/TF016_MarketCrash.m:15
    meta.Category = copy(15)
# /tmp/mfuncs/TF016_MarketCrash.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF016_MarketCrash.m:17
    meta.Parameters = copy(struct('xcCrash',xcCrash))
# /tmp/mfuncs/TF016_MarketCrash.m:18
    meta.Morphology = copy('Log-periodic precursor, abrupt crash, smooth recovery')
# /tmp/mfuncs/TF016_MarketCrash.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 2
    