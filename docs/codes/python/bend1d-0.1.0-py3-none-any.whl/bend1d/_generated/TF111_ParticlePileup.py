# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF111_ParticlePileup(N=None,cPP=None,aPP=None,riseRate=None,decayRate=None,*args,**kwargs):
    varargin = TF111_ParticlePileup.varargin
    nargin = TF111_ParticlePileup.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF111_ParticlePileup.m:2
    
    if nargin < 2 or isempty(cPP):
        cPP=concat([0.14,0.3,0.49,0.515,0.72,0.88])
# /tmp/mfuncs/TF111_ParticlePileup.m:3
    
    if nargin < 3 or isempty(aPP):
        aPP=concat([0.35,0.58,0.85,0.7,0.5,0.27])
# /tmp/mfuncs/TF111_ParticlePileup.m:4
    
    if nargin < 4 or isempty(riseRate):
        riseRate=140
# /tmp/mfuncs/TF111_ParticlePileup.m:5
    
    if nargin < 5 or isempty(decayRate):
        decayRate=18
# /tmp/mfuncs/TF111_ParticlePileup.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF111_ParticlePileup.m:8
    f=zeros(size(x))
# /tmp/mfuncs/TF111_ParticlePileup.m:9
    for k in arange(1,numel(cPP)).reshape(-1):
        u=max(x - cPP(k),0)
# /tmp/mfuncs/TF111_ParticlePileup.m:11
        f=f + multiply(multiply(dot(aPP(k),(x >= cPP(k))),(1 - exp(dot(- riseRate,u)))),exp(dot(- decayRate,u)))
# /tmp/mfuncs/TF111_ParticlePileup.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF111_ParticlePileup.m:14
    meta.ID = copy('TF111')
# /tmp/mfuncs/TF111_ParticlePileup.m:15
    meta.Name = copy('Particle Pileup')
# /tmp/mfuncs/TF111_ParticlePileup.m:16
    meta.Category = copy(6)
# /tmp/mfuncs/TF111_ParticlePileup.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF111_ParticlePileup.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF111_ParticlePileup.m:19
    meta.Morphology = copy('Accumulating events with fast rise and decay')
# /tmp/mfuncs/TF111_ParticlePileup.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    