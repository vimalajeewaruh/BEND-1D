# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF080_TrainingLossSchedule(N=None,decay1=None,decay2=None,offsetA=None,dip1_c=None,dip1_w=None,dip2_c=None,dip2_w=None,dip3_c=None,dip3_w=None,cTL=None,aTL=None,wTL=None,*args,**kwargs):
    varargin = TF080_TrainingLossSchedule.varargin
    nargin = TF080_TrainingLossSchedule.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:2
    
    if nargin < 2 or isempty(decay1):
        decay1=5.8
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:3
    
    if nargin < 3 or isempty(decay2):
        decay2=0.65
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:4
    
    if nargin < 4 or isempty(offsetA):
        offsetA=0.065
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:5
    
    if nargin < 5 or isempty(dip1_c):
        dip1_c=0.34
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:6
    
    if nargin < 6 or isempty(dip1_w):
        dip1_w=0.006
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:7
    
    if nargin < 7 or isempty(dip2_c):
        dip2_c=0.63
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:8
    
    if nargin < 8 or isempty(dip2_w):
        dip2_w=0.006
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:9
    
    if nargin < 9 or isempty(dip3_c):
        dip3_c=0.82
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:10
    
    if nargin < 10 or isempty(dip3_w):
        dip3_w=0.006
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:11
    
    if nargin < 11 or isempty(cTL):
        cTL=concat([0.27,0.47,0.705])
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:12
    
    if nargin < 12 or isempty(aTL):
        aTL=concat([0.12,0.075,0.05])
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:13
    
    if nargin < 13 or isempty(wTL):
        wTL=concat([0.01,0.008,0.006])
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:16
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:17
    f=dot(1.35,exp(dot(- decay1,x))) + dot(0.24,exp(dot(- decay2,x))) + offsetA
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:18
    f=f - dot(0.065,sigmoid(x,dip1_c,dip1_w)) - dot(0.045,sigmoid(x,dip2_c,dip2_w)) - dot(0.028,sigmoid(x,dip3_c,dip3_w))
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:19
    for k in arange(1,numel(cTL)).reshape(-1):
        f=f + dot(aTL(k),exp(dot(- 0.5,((x - cTL(k)) / wTL(k)) ** 2)))
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:21
    
    meta=copy(struct)
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:23
    meta.ID = copy('TF080')
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:24
    meta.Name = copy('Training Loss Schedule')
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:25
    meta.Category = copy(6)
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:28
    meta.Morphology = copy('Exponential decay with localized dips and small bumps')
# /tmp/mfuncs/TF080_TrainingLossSchedule.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    