# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF093_VibratoTone(N=None,envC1=None,envW1=None,envC2=None,envW2=None,phaseBase=None,phaseVibFreq=None,phaseVibAmp=None,ampBase=None,ampModFreq=None,ampModAmp=None,*args,**kwargs):
    varargin = TF093_VibratoTone.varargin
    nargin = TF093_VibratoTone.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF093_VibratoTone.m:2
    
    if nargin < 2 or isempty(envC1):
        envC1=0.12
# /tmp/mfuncs/TF093_VibratoTone.m:3
    
    if nargin < 3 or isempty(envW1):
        envW1=0.025
# /tmp/mfuncs/TF093_VibratoTone.m:4
    
    if nargin < 4 or isempty(envC2):
        envC2=0.88
# /tmp/mfuncs/TF093_VibratoTone.m:5
    
    if nargin < 5 or isempty(envW2):
        envW2=0.035
# /tmp/mfuncs/TF093_VibratoTone.m:6
    
    if nargin < 6 or isempty(phaseBase):
        phaseBase=30
# /tmp/mfuncs/TF093_VibratoTone.m:7
    
    if nargin < 7 or isempty(phaseVibFreq):
        phaseVibFreq=5.5
# /tmp/mfuncs/TF093_VibratoTone.m:8
    
    if nargin < 8 or isempty(phaseVibAmp):
        phaseVibAmp=0.75
# /tmp/mfuncs/TF093_VibratoTone.m:9
    
    if nargin < 9 or isempty(ampBase):
        ampBase=0.72
# /tmp/mfuncs/TF093_VibratoTone.m:10
    
    if nargin < 10 or isempty(ampModFreq):
        ampModFreq=2.2
# /tmp/mfuncs/TF093_VibratoTone.m:11
    
    if nargin < 11 or isempty(ampModAmp):
        ampModAmp=0.14
# /tmp/mfuncs/TF093_VibratoTone.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF093_VibratoTone.m:14
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF093_VibratoTone.m:15
    env=sigmoid(x,envC1,envW1) - sigmoid(x,envC2,envW2)
# /tmp/mfuncs/TF093_VibratoTone.m:16
    phase=dot(dot(2,pi),(dot(phaseBase,x) + dot(phaseVibAmp,sin(dot(dot(dot(2,pi),phaseVibFreq),x)))))
# /tmp/mfuncs/TF093_VibratoTone.m:17
    amp=ampBase + dot(ampModAmp,sin(dot(dot(dot(2,pi),ampModFreq),x)))
# /tmp/mfuncs/TF093_VibratoTone.m:18
    f=multiply(multiply(env,amp),sin(phase))
# /tmp/mfuncs/TF093_VibratoTone.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF093_VibratoTone.m:20
    meta.ID = copy('TF093')
# /tmp/mfuncs/TF093_VibratoTone.m:21
    meta.Name = copy('Vibrato Tone')
# /tmp/mfuncs/TF093_VibratoTone.m:22
    meta.Category = copy(6)
# /tmp/mfuncs/TF093_VibratoTone.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF093_VibratoTone.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF093_VibratoTone.m:25
    meta.Morphology = copy('Tonal vibrato with envelope')
# /tmp/mfuncs/TF093_VibratoTone.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    