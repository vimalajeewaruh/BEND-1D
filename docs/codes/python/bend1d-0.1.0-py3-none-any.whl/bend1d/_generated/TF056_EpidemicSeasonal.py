# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF056_EpidemicSeasonal(N=None,season_base=None,season_amp=None,season_freq=None,season_phase=None,outbreak_a=None,outbreak_ctr=None,outbreak_w=None,interv_a=None,interv_k=None,interv_ctr=None,*args,**kwargs):
    varargin = TF056_EpidemicSeasonal.varargin
    nargin = TF056_EpidemicSeasonal.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:2
    
    if nargin < 2 or isempty(season_base):
        season_base=0.3
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:3
    
    if nargin < 3 or isempty(season_amp):
        season_amp=0.1
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:4
    
    if nargin < 4 or isempty(season_freq):
        season_freq=4
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:5
    
    if nargin < 5 or isempty(season_phase):
        season_phase=- 0.8
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:6
    
    if nargin < 6 or isempty(outbreak_a):
        outbreak_a=0.95
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:7
    
    if nargin < 7 or isempty(outbreak_ctr):
        outbreak_ctr=0.54
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:8
    
    if nargin < 8 or isempty(outbreak_w):
        outbreak_w=0.06
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:9
    
    if nargin < 9 or isempty(interv_a):
        interv_a=- 0.18
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:10
    
    if nargin < 10 or isempty(interv_k):
        interv_k=70
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:11
    
    if nargin < 11 or isempty(interv_ctr):
        interv_ctr=0.63
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:14
    season=season_base + dot(season_amp,sin(dot(dot(dot(2,pi),season_freq),x) + season_phase))
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:15
    outbreak=dot(outbreak_a,exp(dot(- 0.5,((x - outbreak_ctr) / outbreak_w) ** 2)))
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:16
    intervention=interv_a / (1 + exp(dot(- interv_k,(x - interv_ctr))))
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:17
    f=season + outbreak + intervention
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:19
    meta.ID = copy('TF056')
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:20
    meta.Name = copy('Epidemic Seasonal')
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:21
    meta.Category = copy(4)
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:24
    meta.Morphology = copy('Seasonal endemic background with localized outbreak and intervention decay')
# /tmp/mfuncs/TF056_EpidemicSeasonal.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    