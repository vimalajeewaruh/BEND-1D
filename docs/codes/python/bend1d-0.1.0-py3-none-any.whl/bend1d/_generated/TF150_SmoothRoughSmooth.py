# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF150_SmoothRoughSmooth(N=None,leftBase=None,leftAmp=None,leftFreq=None,roughAmp1=None,roughAmp2=None,roughAmp3=None,roughFreq1=None,roughFreq2=None,roughFreq3=None,rightBase=None,rightAmp=None,rightFreq=None,win1=None,win2=None,*args,**kwargs):
    varargin = TF150_SmoothRoughSmooth.varargin
    nargin = TF150_SmoothRoughSmooth.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:2
    
    if nargin < 2 or isempty(leftBase):
        leftBase=0.2
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:3
    
    if nargin < 3 or isempty(leftAmp):
        leftAmp=0.22
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:4
    
    if nargin < 4 or isempty(leftFreq):
        leftFreq=2
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:5
    
    if nargin < 5 or isempty(roughAmp1):
        roughAmp1=0.16
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:6
    
    if nargin < 6 or isempty(roughAmp2):
        roughAmp2=0.08
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:7
    
    if nargin < 7 or isempty(roughAmp3):
        roughAmp3=0.04
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:8
    
    if nargin < 8 or isempty(roughFreq1):
        roughFreq1=17
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:9
    
    if nargin < 9 or isempty(roughFreq2):
        roughFreq2=41
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:10
    
    if nargin < 10 or isempty(roughFreq3):
        roughFreq3=91
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:11
    
    if nargin < 11 or isempty(rightBase):
        rightBase=0.2
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:12
    
    if nargin < 12 or isempty(rightAmp):
        rightAmp=0.18
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:13
    
    if nargin < 13 or isempty(rightFreq):
        rightFreq=2
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:14
    
    if nargin < 14 or isempty(win1):
        win1=0.33
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:15
    
    if nargin < 15 or isempty(win2):
        win2=0.68
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:16
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:18
    leftSRS=leftBase + dot(leftAmp,sin(dot(dot(dot(2,pi),leftFreq),x)))
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:19
    roughWindow=S(x,win1,0.008) - S(x,win2,0.008)
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:20
    roughSRS=dot(roughAmp1,sin(dot(dot(dot(2,pi),roughFreq1),x))) + dot(roughAmp2,sin(dot(dot(dot(2,pi),roughFreq2),x) + 0.3)) + dot(roughAmp3,sin(dot(dot(dot(2,pi),roughFreq3),x) - 0.2))
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:21
    rightSRS=rightBase + dot(rightAmp,cos(dot(dot(dot(2,pi),rightFreq),(x - win2))))
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:22
    f=multiply(leftSRS,(1 - S(x,win1,0.008))) + multiply(roughWindow,(0.2 + roughSRS)) + multiply(rightSRS,S(x,win2,0.008))
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:24
    meta.ID = copy('TF150')
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:25
    meta.Name = copy('Smooth Rough Smooth')
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:26
    meta.Category = copy(9)
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:28
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:29
    meta.Morphology = copy('Transition from smooth to rough oscillations and back')
# /tmp/mfuncs/TF150_SmoothRoughSmooth.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    