# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF010_AvoidedCrossing(N=None,xcross=None,Delta=None,*args,**kwargs):
    varargin = TF010_AvoidedCrossing.varargin
    nargin = TF010_AvoidedCrossing.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF010_AvoidedCrossing.m:2
    
    if nargin < 2 or isempty(xcross):
        xcross=0.52
# /tmp/mfuncs/TF010_AvoidedCrossing.m:3
    
    if nargin < 3 or isempty(Delta):
        Delta=0.035
# /tmp/mfuncs/TF010_AvoidedCrossing.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF010_AvoidedCrossing.m:5
    f=sqrt(dot(4,(x - xcross) ** 2) + Delta ** 2)
# /tmp/mfuncs/TF010_AvoidedCrossing.m:6
    meta=copy(struct)
# /tmp/mfuncs/TF010_AvoidedCrossing.m:7
    meta.ID = copy('TF010')
# /tmp/mfuncs/TF010_AvoidedCrossing.m:8
    meta.Name = copy('Avoided Crossing')
# /tmp/mfuncs/TF010_AvoidedCrossing.m:9
    meta.Category = copy(9)
# /tmp/mfuncs/TF010_AvoidedCrossing.m:10
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF010_AvoidedCrossing.m:11
    meta.Parameters = copy(struct('xcross',xcross,'Delta',Delta))
# /tmp/mfuncs/TF010_AvoidedCrossing.m:12
    meta.Morphology = copy('Upper branch of coupled linear levels')
# /tmp/mfuncs/TF010_AvoidedCrossing.m:13
    return x,f,meta
    
if __name__ == '__main__':
    pass
    