# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF151_PeakOnPeak(N=None,amp1=None,ctr1=None,wid1=None,amp2=None,ctr2=None,wid2=None,amp3=None,ctr3=None,wid3=None,invAmp=None,invCtr=None,invWid=None,*args,**kwargs):
    varargin = TF151_PeakOnPeak.varargin
    nargin = TF151_PeakOnPeak.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF151_PeakOnPeak.m:2
    
    if nargin < 2 or isempty(amp1):
        amp1=0.75
# /tmp/mfuncs/TF151_PeakOnPeak.m:3
    
    if nargin < 3 or isempty(ctr1):
        ctr1=0.5
# /tmp/mfuncs/TF151_PeakOnPeak.m:4
    
    if nargin < 4 or isempty(wid1):
        wid1=0.18
# /tmp/mfuncs/TF151_PeakOnPeak.m:5
    
    if nargin < 5 or isempty(amp2):
        amp2=0.26
# /tmp/mfuncs/TF151_PeakOnPeak.m:6
    
    if nargin < 6 or isempty(ctr2):
        ctr2=0.58
# /tmp/mfuncs/TF151_PeakOnPeak.m:7
    
    if nargin < 7 or isempty(wid2):
        wid2=0.06
# /tmp/mfuncs/TF151_PeakOnPeak.m:8
    
    if nargin < 8 or isempty(amp3):
        amp3=0.22
# /tmp/mfuncs/TF151_PeakOnPeak.m:9
    
    if nargin < 9 or isempty(ctr3):
        ctr3=0.605
# /tmp/mfuncs/TF151_PeakOnPeak.m:10
    
    if nargin < 10 or isempty(wid3):
        wid3=0.015
# /tmp/mfuncs/TF151_PeakOnPeak.m:11
    
    if nargin < 11 or isempty(invAmp):
        invAmp=- 0.1
# /tmp/mfuncs/TF151_PeakOnPeak.m:12
    
    if nargin < 12 or isempty(invCtr):
        invCtr=0.61
# /tmp/mfuncs/TF151_PeakOnPeak.m:13
    
    if nargin < 13 or isempty(invWid):
        invWid=0.0035
# /tmp/mfuncs/TF151_PeakOnPeak.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF151_PeakOnPeak.m:16
    f=dot(amp1,exp(dot(- 0.5,((x - ctr1) / wid1) ** 2))) + dot(amp2,exp(dot(- 0.5,((x - ctr2) / wid2) ** 2))) + dot(amp3,exp(dot(- 0.5,((x - ctr3) / wid3) ** 2))) + dot(invAmp,exp(dot(- 0.5,((x - invCtr) / invWid) ** 2)))
# /tmp/mfuncs/TF151_PeakOnPeak.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF151_PeakOnPeak.m:18
    meta.ID = copy('TF151')
# /tmp/mfuncs/TF151_PeakOnPeak.m:19
    meta.Name = copy('Peak on Peak')
# /tmp/mfuncs/TF151_PeakOnPeak.m:20
    meta.Category = copy(9)
# /tmp/mfuncs/TF151_PeakOnPeak.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF151_PeakOnPeak.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF151_PeakOnPeak.m:23
    meta.Morphology = copy('Nested peaks with a small inverted spike near the summit')
# /tmp/mfuncs/TF151_PeakOnPeak.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    