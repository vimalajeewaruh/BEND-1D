# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF141_MishMashAlpha(N=None,linAmp=None,sleepAmp=None,sleepCtr=None,sleepW=None,sqrtCtr=None,expCtr=None,expW=None,sinCoeffs=None,*args,**kwargs):
    varargin = TF141_MishMashAlpha.varargin
    nargin = TF141_MishMashAlpha.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF141_MishMashAlpha.m:2
    
    if nargin < 2 or isempty(linAmp):
        linAmp=0.18
# /tmp/mfuncs/TF141_MishMashAlpha.m:3
    
    if nargin < 3 or isempty(sleepAmp):
        sleepAmp=0.25
# /tmp/mfuncs/TF141_MishMashAlpha.m:4
    
    if nargin < 4 or isempty(sleepCtr):
        sleepCtr=0.68
# /tmp/mfuncs/TF141_MishMashAlpha.m:5
    
    if nargin < 5 or isempty(sleepW):
        sleepW=0.004
# /tmp/mfuncs/TF141_MishMashAlpha.m:6
    
    if nargin < 6 or isempty(sqrtCtr):
        sqrtCtr=0.27
# /tmp/mfuncs/TF141_MishMashAlpha.m:7
    
    if nargin < 7 or isempty(expCtr):
        expCtr=0.48
# /tmp/mfuncs/TF141_MishMashAlpha.m:8
    
    if nargin < 8 or isempty(expW):
        expW=0.012
# /tmp/mfuncs/TF141_MishMashAlpha.m:9
    
    if nargin < 9 or isempty(sinCoeffs):
        sinCoeffs=concat([7,18,0.18])
# /tmp/mfuncs/TF141_MishMashAlpha.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF141_MishMashAlpha.m:12
    f=dot(linAmp,x) + dot(sleepAmp,S(x,sleepCtr,sleepW)) + dot(0.32,sqrt(abs(x - sqrtCtr))) + dot(0.22,exp(dot(- 0.5,((x - expCtr) / expW) ** 2))) + dot(0.18,sin(dot(dot(2,pi),(dot(sinCoeffs(1),x) + dot(sinCoeffs(2),x ** 2)))))
# /tmp/mfuncs/TF141_MishMashAlpha.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF141_MishMashAlpha.m:14
    meta.ID = copy('TF141')
# /tmp/mfuncs/TF141_MishMashAlpha.m:15
    meta.Name = copy('MishMash Alpha')
# /tmp/mfuncs/TF141_MishMashAlpha.m:16
    meta.Category = copy(9)
# /tmp/mfuncs/TF141_MishMashAlpha.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF141_MishMashAlpha.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF141_MishMashAlpha.m:19
    meta.Morphology = copy('Combination of trends, localized pulse and chirped oscillation')
# /tmp/mfuncs/TF141_MishMashAlpha.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    