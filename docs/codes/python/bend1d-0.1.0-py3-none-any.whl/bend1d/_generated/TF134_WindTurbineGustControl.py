# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF134_WindTurbineGustControl(N=None,baseline=None,gustFreq=None,gustAmp=None,gustOnset=None,gustDecay=None,gustOscFreq=None,localBumpCtr=None,localBumpAmp=None,localBumpW=None,*args,**kwargs):
    varargin = TF134_WindTurbineGustControl.varargin
    nargin = TF134_WindTurbineGustControl.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.25
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:3
    
    if nargin < 3 or isempty(gustFreq):
        gustFreq=6
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:4
    
    if nargin < 4 or isempty(gustAmp):
        gustAmp=0.08
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:5
    
    if nargin < 5 or isempty(gustOnset):
        gustOnset=0.5
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:6
    
    if nargin < 6 or isempty(gustDecay):
        gustDecay=9
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:7
    
    if nargin < 7 or isempty(gustOscFreq):
        gustOscFreq=15
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:8
    
    if nargin < 8 or isempty(localBumpCtr):
        localBumpCtr=0.49
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:9
    
    if nargin < 9 or isempty(localBumpAmp):
        localBumpAmp=0.48
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:10
    
    if nargin < 10 or isempty(localBumpW):
        localBumpW=0.035
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:13
    uWT=max(x - gustOnset,0)
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:14
    f=baseline + dot(gustAmp,sin(dot(dot(dot(2,pi),gustFreq),x))) + dot(0.03,sin(dot(dot(dot(2,pi),18),x))) + dot(localBumpAmp,exp(dot(- 0.5,((x - localBumpCtr) / localBumpW) ** 2))) + multiply(multiply(multiply((x >= gustOnset),0.2),exp(dot(- gustDecay,uWT))),sin(dot(dot(dot(2,pi),gustOscFreq),uWT))) + dot(0.12,S(x,0.56,0.02))
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:16
    meta.ID = copy('TF134')
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:17
    meta.Name = copy('Wind Turbine Gust Control')
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:18
    meta.Category = copy(9)
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:21
    meta.Morphology = copy('Baseline with traveling gust-induced decaying oscillation and local bump')
# /tmp/mfuncs/TF134_WindTurbineGustControl.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    