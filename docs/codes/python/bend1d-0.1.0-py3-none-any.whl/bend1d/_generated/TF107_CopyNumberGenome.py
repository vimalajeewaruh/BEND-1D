# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF107_CopyNumberGenome(N=None,base=None,oscAmp=None,oscFreq=None,steps=None,*args,**kwargs):
    varargin = TF107_CopyNumberGenome.varargin
    nargin = TF107_CopyNumberGenome.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF107_CopyNumberGenome.m:2
    
    if nargin < 2 or isempty(base):
        base=0.48
# /tmp/mfuncs/TF107_CopyNumberGenome.m:3
    
    if nargin < 3 or isempty(oscAmp):
        oscAmp=0.025
# /tmp/mfuncs/TF107_CopyNumberGenome.m:4
    
    if nargin < 4 or isempty(oscFreq):
        oscFreq=5
# /tmp/mfuncs/TF107_CopyNumberGenome.m:5
    
    if nargin < 5 or isempty(steps):
        steps=concat([0.18,0.39,0.52,0.66,0.74,0.79])
# /tmp/mfuncs/TF107_CopyNumberGenome.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF107_CopyNumberGenome.m:10
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF107_CopyNumberGenome.m:11
    f=base + dot(oscAmp,sin(dot(dot(dot(2,pi),oscFreq),x)))
# /tmp/mfuncs/TF107_CopyNumberGenome.m:12
    f=f + dot(0.2,(S(x,steps(1),0.004) - S(x,steps(2),0.004))) - dot(0.15,(S(x,steps(3),0.004) - S(x,steps(4),0.004))) + dot(0.3,(S(x,steps(5),0.003) - S(x,steps(6),0.003)))
# /tmp/mfuncs/TF107_CopyNumberGenome.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF107_CopyNumberGenome.m:14
    meta.ID = copy('TF107')
# /tmp/mfuncs/TF107_CopyNumberGenome.m:15
    meta.Name = copy('Copy Number Genome')
# /tmp/mfuncs/TF107_CopyNumberGenome.m:16
    meta.Category = copy(6)
# /tmp/mfuncs/TF107_CopyNumberGenome.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF107_CopyNumberGenome.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF107_CopyNumberGenome.m:19
    meta.Morphology = copy('Step-like copy number changes with baseline oscillation')
# /tmp/mfuncs/TF107_CopyNumberGenome.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    