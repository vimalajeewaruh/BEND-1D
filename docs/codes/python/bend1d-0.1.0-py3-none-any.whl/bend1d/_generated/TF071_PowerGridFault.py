# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF071_PowerGridFault(N=None,carrier_freq=None,amp_sag=None,spike_amp1=None,spike_ctr1=None,spike_w1=None,spike_amp2=None,spike_ctr2=None,spike_w2=None,ring_amp=None,ring_ctr=None,ring_decay=None,ring_freq=None,*args,**kwargs):
    varargin = TF071_PowerGridFault.varargin
    nargin = TF071_PowerGridFault.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF071_PowerGridFault.m:2
    
    if nargin < 2 or isempty(carrier_freq):
        carrier_freq=28
# /tmp/mfuncs/TF071_PowerGridFault.m:3
    
    if nargin < 3 or isempty(amp_sag):
        amp_sag=0.42
# /tmp/mfuncs/TF071_PowerGridFault.m:4
    
    if nargin < 4 or isempty(spike_amp1):
        spike_amp1=- 0.85
# /tmp/mfuncs/TF071_PowerGridFault.m:5
    
    if nargin < 5 or isempty(spike_ctr1):
        spike_ctr1=0.355
# /tmp/mfuncs/TF071_PowerGridFault.m:6
    
    if nargin < 6 or isempty(spike_w1):
        spike_w1=0.0028
# /tmp/mfuncs/TF071_PowerGridFault.m:7
    
    if nargin < 7 or isempty(spike_amp2):
        spike_amp2=0.48
# /tmp/mfuncs/TF071_PowerGridFault.m:8
    
    if nargin < 8 or isempty(spike_ctr2):
        spike_ctr2=0.365
# /tmp/mfuncs/TF071_PowerGridFault.m:9
    
    if nargin < 9 or isempty(spike_w2):
        spike_w2=0.0045
# /tmp/mfuncs/TF071_PowerGridFault.m:10
    
    if nargin < 10 or isempty(ring_amp):
        ring_amp=0.23
# /tmp/mfuncs/TF071_PowerGridFault.m:11
    
    if nargin < 11 or isempty(ring_ctr):
        ring_ctr=0.58
# /tmp/mfuncs/TF071_PowerGridFault.m:12
    
    if nargin < 12 or isempty(ring_decay):
        ring_decay=18
# /tmp/mfuncs/TF071_PowerGridFault.m:13
    
    if nargin < 13 or isempty(ring_freq):
        ring_freq=52
# /tmp/mfuncs/TF071_PowerGridFault.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF071_PowerGridFault.m:16
    carrierPG=sin(dot(dot(dot(2,pi),carrier_freq),x))
# /tmp/mfuncs/TF071_PowerGridFault.m:17
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF071_PowerGridFault.m:18
    sagWindow=sigmoid(x,0.35,0.003) - sigmoid(x,0.58,0.004)
# /tmp/mfuncs/TF071_PowerGridFault.m:19
    ampPG=1 - dot(amp_sag,sagWindow)
# /tmp/mfuncs/TF071_PowerGridFault.m:20
    faultImpulse=dot(spike_amp1,exp(dot(- 0.5,((x - spike_ctr1) / spike_w1) ** 2))) + dot(spike_amp2,exp(dot(- 0.5,((x - spike_ctr2) / spike_w2) ** 2)))
# /tmp/mfuncs/TF071_PowerGridFault.m:21
    uPG=max(x - ring_ctr,0)
# /tmp/mfuncs/TF071_PowerGridFault.m:22
    ringPG=multiply(multiply(multiply((x >= ring_ctr),ring_amp),exp(dot(- ring_decay,uPG))),sin(dot(dot(dot(2,pi),ring_freq),uPG)))
# /tmp/mfuncs/TF071_PowerGridFault.m:23
    f=multiply(ampPG,carrierPG) + faultImpulse + ringPG
# /tmp/mfuncs/TF071_PowerGridFault.m:24
    meta=copy(struct)
# /tmp/mfuncs/TF071_PowerGridFault.m:25
    meta.ID = copy('TF071')
# /tmp/mfuncs/TF071_PowerGridFault.m:26
    meta.Name = copy('Power Grid Fault')
# /tmp/mfuncs/TF071_PowerGridFault.m:27
    meta.Category = copy(6)
# /tmp/mfuncs/TF071_PowerGridFault.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF071_PowerGridFault.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF071_PowerGridFault.m:30
    meta.Morphology = copy('Carrier with amplitude sag, impulse fault and ringing')
# /tmp/mfuncs/TF071_PowerGridFault.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    