# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF082_PulsarProfile(N=None,base_level=None,p1_a=None,p1_c=None,p1_w=None,p2_a=None,p2_c=None,p2_w=None,p3_a=None,p3_c=None,p3_w=None,p4_a=None,p4_c=None,p4_w=None,tail_a=None,tail_rate=None,tail_c=None,*args,**kwargs):
    varargin = TF082_PulsarProfile.varargin
    nargin = TF082_PulsarProfile.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF082_PulsarProfile.m:2
    
    if nargin < 2 or isempty(base_level):
        base_level=0.015
# /tmp/mfuncs/TF082_PulsarProfile.m:3
    
    if nargin < 3 or isempty(p1_a):
        p1_a=0.14
# /tmp/mfuncs/TF082_PulsarProfile.m:4
    
    if nargin < 4 or isempty(p1_c):
        p1_c=0.18
# /tmp/mfuncs/TF082_PulsarProfile.m:5
    
    if nargin < 5 or isempty(p1_w):
        p1_w=0.01
# /tmp/mfuncs/TF082_PulsarProfile.m:6
    
    if nargin < 6 or isempty(p2_a):
        p2_a=1.0
# /tmp/mfuncs/TF082_PulsarProfile.m:7
    
    if nargin < 7 or isempty(p2_c):
        p2_c=0.31
# /tmp/mfuncs/TF082_PulsarProfile.m:8
    
    if nargin < 8 or isempty(p2_w):
        p2_w=0.014
# /tmp/mfuncs/TF082_PulsarProfile.m:9
    
    if nargin < 9 or isempty(p3_a):
        p3_a=0.34
# /tmp/mfuncs/TF082_PulsarProfile.m:10
    
    if nargin < 10 or isempty(p3_c):
        p3_c=0.345
# /tmp/mfuncs/TF082_PulsarProfile.m:11
    
    if nargin < 11 or isempty(p3_w):
        p3_w=0.027
# /tmp/mfuncs/TF082_PulsarProfile.m:12
    
    if nargin < 12 or isempty(p4_a):
        p4_a=0.42
# /tmp/mfuncs/TF082_PulsarProfile.m:13
    
    if nargin < 13 or isempty(p4_c):
        p4_c=0.72
# /tmp/mfuncs/TF082_PulsarProfile.m:14
    
    if nargin < 14 or isempty(p4_w):
        p4_w=0.02
# /tmp/mfuncs/TF082_PulsarProfile.m:15
    
    if nargin < 15 or isempty(tail_a):
        tail_a=0.16
# /tmp/mfuncs/TF082_PulsarProfile.m:16
    
    if nargin < 16 or isempty(tail_rate):
        tail_rate=20
# /tmp/mfuncs/TF082_PulsarProfile.m:17
    
    if nargin < 17 or isempty(tail_c):
        tail_c=0.31
# /tmp/mfuncs/TF082_PulsarProfile.m:18
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF082_PulsarProfile.m:20
    f=base_level + dot(p1_a,exp(dot(- 0.5,((x - p1_c) / p1_w) ** 2))) + dot(p2_a,exp(dot(- 0.5,((x - p2_c) / p2_w) ** 2))) + dot(p3_a,exp(dot(- 0.5,((x - p3_c) / p3_w) ** 2))) + dot(p4_a,exp(dot(- 0.5,((x - p4_c) / p4_w) ** 2)))
# /tmp/mfuncs/TF082_PulsarProfile.m:21
    u=max(x - tail_c,0)
# /tmp/mfuncs/TF082_PulsarProfile.m:23
    f=f + multiply(dot(tail_a,(x >= tail_c)),exp(dot(- tail_rate,u)))
# /tmp/mfuncs/TF082_PulsarProfile.m:24
    meta=copy(struct)
# /tmp/mfuncs/TF082_PulsarProfile.m:25
    meta.ID = copy('TF082')
# /tmp/mfuncs/TF082_PulsarProfile.m:26
    meta.Name = copy('Pulsar Profile')
# /tmp/mfuncs/TF082_PulsarProfile.m:27
    meta.Category = copy(6)
# /tmp/mfuncs/TF082_PulsarProfile.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF082_PulsarProfile.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF082_PulsarProfile.m:30
    meta.Morphology = copy('Multiple Gaussian peaks with exponential tail')
# /tmp/mfuncs/TF082_PulsarProfile.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    