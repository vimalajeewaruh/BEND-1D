# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF222_BubbleLogPeriodic(N=None,xc=None,preAmp=None,postScale=None,*args,**kwargs):
    varargin = TF222_BubbleLogPeriodic.varargin
    nargin = TF222_BubbleLogPeriodic.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:2
    
    if nargin < 2 or isempty(xc):
        xc=0.83
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:3
    
    if nargin < 3 or isempty(preAmp):
        preAmp=1.05
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:4
    
    if nargin < 4 or isempty(postScale):
        postScale=0.42
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:7
    pre=x < xc
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:8
    t=max(xc - x,1e-05)
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:9
    f[pre]=1 - multiply(dot(preAmp,t(pre) ** 0.55),(1 + dot(0.14,cos(dot(8.5,log(t(pre))) + 0.4))))
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:10
    u=max(x - xc,0)
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:11
    idx=logical_not(pre)
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:12
    f[idx]=0.24 + dot(postScale,(1 - exp(- u(idx) / 0.12))) + multiply(dot(0.03,sin(dot(dot(dot(2,pi),18),u(idx)))),exp(dot(- 12,u(idx))))
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:14
    meta.ID = copy('TF222')
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:15
    meta.Name = copy('Bubble Log-Periodic')
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:16
    meta.Category = copy(12)
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:18
    meta.Parameters = copy(struct('xc',xc,'preAmp',preAmp,'postScale',postScale))
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:19
    meta.Morphology = copy('Pre-crash log-periodic approach and post-crash relaxation')
# /tmp/mfuncs/TF222_BubbleLogPeriodic.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    