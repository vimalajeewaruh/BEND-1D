# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF115_HyperspectralMineral(N=None,baseSlope=None,bands=None,amps=None,width=None,*args,**kwargs):
    varargin = TF115_HyperspectralMineral.varargin
    nargin = TF115_HyperspectralMineral.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF115_HyperspectralMineral.m:2
    
    if nargin < 2 or isempty(baseSlope):
        baseSlope=concat([0.78,0.08])
# /tmp/mfuncs/TF115_HyperspectralMineral.m:3
    
    if nargin < 3 or isempty(bands):
        bands=concat([0.22,0.46,0.59,0.625,0.81])
# /tmp/mfuncs/TF115_HyperspectralMineral.m:4
    
    if nargin < 4 or isempty(amps):
        amps=concat([0.12,0.25,0.18,0.14,0.08])
# /tmp/mfuncs/TF115_HyperspectralMineral.m:5
    
    if nargin < 5 or isempty(width):
        width=concat([0.03,0.04,0.018,0.016,0.024])
# /tmp/mfuncs/TF115_HyperspectralMineral.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF115_HyperspectralMineral.m:8
    f=baseSlope(1) + dot(baseSlope(2),x)
# /tmp/mfuncs/TF115_HyperspectralMineral.m:9
    for k in arange(1,numel(bands)).reshape(-1):
        f=f - dot(amps(k),exp(dot(- 0.5,((x - bands(k)) / width(k)) ** 2)))
# /tmp/mfuncs/TF115_HyperspectralMineral.m:11
    
    meta=copy(struct)
# /tmp/mfuncs/TF115_HyperspectralMineral.m:13
    meta.ID = copy('TF115')
# /tmp/mfuncs/TF115_HyperspectralMineral.m:14
    meta.Name = copy('Hyperspectral Mineral')
# /tmp/mfuncs/TF115_HyperspectralMineral.m:15
    meta.Category = copy(6)
# /tmp/mfuncs/TF115_HyperspectralMineral.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF115_HyperspectralMineral.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF115_HyperspectralMineral.m:18
    meta.Morphology = copy('Baseline with absorption-like bands')
# /tmp/mfuncs/TF115_HyperspectralMineral.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    