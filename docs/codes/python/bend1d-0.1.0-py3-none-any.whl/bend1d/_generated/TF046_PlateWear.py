# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF046_PlateWear(N=None,w1_a=None,w1_pow=None,maint_amp=None,maint_ctr=None,wear2_amp=None,micro_amp=None,micro_freq=None,*args,**kwargs):
    varargin = TF046_PlateWear.varargin
    nargin = TF046_PlateWear.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF046_PlateWear.m:2
    
    if nargin < 2 or isempty(w1_a):
        w1_a=1.0
# /tmp/mfuncs/TF046_PlateWear.m:3
    
    if nargin < 3 or isempty(w1_pow):
        w1_pow=0.82
# /tmp/mfuncs/TF046_PlateWear.m:4
    
    if nargin < 4 or isempty(maint_amp):
        maint_amp=0.2
# /tmp/mfuncs/TF046_PlateWear.m:5
    
    if nargin < 5 or isempty(maint_ctr):
        maint_ctr=0.56
# /tmp/mfuncs/TF046_PlateWear.m:6
    
    if nargin < 6 or isempty(wear2_amp):
        wear2_amp=- 0.28
# /tmp/mfuncs/TF046_PlateWear.m:7
    
    if nargin < 7 or isempty(micro_amp):
        micro_amp=0.018
# /tmp/mfuncs/TF046_PlateWear.m:8
    
    if nargin < 8 or isempty(micro_freq):
        micro_freq=12
# /tmp/mfuncs/TF046_PlateWear.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF046_PlateWear.m:11
    wear1=w1_a - dot(0.38,x ** w1_pow)
# /tmp/mfuncs/TF046_PlateWear.m:12
    maintenance=maint_amp / (1 + exp(dot(- 160,(x - maint_ctr))))
# /tmp/mfuncs/TF046_PlateWear.m:13
    wear2=dot(wear2_amp,max(x - maint_ctr,0))
# /tmp/mfuncs/TF046_PlateWear.m:14
    microWear=multiply(dot(micro_amp,sin(dot(dot(dot(2,pi),micro_freq),x))),(1 - dot(0.4,x)))
# /tmp/mfuncs/TF046_PlateWear.m:15
    f=wear1 + maintenance + wear2 + microWear
# /tmp/mfuncs/TF046_PlateWear.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF046_PlateWear.m:17
    meta.ID = copy('TF046')
# /tmp/mfuncs/TF046_PlateWear.m:18
    meta.Name = copy('Plate Wear')
# /tmp/mfuncs/TF046_PlateWear.m:19
    meta.Category = copy(4)
# /tmp/mfuncs/TF046_PlateWear.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF046_PlateWear.m:21
    meta.Parameters = copy(struct('w1_a',w1_a,'w1_pow',w1_pow,'maint_amp',maint_amp,'maint_ctr',maint_ctr,'wear2_amp',wear2_amp,'micro_amp',micro_amp,'micro_freq',micro_freq))
# /tmp/mfuncs/TF046_PlateWear.m:22
    meta.Morphology = copy('Progressive wear with maintenance reset and renewed wear')
# /tmp/mfuncs/TF046_PlateWear.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    