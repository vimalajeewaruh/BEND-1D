# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF155_GrandMishMash(N=None,linA=None,logA=None,rootA=None,stepA1=None,stepW1=None,stepA2=None,stepW2=None,negStepA=None,negStepW=None,peakA1=None,peakCtr1=None,peakWid1=None,peakA2=None,peakCtr2=None,peakWid2=None,negPeakA=None,negPeakCtr=None,negPeakWid=None,oscA=None,oscPhaseA=None,oscWin1=None,oscWin2=None,hiOscA=None,hiOscCtr=None,hiOscWid=None,peakA3=None,peakCtr3=None,peakWid3=None,negPeakA2=None,negPeakCtr2=None,negPeakWid2=None,spikeA=None,spikeCtr=None,spikeWid=None,*args,**kwargs):
    varargin = TF155_GrandMishMash.varargin
    nargin = TF155_GrandMishMash.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF155_GrandMishMash.m:2
    
    if nargin < 2 or isempty(linA):
        linA=0.12
# /tmp/mfuncs/TF155_GrandMishMash.m:3
    
    if nargin < 3 or isempty(logA):
        logA=0.08
# /tmp/mfuncs/TF155_GrandMishMash.m:4
    
    if nargin < 4 or isempty(rootA):
        rootA=0.18
# /tmp/mfuncs/TF155_GrandMishMash.m:5
    
    if nargin < 5 or isempty(stepA1):
        stepA1=0.16
# /tmp/mfuncs/TF155_GrandMishMash.m:6
    
    if nargin < 6 or isempty(stepW1):
        stepW1=0.006
# /tmp/mfuncs/TF155_GrandMishMash.m:7
    
    if nargin < 7 or isempty(stepA2):
        stepA2=0.08
# /tmp/mfuncs/TF155_GrandMishMash.m:8
    
    if nargin < 8 or isempty(stepW2):
        stepW2=0.006
# /tmp/mfuncs/TF155_GrandMishMash.m:9
    
    if nargin < 9 or isempty(negStepA):
        negStepA=0.18
# /tmp/mfuncs/TF155_GrandMishMash.m:10
    
    if nargin < 10 or isempty(negStepW):
        negStepW=0.003
# /tmp/mfuncs/TF155_GrandMishMash.m:11
    
    if nargin < 11 or isempty(peakA1):
        peakA1=0.26
# /tmp/mfuncs/TF155_GrandMishMash.m:12
    
    if nargin < 12 or isempty(peakCtr1):
        peakCtr1=0.5
# /tmp/mfuncs/TF155_GrandMishMash.m:13
    
    if nargin < 13 or isempty(peakWid1):
        peakWid1=0.01
# /tmp/mfuncs/TF155_GrandMishMash.m:14
    
    if nargin < 14 or isempty(peakA2):
        peakA2=0.21
# /tmp/mfuncs/TF155_GrandMishMash.m:15
    
    if nargin < 15 or isempty(peakCtr2):
        peakCtr2=0.527
# /tmp/mfuncs/TF155_GrandMishMash.m:16
    
    if nargin < 16 or isempty(peakWid2):
        peakWid2=0.008
# /tmp/mfuncs/TF155_GrandMishMash.m:17
    
    if nargin < 17 or isempty(negPeakA):
        negPeakA=0.13
# /tmp/mfuncs/TF155_GrandMishMash.m:18
    
    if nargin < 18 or isempty(negPeakCtr):
        negPeakCtr=0.575
# /tmp/mfuncs/TF155_GrandMishMash.m:19
    
    if nargin < 19 or isempty(negPeakWid):
        negPeakWid=0.005
# /tmp/mfuncs/TF155_GrandMishMash.m:20
    
    if nargin < 20 or isempty(oscA):
        oscA=0.13
# /tmp/mfuncs/TF155_GrandMishMash.m:21
    
    if nargin < 21 or isempty(oscPhaseA):
        oscPhaseA=0
# /tmp/mfuncs/TF155_GrandMishMash.m:22
    
    if nargin < 22 or isempty(oscWin1):
        oscWin1=0.6
# /tmp/mfuncs/TF155_GrandMishMash.m:23
    
    if nargin < 23 or isempty(oscWin2):
        oscWin2=0.78
# /tmp/mfuncs/TF155_GrandMishMash.m:24
    
    if nargin < 24 or isempty(hiOscA):
        hiOscA=0.16
# /tmp/mfuncs/TF155_GrandMishMash.m:25
    
    if nargin < 25 or isempty(hiOscCtr):
        hiOscCtr=0.8
# /tmp/mfuncs/TF155_GrandMishMash.m:26
    
    if nargin < 26 or isempty(hiOscWid):
        hiOscWid=0.045
# /tmp/mfuncs/TF155_GrandMishMash.m:27
    
    if nargin < 27 or isempty(peakA3):
        peakA3=0.28
# /tmp/mfuncs/TF155_GrandMishMash.m:28
    
    if nargin < 28 or isempty(peakCtr3):
        peakCtr3=0.885
# /tmp/mfuncs/TF155_GrandMishMash.m:29
    
    if nargin < 29 or isempty(peakWid3):
        peakWid3=0.035
# /tmp/mfuncs/TF155_GrandMishMash.m:30
    
    if nargin < 30 or isempty(negPeakA2):
        negPeakA2=0.26
# /tmp/mfuncs/TF155_GrandMishMash.m:31
    
    if nargin < 31 or isempty(negPeakCtr2):
        negPeakCtr2=0.895
# /tmp/mfuncs/TF155_GrandMishMash.m:32
    
    if nargin < 32 or isempty(negPeakWid2):
        negPeakWid2=0.037
# /tmp/mfuncs/TF155_GrandMishMash.m:33
    
    if nargin < 33 or isempty(spikeA):
        spikeA=0.09
# /tmp/mfuncs/TF155_GrandMishMash.m:34
    
    if nargin < 34 or isempty(spikeCtr):
        spikeCtr=0.955
# /tmp/mfuncs/TF155_GrandMishMash.m:35
    
    if nargin < 35 or isempty(spikeWid):
        spikeWid=0.0028
# /tmp/mfuncs/TF155_GrandMishMash.m:36
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF155_GrandMishMash.m:38
    f=dot(linA,x) + dot(logA,log(1 + dot(6,x))) + dot(rootA,sqrt(abs(x - 0.16)))
# /tmp/mfuncs/TF155_GrandMishMash.m:39
    f=f + dot(stepA1,(S(x,0.24,stepW1) - S(x,0.36,stepW2))) - dot(negStepA,S(x,0.43,negStepW))
# /tmp/mfuncs/TF155_GrandMishMash.m:40
    f=f + dot(peakA1,exp(dot(- 0.5,((x - peakCtr1) / peakWid1) ** 2))) + dot(peakA2,exp(dot(- 0.5,((x - peakCtr2) / peakWid2) ** 2))) - dot(negPeakA,exp(dot(- 0.5,((x - negPeakCtr) / negPeakWid) ** 2)))
# /tmp/mfuncs/TF155_GrandMishMash.m:41
    f=f + multiply(dot(oscA,sin(dot(dot(2,pi),(dot(8,x) + dot(24,x ** 2))) + oscPhaseA)),(S(x,oscWin1,0.02) - S(x,oscWin2,0.02)))
# /tmp/mfuncs/TF155_GrandMishMash.m:42
    f=f + multiply(dot(hiOscA,exp(dot(- 0.5,((x - hiOscCtr) / hiOscWid) ** 2))),sin(dot(dot(dot(2,pi),55),x)))
# /tmp/mfuncs/TF155_GrandMishMash.m:43
    f=f + dot(peakA3,exp(dot(- 0.5,((x - peakCtr3) / peakWid3) ** 2))) - dot(negPeakA2,exp(dot(- 0.5,((x - negPeakCtr2) / negPeakWid2) ** 2))) + dot(spikeA,exp(dot(- 0.5,((x - spikeCtr) / spikeWid) ** 2)))
# /tmp/mfuncs/TF155_GrandMishMash.m:44
    meta=copy(struct)
# /tmp/mfuncs/TF155_GrandMishMash.m:45
    meta.ID = copy('TF155')
# /tmp/mfuncs/TF155_GrandMishMash.m:46
    meta.Name = copy('Grand MishMash')
# /tmp/mfuncs/TF155_GrandMishMash.m:47
    meta.Category = copy(9)
# /tmp/mfuncs/TF155_GrandMishMash.m:48
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF155_GrandMishMash.m:49
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF155_GrandMishMash.m:50
    meta.Morphology = copy('Highly composite signal combining trends, localized peaks, oscillations and fine spikes')
# /tmp/mfuncs/TF155_GrandMishMash.m:51
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 9: 156 - 180
    