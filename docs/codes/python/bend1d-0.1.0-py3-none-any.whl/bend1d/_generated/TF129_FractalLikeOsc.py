# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF129_FractalLikeOsc(N=None,baseAmp=None,depth=None,*args,**kwargs):
    varargin = TF129_FractalLikeOsc.varargin
    nargin = TF129_FractalLikeOsc.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF129_FractalLikeOsc.m:2
    
    if nargin < 2 or isempty(baseAmp):
        baseAmp=0.4
# /tmp/mfuncs/TF129_FractalLikeOsc.m:3
    
    if nargin < 3 or isempty(depth):
        depth=6
# /tmp/mfuncs/TF129_FractalLikeOsc.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF129_FractalLikeOsc.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF129_FractalLikeOsc.m:7
    for k in arange(1,depth).reshape(-1):
        freq=dot(2 ** (k - 1),5)
# /tmp/mfuncs/TF129_FractalLikeOsc.m:9
        amp=baseAmp / (2 ** (k - 1))
# /tmp/mfuncs/TF129_FractalLikeOsc.m:10
        phase=dot(dot(rand(),2),pi)
# /tmp/mfuncs/TF129_FractalLikeOsc.m:11
        f=f + dot(amp,sin(dot(dot(dot(2,pi),freq),x) + phase))
# /tmp/mfuncs/TF129_FractalLikeOsc.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF129_FractalLikeOsc.m:14
    meta.ID = copy('TF129')
# /tmp/mfuncs/TF129_FractalLikeOsc.m:15
    meta.Name = copy('Fractal-Like Oscillation')
# /tmp/mfuncs/TF129_FractalLikeOsc.m:16
    meta.Category = copy(8)
# /tmp/mfuncs/TF129_FractalLikeOsc.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF129_FractalLikeOsc.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF129_FractalLikeOsc.m:19
    meta.Morphology = copy('Superposition of harmonics with geometrically decaying amplitude')
# /tmp/mfuncs/TF129_FractalLikeOsc.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
