# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF223_IntradayVolatilityU(N=None,baseline=None,spikeA=None,spikeC=None,*args,**kwargs):
    varargin = TF223_IntradayVolatilityU.varargin
    nargin = TF223_IntradayVolatilityU.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.16
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:3
    
    if nargin < 3 or isempty(spikeA):
        spikeA=concat([0.18,0.1,0.12,0.2])
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:4
    
    if nargin < 4 or isempty(spikeC):
        spikeC=concat([0.08,0.32,0.71,0.93])
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:6
    f=baseline + dot(2.2,(x - 0.5) ** 2) + multiply(dot(0.025,sin(dot(dot(dot(2,pi),45),x))),(1 + dot(2.5,abs(x - 0.5))))
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:7
    c=copy(spikeC)
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:8
    a=copy(spikeA)
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:9
    w=concat([0.008,0.006,0.007,0.006])
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:10
    for k in arange(1,4).reshape(-1):
        f=f + dot(a(k),G(x,c(k),w(k)))
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:14
    meta.ID = copy('TF223')
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:15
    meta.Name = copy('Intraday Volatility U')
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:16
    meta.Category = copy(12)
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:18
    meta.Parameters = copy(struct('baseline',baseline,'spikeA',spikeA,'spikeC',spikeC))
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:19
    meta.Morphology = copy('U-shaped baseline with localized intraday spikes')
# /tmp/mfuncs/TF223_IntradayVolatilityU.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    