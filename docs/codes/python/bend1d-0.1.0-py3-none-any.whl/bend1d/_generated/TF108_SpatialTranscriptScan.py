# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF108_SpatialTranscriptScan(N=None,*args,**kwargs):
    varargin = TF108_SpatialTranscriptScan.varargin
    nargin = TF108_SpatialTranscriptScan.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:3
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:4
    f=0.18 + dot(0.2,x) + dot(0.04,sin(dot(dot(dot(2,pi),2),x)))
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:5
    f=f + dot(0.38,(S(x,0.31,0.01) - S(x,0.55,0.012))) + dot(0.24,exp(dot(- 0.5,((x - 0.72) / 0.03) ** 2))) + dot(0.08,exp(dot(- 0.5,((x - 0.8) / 0.012) ** 2)))
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:6
    meta=copy(struct)
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:7
    meta.ID = copy('TF108')
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:8
    meta.Name = copy('Spatial Transcript Scan')
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:9
    meta.Category = copy(6)
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:10
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:11
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:12
    meta.Morphology = copy('Gradual trend with localized increases and bumps')
# /tmp/mfuncs/TF108_SpatialTranscriptScan.m:13
    return x,f,meta
    
if __name__ == '__main__':
    pass
    