# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF055_Pharmacokinetic(N=None,tPK_scale=None,abs_k=None,elim_a=None,elim_b=None,elim_k1=None,elim_k2=None,secondDoseTime=None,secondDoseA=None,secondDose_onset_k=None,secondDose_decay_k=None,*args,**kwargs):
    varargin = TF055_Pharmacokinetic.varargin
    nargin = TF055_Pharmacokinetic.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF055_Pharmacokinetic.m:2
    
    if nargin < 2 or isempty(tPK_scale):
        tPK_scale=12
# /tmp/mfuncs/TF055_Pharmacokinetic.m:3
    
    if nargin < 3 or isempty(abs_k):
        abs_k=2.2
# /tmp/mfuncs/TF055_Pharmacokinetic.m:4
    
    if nargin < 4 or isempty(elim_a):
        elim_a=0.78
# /tmp/mfuncs/TF055_Pharmacokinetic.m:5
    
    if nargin < 5 or isempty(elim_b):
        elim_b=0.22
# /tmp/mfuncs/TF055_Pharmacokinetic.m:6
    
    if nargin < 6 or isempty(elim_k1):
        elim_k1=0.24
# /tmp/mfuncs/TF055_Pharmacokinetic.m:7
    
    if nargin < 7 or isempty(elim_k2):
        elim_k2=1.3
# /tmp/mfuncs/TF055_Pharmacokinetic.m:8
    
    if nargin < 8 or isempty(secondDoseTime):
        secondDoseTime=5.3
# /tmp/mfuncs/TF055_Pharmacokinetic.m:9
    
    if nargin < 9 or isempty(secondDoseA):
        secondDoseA=0.16
# /tmp/mfuncs/TF055_Pharmacokinetic.m:10
    
    if nargin < 10 or isempty(secondDose_onset_k):
        secondDose_onset_k=2.8
# /tmp/mfuncs/TF055_Pharmacokinetic.m:11
    
    if nargin < 11 or isempty(secondDose_decay_k):
        secondDose_decay_k=0.55
# /tmp/mfuncs/TF055_Pharmacokinetic.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF055_Pharmacokinetic.m:14
    tPK=dot(tPK_scale,x)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:15
    absorb=1 - exp(dot(- abs_k,tPK))
# /tmp/mfuncs/TF055_Pharmacokinetic.m:16
    elim=dot(elim_a,exp(dot(- elim_k1,tPK))) + dot(elim_b,exp(dot(- elim_k2,tPK)))
# /tmp/mfuncs/TF055_Pharmacokinetic.m:17
    f=multiply(absorb,elim)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:18
    uDose=max(tPK - secondDoseTime,0)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:19
    f=f + multiply(multiply(multiply((tPK >= secondDoseTime),secondDoseA),(1 - exp(dot(- secondDose_onset_k,uDose)))),exp(dot(- secondDose_decay_k,uDose)))
# /tmp/mfuncs/TF055_Pharmacokinetic.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:21
    meta.ID = copy('TF055')
# /tmp/mfuncs/TF055_Pharmacokinetic.m:22
    meta.Name = copy('Pharmacokinetic')
# /tmp/mfuncs/TF055_Pharmacokinetic.m:23
    meta.Category = copy(4)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF055_Pharmacokinetic.m:26
    meta.Morphology = copy('Oral-like absorption with biexponential elimination and second dose shoulder')
# /tmp/mfuncs/TF055_Pharmacokinetic.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    