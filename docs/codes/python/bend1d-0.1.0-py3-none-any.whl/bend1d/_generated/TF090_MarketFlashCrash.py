# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF090_MarketFlashCrash(N=None,preBase=None,preSlope=None,preSeason=None,crashAmp=None,crashC=None,crashW=None,reboundAmp=None,reboundC=None,reboundW=None,afterAmp=None,afterC=None,afterW=None,normAmp=None,normC=None,normRate=None,*args,**kwargs):
    varargin = TF090_MarketFlashCrash.varargin
    nargin = TF090_MarketFlashCrash.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF090_MarketFlashCrash.m:2
    
    if nargin < 2 or isempty(preBase):
        preBase=1.0
# /tmp/mfuncs/TF090_MarketFlashCrash.m:3
    
    if nargin < 3 or isempty(preSlope):
        preSlope=0.1
# /tmp/mfuncs/TF090_MarketFlashCrash.m:4
    
    if nargin < 4 or isempty(preSeason):
        preSeason=0.025
# /tmp/mfuncs/TF090_MarketFlashCrash.m:5
    
    if nargin < 5 or isempty(crashAmp):
        crashAmp=- 0.62
# /tmp/mfuncs/TF090_MarketFlashCrash.m:6
    
    if nargin < 6 or isempty(crashC):
        crashC=0.535
# /tmp/mfuncs/TF090_MarketFlashCrash.m:7
    
    if nargin < 7 or isempty(crashW):
        crashW=0.004
# /tmp/mfuncs/TF090_MarketFlashCrash.m:8
    
    if nargin < 8 or isempty(reboundAmp):
        reboundAmp=0.44
# /tmp/mfuncs/TF090_MarketFlashCrash.m:9
    
    if nargin < 9 or isempty(reboundC):
        reboundC=0.585
# /tmp/mfuncs/TF090_MarketFlashCrash.m:10
    
    if nargin < 10 or isempty(reboundW):
        reboundW=0.009
# /tmp/mfuncs/TF090_MarketFlashCrash.m:11
    
    if nargin < 11 or isempty(afterAmp):
        afterAmp=- 0.13
# /tmp/mfuncs/TF090_MarketFlashCrash.m:12
    
    if nargin < 12 or isempty(afterC):
        afterC=0.665
# /tmp/mfuncs/TF090_MarketFlashCrash.m:13
    
    if nargin < 13 or isempty(afterW):
        afterW=0.015
# /tmp/mfuncs/TF090_MarketFlashCrash.m:14
    
    if nargin < 14 or isempty(normAmp):
        normAmp=0.16
# /tmp/mfuncs/TF090_MarketFlashCrash.m:15
    
    if nargin < 15 or isempty(normC):
        normC=0.585
# /tmp/mfuncs/TF090_MarketFlashCrash.m:16
    
    if nargin < 16 or isempty(normRate):
        normRate=4.5
# /tmp/mfuncs/TF090_MarketFlashCrash.m:17
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF090_MarketFlashCrash.m:19
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF090_MarketFlashCrash.m:20
    preMF=preBase + dot(preSlope,x) + dot(preSeason,sin(dot(dot(dot(2,pi),3),x)))
# /tmp/mfuncs/TF090_MarketFlashCrash.m:21
    crashMF=dot(crashAmp,sigmoid(x,crashC,crashW))
# /tmp/mfuncs/TF090_MarketFlashCrash.m:22
    reboundMF=dot(reboundAmp,sigmoid(x,reboundC,reboundW))
# /tmp/mfuncs/TF090_MarketFlashCrash.m:23
    afterMF=dot(afterAmp,exp(dot(- 0.5,((x - afterC) / afterW) ** 2)))
# /tmp/mfuncs/TF090_MarketFlashCrash.m:24
    uMF=max(x - normC,0)
# /tmp/mfuncs/TF090_MarketFlashCrash.m:25
    normMF=multiply(multiply((x >= normC),normAmp),(1 - exp(dot(- normRate,uMF))))
# /tmp/mfuncs/TF090_MarketFlashCrash.m:26
    f=preMF + crashMF + reboundMF + afterMF + normMF
# /tmp/mfuncs/TF090_MarketFlashCrash.m:27
    meta=copy(struct)
# /tmp/mfuncs/TF090_MarketFlashCrash.m:29
    meta.ID = copy('TF090')
# /tmp/mfuncs/TF090_MarketFlashCrash.m:30
    meta.Name = copy('Market Flash Crash')
# /tmp/mfuncs/TF090_MarketFlashCrash.m:31
    meta.Category = copy(6)
# /tmp/mfuncs/TF090_MarketFlashCrash.m:32
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF090_MarketFlashCrash.m:33
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF090_MarketFlashCrash.m:34
    meta.Morphology = copy('Pre-crash trend, sharp crash, rebound and normalization')
# /tmp/mfuncs/TF090_MarketFlashCrash.m:35
    return x,f,meta
    
if __name__ == '__main__':
    pass
    