# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF143_DoubletOnCliff(N=None,cliffAmp=None,cliffCtr=None,cliffW=None,peak1Amp=None,peak1Ctr=None,peak1W=None,peak2Amp=None,peak2Ctr=None,peak2W=None,*args,**kwargs):
    varargin = TF143_DoubletOnCliff.varargin
    nargin = TF143_DoubletOnCliff.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF143_DoubletOnCliff.m:2
    
    if nargin < 2 or isempty(cliffAmp):
        cliffAmp=0.75
# /tmp/mfuncs/TF143_DoubletOnCliff.m:3
    
    if nargin < 3 or isempty(cliffCtr):
        cliffCtr=0.53
# /tmp/mfuncs/TF143_DoubletOnCliff.m:4
    
    if nargin < 4 or isempty(cliffW):
        cliffW=0.015
# /tmp/mfuncs/TF143_DoubletOnCliff.m:5
    
    if nargin < 5 or isempty(peak1Amp):
        peak1Amp=0.28
# /tmp/mfuncs/TF143_DoubletOnCliff.m:6
    
    if nargin < 6 or isempty(peak1Ctr):
        peak1Ctr=0.505
# /tmp/mfuncs/TF143_DoubletOnCliff.m:7
    
    if nargin < 7 or isempty(peak1W):
        peak1W=0.008
# /tmp/mfuncs/TF143_DoubletOnCliff.m:8
    
    if nargin < 8 or isempty(peak2Amp):
        peak2Amp=0.24
# /tmp/mfuncs/TF143_DoubletOnCliff.m:9
    
    if nargin < 9 or isempty(peak2Ctr):
        peak2Ctr=0.548
# /tmp/mfuncs/TF143_DoubletOnCliff.m:10
    
    if nargin < 10 or isempty(peak2W):
        peak2W=0.008
# /tmp/mfuncs/TF143_DoubletOnCliff.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF143_DoubletOnCliff.m:13
    f=dot(cliffAmp,S(x,cliffCtr,cliffW)) + dot(peak1Amp,exp(dot(- 0.5,((x - peak1Ctr) / peak1W) ** 2))) + dot(peak2Amp,exp(dot(- 0.5,((x - peak2Ctr) / peak2W) ** 2)))
# /tmp/mfuncs/TF143_DoubletOnCliff.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF143_DoubletOnCliff.m:15
    meta.ID = copy('TF143')
# /tmp/mfuncs/TF143_DoubletOnCliff.m:16
    meta.Name = copy('Doublet on Cliff')
# /tmp/mfuncs/TF143_DoubletOnCliff.m:17
    meta.Category = copy(9)
# /tmp/mfuncs/TF143_DoubletOnCliff.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF143_DoubletOnCliff.m:19
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF143_DoubletOnCliff.m:20
    meta.Morphology = copy('Step-like cliff with two nearby localized peaks')
# /tmp/mfuncs/TF143_DoubletOnCliff.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    