# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF135_EVFastCharge(N=None,baseline=None,firstStepCtr=None,firstStepAmp=None,firstStepW=None,secondStepCtr=None,secondStepW=None,negStepCtr=None,negStepW=None,highFreqAmp=None,highFreqFreq=None,lateStepCtr=None,lateStepW=None,*args,**kwargs):
    varargin = TF135_EVFastCharge.varargin
    nargin = TF135_EVFastCharge.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF135_EVFastCharge.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.18
# /tmp/mfuncs/TF135_EVFastCharge.m:3
    
    if nargin < 3 or isempty(firstStepCtr):
        firstStepCtr=0.2
# /tmp/mfuncs/TF135_EVFastCharge.m:4
    
    if nargin < 4 or isempty(firstStepAmp):
        firstStepAmp=0.55
# /tmp/mfuncs/TF135_EVFastCharge.m:5
    
    if nargin < 5 or isempty(firstStepW):
        firstStepW=0.1
# /tmp/mfuncs/TF135_EVFastCharge.m:6
    
    if nargin < 6 or isempty(secondStepCtr):
        secondStepCtr=0.58
# /tmp/mfuncs/TF135_EVFastCharge.m:7
    
    if nargin < 7 or isempty(secondStepW):
        secondStepW=0.035
# /tmp/mfuncs/TF135_EVFastCharge.m:8
    
    if nargin < 8 or isempty(negStepCtr):
        negStepCtr=0.72
# /tmp/mfuncs/TF135_EVFastCharge.m:9
    
    if nargin < 9 or isempty(negStepW):
        negStepW=0.01
# /tmp/mfuncs/TF135_EVFastCharge.m:10
    
    if nargin < 10 or isempty(highFreqAmp):
        highFreqAmp=0.015
# /tmp/mfuncs/TF135_EVFastCharge.m:11
    
    if nargin < 11 or isempty(highFreqFreq):
        highFreqFreq=18
# /tmp/mfuncs/TF135_EVFastCharge.m:12
    
    if nargin < 12 or isempty(lateStepCtr):
        lateStepCtr=0.88
# /tmp/mfuncs/TF135_EVFastCharge.m:13
    
    if nargin < 13 or isempty(lateStepW):
        lateStepW=0.025
# /tmp/mfuncs/TF135_EVFastCharge.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF135_EVFastCharge.m:16
    f=baseline + dot(firstStepAmp,S(x,firstStepCtr,firstStepW)) + dot(0.22,S(x,secondStepCtr,secondStepW)) - dot(0.12,S(x,negStepCtr,negStepW)) + multiply(dot(highFreqAmp,sin(dot(dot(dot(2,pi),highFreqFreq),x))),S(x,firstStepCtr,0.03)) + dot(0.07,S(x,lateStepCtr,lateStepW))
# /tmp/mfuncs/TF135_EVFastCharge.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF135_EVFastCharge.m:18
    meta.ID = copy('TF135')
# /tmp/mfuncs/TF135_EVFastCharge.m:19
    meta.Name = copy('EV Fast Charge')
# /tmp/mfuncs/TF135_EVFastCharge.m:20
    meta.Category = copy(9)
# /tmp/mfuncs/TF135_EVFastCharge.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF135_EVFastCharge.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF135_EVFastCharge.m:23
    meta.Morphology = copy('Step-like charge events with small riding high-frequency component')
# /tmp/mfuncs/TF135_EVFastCharge.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    