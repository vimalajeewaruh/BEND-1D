# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF014_ECGBeat(N=None,*args,**kwargs):
    varargin = TF014_ECGBeat.varargin
    nargin = TF014_ECGBeat.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF014_ECGBeat.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF014_ECGBeat.m:3
    f=zeros(size(x))
# /tmp/mfuncs/TF014_ECGBeat.m:4
    rCenters=concat([0.28,0.76])
# /tmp/mfuncs/TF014_ECGBeat.m:5
    beatAmp=concat([1.0,0.88])
# /tmp/mfuncs/TF014_ECGBeat.m:6
    offset=concat([- 0.15,- 0.025,0,0.025,0.16])
# /tmp/mfuncs/TF014_ECGBeat.m:7
    amp=concat([0.15,- 0.12,1.0,- 0.25,0.32])
# /tmp/mfuncs/TF014_ECGBeat.m:8
    width=concat([0.035,0.01,0.008,0.012,0.06])
# /tmp/mfuncs/TF014_ECGBeat.m:9
    for ib in arange(1,numel(rCenters)).reshape(-1):
        for iq in arange(1,5).reshape(-1):
            muq=rCenters(ib) + offset(iq)
# /tmp/mfuncs/TF014_ECGBeat.m:12
            f=f + multiply(dot(beatAmp(ib),amp(iq)),exp(dot(- 0.5,((x - muq) / width(iq)) ** 2)))
# /tmp/mfuncs/TF014_ECGBeat.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF014_ECGBeat.m:16
    meta.ID = copy('TF014')
# /tmp/mfuncs/TF014_ECGBeat.m:17
    meta.Name = copy('ECG Beat')
# /tmp/mfuncs/TF014_ECGBeat.m:18
    meta.Category = copy(13)
# /tmp/mfuncs/TF014_ECGBeat.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF014_ECGBeat.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF014_ECGBeat.m:21
    meta.Morphology = copy('Two unequal heartbeats composed of signed Gaussian components')
# /tmp/mfuncs/TF014_ECGBeat.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    