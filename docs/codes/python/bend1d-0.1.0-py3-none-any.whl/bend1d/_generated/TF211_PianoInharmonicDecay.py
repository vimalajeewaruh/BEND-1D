# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF211_PianoInharmonicDecay(N=None,u0=None,gateCenter=None,gateWidth=None,*args,**kwargs):
    varargin = TF211_PianoInharmonicDecay.varargin
    nargin = TF211_PianoInharmonicDecay.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:2
    
    if nargin < 2 or isempty(u0):
        u0=0.035
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:3
    
    if nargin < 3 or isempty(gateCenter):
        gateCenter=0.035
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:4
    
    if nargin < 4 or isempty(gateWidth):
        gateWidth=0.0025
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:6
    u=max(x - u0,0)
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:7
    gate=S(x,gateCenter,gateWidth)
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:8
    f=multiply(gate,(multiply(dot(0.62,exp(dot(- 2.2,u))),sin(dot(dot(dot(2,pi),7),u))) + multiply(dot(0.34,exp(dot(- 4.0,u))),sin(dot(dot(dot(2,pi),14.25),u) + 0.15)) + multiply(dot(0.22,exp(dot(- 6.0,u))),sin(dot(dot(dot(2,pi),21.7),u) + 0.4)) + multiply(dot(0.14,exp(dot(- 8.0,u))),sin(dot(dot(dot(2,pi),29.5),u) + 0.7))))
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:14
    meta.ID = copy('TF211')
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:15
    meta.Name = copy('Piano Inharmonic Decay')
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:16
    meta.Category = copy(11)
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:18
    meta.Parameters = copy(struct('u0',u0,'gateCenter',gateCenter,'gateWidth',gateWidth))
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:19
    meta.Morphology = copy('Inharmonic decaying partials gated by attack')
# /tmp/mfuncs/TF211_PianoInharmonicDecay.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    