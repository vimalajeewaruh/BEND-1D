# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF092_PercussiveAttackDecay(N=None,t0=None,attackScale=None,attackRate=None,decayMix=None,decayRate1=None,decayRate2=None,ringAmp=None,ringRate=None,ringFreq=None,*args,**kwargs):
    varargin = TF092_PercussiveAttackDecay.varargin
    nargin = TF092_PercussiveAttackDecay.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:2
    
    if nargin < 2 or isempty(t0):
        t0=0.18
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:3
    
    if nargin < 3 or isempty(attackScale):
        attackScale=1.1
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:4
    
    if nargin < 4 or isempty(attackRate):
        attackRate=180
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:5
    
    if nargin < 5 or isempty(decayMix):
        decayMix=concat([0.68,0.32])
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:6
    
    if nargin < 6 or isempty(decayRate1):
        decayRate1=7
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:7
    
    if nargin < 7 or isempty(decayRate2):
        decayRate2=24
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:8
    
    if nargin < 8 or isempty(ringAmp):
        ringAmp=0.18
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:9
    
    if nargin < 9 or isempty(ringRate):
        ringRate=12
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:10
    
    if nargin < 10 or isempty(ringFreq):
        ringFreq=58
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:13
    u=max(x - t0,0)
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:14
    attack=multiply(dot(attackScale,(1 - exp(dot(- attackRate,u)))),(x >= t0))
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:15
    decay=multiply(attack,(dot(decayMix(1),exp(dot(- decayRate1,u))) + dot(decayMix(2),exp(dot(- decayRate2,u)))))
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:16
    ring=multiply(multiply(multiply((x >= t0),ringAmp),exp(dot(- ringRate,u))),sin(dot(dot(dot(2,pi),ringFreq),u)))
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:17
    f=decay + ring
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:19
    meta.ID = copy('TF092')
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:20
    meta.Name = copy('Percussive Attack-Decay')
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:21
    meta.Category = copy(6)
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:24
    meta.Morphology = copy('Fast attack, multi-timescale decay with high-frequency ring')
# /tmp/mfuncs/TF092_PercussiveAttackDecay.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    