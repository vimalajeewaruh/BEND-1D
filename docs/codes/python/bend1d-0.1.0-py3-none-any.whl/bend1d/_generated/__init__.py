"""Generated BEND-1D signal equations."""
