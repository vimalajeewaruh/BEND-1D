# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF128_AlternatingPlateaus(N=None,plateauCenters=None,plateauHeights=None,plateauW=None,*args,**kwargs):
    varargin = TF128_AlternatingPlateaus.varargin
    nargin = TF128_AlternatingPlateaus.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:2
    
    if nargin < 2 or isempty(plateauCenters):
        plateauCenters=linspace(0.1,0.9,6)
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:3
    
    if nargin < 3 or isempty(plateauHeights):
        plateauHeights=repmat(concat([0.3,- 0.25]),1,3)
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:4
    
    if nargin < 4 or isempty(plateauW):
        plateauW=0.03
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:8
    for k in arange(1,numel(plateauCenters)).reshape(-1):
        f=f + dot(plateauHeights(k),tanh((x - plateauCenters(k)) / plateauW))
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:10
    
    meta=copy(struct)
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:12
    meta.ID = copy('TF128')
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:13
    meta.Name = copy('Alternating Plateaus')
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:14
    meta.Category = copy(8)
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:16
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:17
    meta.Morphology = copy('Sequence of alternating signed plateau transitions')
# /tmp/mfuncs/TF128_AlternatingPlateaus.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    