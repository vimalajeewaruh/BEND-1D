# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF168_DSCPhaseTransitions(N=None,*args,**kwargs):
    varargin = TF168_DSCPhaseTransitions.varargin
    nargin = TF168_DSCPhaseTransitions.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:3
    f=0.08 + dot(0.1,x) - dot(0.095,S(x,0.23,0.012)) + dot(0.48,exp(dot(- 0.5,((x - 0.46) / 0.03) ** 2))) - dot(0.42,exp(dot(- 0.5,((x - 0.74) / 0.06) ** 2))) - dot(0.12,exp(dot(- 0.5,((x - 0.825) / 0.028) ** 2)))
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:4
    meta=copy(struct)
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:5
    meta.ID = copy('TF168')
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:6
    meta.Name = copy('DSC Phase Transitions')
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:7
    meta.Category = copy(9)
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:8
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:9
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:10
    meta.Morphology = copy('Baseline trend with multiple phase transition peaks and dips')
# /tmp/mfuncs/TF168_DSCPhaseTransitions.m:11
    return x,f,meta
    
if __name__ == '__main__':
    pass
    