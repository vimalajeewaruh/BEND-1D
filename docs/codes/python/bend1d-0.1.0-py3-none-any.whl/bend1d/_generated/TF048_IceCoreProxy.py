# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF048_IceCoreProxy(N=None,slow_a=None,slow_b=None,slow_phi=None,fine_a=None,fine_phase=None,event_amp=None,event_ctr=None,event_w=None,step_a=None,step1_k=None,step1_ctr=None,step2_k=None,step2_ctr=None,*args,**kwargs):
    varargin = TF048_IceCoreProxy.varargin
    nargin = TF048_IceCoreProxy.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF048_IceCoreProxy.m:2
    
    if nargin < 2 or isempty(slow_a):
        slow_a=0.34
# /tmp/mfuncs/TF048_IceCoreProxy.m:3
    
    if nargin < 3 or isempty(slow_b):
        slow_b=0.16
# /tmp/mfuncs/TF048_IceCoreProxy.m:4
    
    if nargin < 4 or isempty(slow_phi):
        slow_phi=0.7
# /tmp/mfuncs/TF048_IceCoreProxy.m:5
    
    if nargin < 5 or isempty(fine_a):
        fine_a=0.045
# /tmp/mfuncs/TF048_IceCoreProxy.m:6
    
    if nargin < 6 or isempty(fine_phase):
        fine_phase=0
# /tmp/mfuncs/TF048_IceCoreProxy.m:7
    
    if nargin < 7 or isempty(event_amp):
        event_amp=- 0.62
# /tmp/mfuncs/TF048_IceCoreProxy.m:8
    
    if nargin < 8 or isempty(event_ctr):
        event_ctr=0.58
# /tmp/mfuncs/TF048_IceCoreProxy.m:9
    
    if nargin < 9 or isempty(event_w):
        event_w=0.018
# /tmp/mfuncs/TF048_IceCoreProxy.m:10
    
    if nargin < 10 or isempty(step_a):
        step_a=0.2
# /tmp/mfuncs/TF048_IceCoreProxy.m:11
    
    if nargin < 11 or isempty(step1_k):
        step1_k=85
# /tmp/mfuncs/TF048_IceCoreProxy.m:12
    
    if nargin < 12 or isempty(step1_ctr):
        step1_ctr=0.62
# /tmp/mfuncs/TF048_IceCoreProxy.m:13
    
    if nargin < 13 or isempty(step2_k):
        step2_k=55
# /tmp/mfuncs/TF048_IceCoreProxy.m:14
    
    if nargin < 14 or isempty(step2_ctr):
        step2_ctr=0.76
# /tmp/mfuncs/TF048_IceCoreProxy.m:15
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF048_IceCoreProxy.m:17
    slowIce=dot(slow_a,sin(dot(dot(dot(2,pi),1.25),x))) + dot(slow_b,sin(dot(dot(dot(2,pi),3.4),x) + slow_phi))
# /tmp/mfuncs/TF048_IceCoreProxy.m:18
    fineIce=multiply(dot(fine_a,sin(dot(dot(dot(2,pi),27),x))),(0.7 + dot(0.3,cos(dot(dot(2,pi),x) + fine_phase))))
# /tmp/mfuncs/TF048_IceCoreProxy.m:19
    eventIce=dot(event_amp,exp(dot(- 0.5,((x - event_ctr) / event_w) ** 2)))
# /tmp/mfuncs/TF048_IceCoreProxy.m:20
    stepIce=dot(step_a,(1.0 / (1 + exp(dot(- step1_k,(x - step1_ctr)))) - 1.0 / (1 + exp(dot(- step2_k,(x - step2_ctr))))))
# /tmp/mfuncs/TF048_IceCoreProxy.m:21
    f=slowIce + fineIce + eventIce + stepIce
# /tmp/mfuncs/TF048_IceCoreProxy.m:22
    meta=copy(struct)
# /tmp/mfuncs/TF048_IceCoreProxy.m:23
    meta.ID = copy('TF048')
# /tmp/mfuncs/TF048_IceCoreProxy.m:24
    meta.Name = copy('Ice-Core Proxy')
# /tmp/mfuncs/TF048_IceCoreProxy.m:25
    meta.Category = copy(4)
# /tmp/mfuncs/TF048_IceCoreProxy.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF048_IceCoreProxy.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF048_IceCoreProxy.m:28
    meta.Morphology = copy('Slow paleoclimate oscillation with abrupt excursion and step')
# /tmp/mfuncs/TF048_IceCoreProxy.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    