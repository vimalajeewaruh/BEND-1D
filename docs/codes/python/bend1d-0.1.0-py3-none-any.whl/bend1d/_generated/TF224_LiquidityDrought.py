# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF224_LiquidityDrought(N=None,a0=None,slope=None,stepCenter=None,*args,**kwargs):
    varargin = TF224_LiquidityDrought.varargin
    nargin = TF224_LiquidityDrought.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF224_LiquidityDrought.m:2
    
    if nargin < 2 or isempty(a0):
        a0=0.95
# /tmp/mfuncs/TF224_LiquidityDrought.m:3
    
    if nargin < 3 or isempty(slope):
        slope=- 0.38
# /tmp/mfuncs/TF224_LiquidityDrought.m:4
    
    if nargin < 4 or isempty(stepCenter):
        stepCenter=0.61
# /tmp/mfuncs/TF224_LiquidityDrought.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF224_LiquidityDrought.m:6
    f=a0 + dot(slope,x) - dot(0.34,S(x,stepCenter,0.008))
# /tmp/mfuncs/TF224_LiquidityDrought.m:7
    u=max(x - stepCenter,0)
# /tmp/mfuncs/TF224_LiquidityDrought.m:8
    f=f + multiply(multiply((x >= stepCenter),0.27),(1 - exp(- u / 0.18))) + dot(0.07,G(x,0.595,0.01)) - dot(0.1,G(x,0.625,0.012))
# /tmp/mfuncs/TF224_LiquidityDrought.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF224_LiquidityDrought.m:10
    meta.ID = copy('TF224')
# /tmp/mfuncs/TF224_LiquidityDrought.m:11
    meta.Name = copy('Liquidity Drought')
# /tmp/mfuncs/TF224_LiquidityDrought.m:12
    meta.Category = copy(12)
# /tmp/mfuncs/TF224_LiquidityDrought.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF224_LiquidityDrought.m:14
    meta.Parameters = copy(struct('a0',a0,'slope',slope,'stepCenter',stepCenter))
# /tmp/mfuncs/TF224_LiquidityDrought.m:15
    meta.Morphology = copy('Linear decline with step recovery and local bumps')
# /tmp/mfuncs/TF224_LiquidityDrought.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    