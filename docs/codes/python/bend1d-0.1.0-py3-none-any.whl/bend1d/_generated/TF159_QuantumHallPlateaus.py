# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF159_QuantumHallPlateaus(N=None,baseA=None,cQH=None,aQH=None,wQH=None,*args,**kwargs):
    varargin = TF159_QuantumHallPlateaus.varargin
    nargin = TF159_QuantumHallPlateaus.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:2
    
    if nargin < 2 or isempty(baseA):
        baseA=0.1
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:3
    
    if nargin < 3 or isempty(cQH):
        cQH=concat([0.13,0.27,0.41,0.57,0.73,0.87])
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:4
    
    if nargin < 4 or isempty(aQH):
        aQH=concat([0.14,0.16,0.18,0.17,0.15,0.12])
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:5
    
    if nargin < 5 or isempty(wQH):
        wQH=concat([0.004,0.004,0.005,0.004,0.005,0.004])
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:7
    f=dot(baseA,ones(size(x)))
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:8
    for k in arange(1,numel(cQH)).reshape(-1):
        f=f + dot(aQH(k),S(x,cQH(k),wQH(k)))
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:10
    
    f=f + multiply(multiply(dot(0.025,exp(dot(- 2.4,x))),sin(dot(dot(2,pi),(dot(11,x) + dot(8,x ** 2))))),(1 - S(x,0.58,0.025)))
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:13
    meta.ID = copy('TF159')
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:14
    meta.Name = copy('Quantum Hall Plateaus')
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:18
    meta.Morphology = copy('Plateaus with narrow transitions and residual oscillation')
# /tmp/mfuncs/TF159_QuantumHallPlateaus.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    