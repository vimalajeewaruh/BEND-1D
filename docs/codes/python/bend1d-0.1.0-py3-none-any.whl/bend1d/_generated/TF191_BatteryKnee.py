# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF191_BatteryKnee(N=None,kappa=None,x0=None,*args,**kwargs):
    varargin = TF191_BatteryKnee.varargin
    nargin = TF191_BatteryKnee.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF191_BatteryKnee.m:2
    
    if nargin < 2 or isempty(kappa):
        kappa=26
# /tmp/mfuncs/TF191_BatteryKnee.m:3
    
    if nargin < 3 or isempty(x0):
        x0=0.64
# /tmp/mfuncs/TF191_BatteryKnee.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF191_BatteryKnee.m:5
    sp=log1p(exp(dot(kappa,(x - x0)))) / kappa
# /tmp/mfuncs/TF191_BatteryKnee.m:6
    sp1=log1p(exp(dot(kappa,(1 - x0)))) / kappa
# /tmp/mfuncs/TF191_BatteryKnee.m:7
    f=1 - dot(0.18,x) - dot(0.58,(sp / sp1) ** 1.55)
# /tmp/mfuncs/TF191_BatteryKnee.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF191_BatteryKnee.m:9
    meta.ID = copy('TF191')
# /tmp/mfuncs/TF191_BatteryKnee.m:10
    meta.Name = copy('Battery Knee')
# /tmp/mfuncs/TF191_BatteryKnee.m:11
    meta.Category = copy(10)
# /tmp/mfuncs/TF191_BatteryKnee.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF191_BatteryKnee.m:13
    meta.Parameters = copy(struct('kappa',kappa,'x0',x0))
# /tmp/mfuncs/TF191_BatteryKnee.m:14
    meta.Morphology = copy('Smooth knee via softplus transform')
# /tmp/mfuncs/TF191_BatteryKnee.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    