# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF086_QuasarFlare(N=None,wanderAmp1=None,wanderAmp2=None,wanderSlope=None,flareAmp=None,leftC=None,leftW=None,rightDecay=None,smallAmp1=None,smallC1=None,smallW1=None,smallAmp2=None,smallC2=None,smallW2=None,*args,**kwargs):
    varargin = TF086_QuasarFlare.varargin
    nargin = TF086_QuasarFlare.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF086_QuasarFlare.m:2
    
    if nargin < 2 or isempty(wanderAmp1):
        wanderAmp1=0.055
# /tmp/mfuncs/TF086_QuasarFlare.m:3
    
    if nargin < 3 or isempty(wanderAmp2):
        wanderAmp2=0.035
# /tmp/mfuncs/TF086_QuasarFlare.m:4
    
    if nargin < 4 or isempty(wanderSlope):
        wanderSlope=0.02
# /tmp/mfuncs/TF086_QuasarFlare.m:5
    
    if nargin < 5 or isempty(flareAmp):
        flareAmp=0.52
# /tmp/mfuncs/TF086_QuasarFlare.m:6
    
    if nargin < 6 or isempty(leftC):
        leftC=0.56
# /tmp/mfuncs/TF086_QuasarFlare.m:7
    
    if nargin < 7 or isempty(leftW):
        leftW=0.06
# /tmp/mfuncs/TF086_QuasarFlare.m:8
    
    if nargin < 8 or isempty(rightDecay):
        rightDecay=0.18
# /tmp/mfuncs/TF086_QuasarFlare.m:9
    
    if nargin < 9 or isempty(smallAmp1):
        smallAmp1=0.075
# /tmp/mfuncs/TF086_QuasarFlare.m:10
    
    if nargin < 10 or isempty(smallC1):
        smallC1=0.2
# /tmp/mfuncs/TF086_QuasarFlare.m:11
    
    if nargin < 11 or isempty(smallW1):
        smallW1=0.018
# /tmp/mfuncs/TF086_QuasarFlare.m:12
    
    if nargin < 12 or isempty(smallAmp2):
        smallAmp2=0.055
# /tmp/mfuncs/TF086_QuasarFlare.m:13
    
    if nargin < 13 or isempty(smallC2):
        smallC2=0.84
# /tmp/mfuncs/TF086_QuasarFlare.m:14
    
    if nargin < 14 or isempty(smallW2):
        smallW2=0.014
# /tmp/mfuncs/TF086_QuasarFlare.m:15
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF086_QuasarFlare.m:17
    wanderQ=0.34 + dot(wanderAmp1,sin(dot(dot(dot(2,pi),1.4),x) + 0.2)) + dot(wanderAmp2,sin(dot(dot(dot(2,pi),3.3),x) - 0.6)) + dot(wanderSlope,x)
# /tmp/mfuncs/TF086_QuasarFlare.m:18
    leftQ=dot(flareAmp,exp(dot(- 0.5,((x - leftC) / leftW) ** 2)))
# /tmp/mfuncs/TF086_QuasarFlare.m:19
    rightQ=multiply(dot(flareAmp,exp(- (x - leftC) / rightDecay)),(x >= leftC))
# /tmp/mfuncs/TF086_QuasarFlare.m:20
    flareQ=multiply(leftQ,(x < leftC)) + rightQ
# /tmp/mfuncs/TF086_QuasarFlare.m:21
    smallQ=dot(smallAmp1,exp(dot(- 0.5,((x - smallC1) / smallW1) ** 2))) + dot(smallAmp2,exp(dot(- 0.5,((x - smallC2) / smallW2) ** 2)))
# /tmp/mfuncs/TF086_QuasarFlare.m:22
    f=wanderQ + flareQ + smallQ
# /tmp/mfuncs/TF086_QuasarFlare.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF086_QuasarFlare.m:25
    meta.ID = copy('TF086')
# /tmp/mfuncs/TF086_QuasarFlare.m:26
    meta.Name = copy('Quasar Flare')
# /tmp/mfuncs/TF086_QuasarFlare.m:27
    meta.Category = copy(6)
# /tmp/mfuncs/TF086_QuasarFlare.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF086_QuasarFlare.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF086_QuasarFlare.m:30
    meta.Morphology = copy('Wandering baseline with asymmetric flare and small spikes')
# /tmp/mfuncs/TF086_QuasarFlare.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    