# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF139_TerahertzLayerEcho(N=None,cTHz=None,aTHz=None,wTHz=None,echoOnset=None,echoAmp=None,echoFreq=None,echoDecay=None,*args,**kwargs):
    varargin = TF139_TerahertzLayerEcho.varargin
    nargin = TF139_TerahertzLayerEcho.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:2
    
    if nargin < 2 or isempty(cTHz):
        cTHz=concat([0.15,0.34,0.5,0.525,0.72,0.88])
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:3
    
    if nargin < 3 or isempty(aTHz):
        aTHz=concat([0.6,0.42,0.5,0.4,0.28,0.11])
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:4
    
    if nargin < 4 or isempty(wTHz):
        wTHz=concat([0.012,0.014,0.01,0.01,0.016,0.012])
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:5
    
    if nargin < 5 or isempty(echoOnset):
        echoOnset=0.72
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:6
    
    if nargin < 6 or isempty(echoAmp):
        echoAmp=0.07
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:7
    
    if nargin < 7 or isempty(echoFreq):
        echoFreq=35
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:8
    
    if nargin < 8 or isempty(echoDecay):
        echoDecay=9
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:11
    f=zeros(size(x))
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:12
    for k in arange(1,numel(cTHz)).reshape(-1):
        z=(x - cTHz(k)) / wTHz(k)
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:14
        f=f + multiply(multiply(aTHz(k),z),exp(dot(- 0.5,z ** 2)))
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:15
    
    uTHz=max(x - echoOnset,0)
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:17
    f=f + multiply(multiply(multiply((x >= echoOnset),echoAmp),exp(dot(- echoDecay,uTHz))),sin(dot(dot(dot(2,pi),echoFreq),uTHz)))
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:20
    meta.ID = copy('TF139')
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:21
    meta.Name = copy('Terahertz Layer Echo')
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:22
    meta.Category = copy(9)
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:25
    meta.Morphology = copy('Layered dispersive responses with a trailing high‑frequency echo')
# /tmp/mfuncs/TF139_TerahertzLayerEcho.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    