# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF059_ECGBeat(N=None,baseline_amp1=None,baseline_amp2=None,P_a=None,P_ctr=None,P_w=None,Q_a=None,Q_ctr=None,Q_w=None,R_a=None,R_ctr=None,R_w=None,S_a=None,S_ctr=None,S_w=None,ST_a=None,ST_lenscale=None,T_a=None,T_ctr=None,T_w=None,*args,**kwargs):
    varargin = TF059_ECGBeat.varargin
    nargin = TF059_ECGBeat.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF059_ECGBeat.m:2
    
    if nargin < 2 or isempty(baseline_amp1):
        baseline_amp1=0.018
# /tmp/mfuncs/TF059_ECGBeat.m:3
    
    if nargin < 3 or isempty(baseline_amp2):
        baseline_amp2=0.01
# /tmp/mfuncs/TF059_ECGBeat.m:4
    
    if nargin < 4 or isempty(P_a):
        P_a=0.12
# /tmp/mfuncs/TF059_ECGBeat.m:5
    
    if nargin < 5 or isempty(P_ctr):
        P_ctr=0.18
# /tmp/mfuncs/TF059_ECGBeat.m:6
    
    if nargin < 6 or isempty(P_w):
        P_w=0.03
# /tmp/mfuncs/TF059_ECGBeat.m:7
    
    if nargin < 7 or isempty(Q_a):
        Q_a=- 0.16
# /tmp/mfuncs/TF059_ECGBeat.m:8
    
    if nargin < 8 or isempty(Q_ctr):
        Q_ctr=0.365
# /tmp/mfuncs/TF059_ECGBeat.m:9
    
    if nargin < 9 or isempty(Q_w):
        Q_w=0.01
# /tmp/mfuncs/TF059_ECGBeat.m:10
    
    if nargin < 10 or isempty(R_a):
        R_a=1.05
# /tmp/mfuncs/TF059_ECGBeat.m:11
    
    if nargin < 11 or isempty(R_ctr):
        R_ctr=0.392
# /tmp/mfuncs/TF059_ECGBeat.m:12
    
    if nargin < 12 or isempty(R_w):
        R_w=0.0065
# /tmp/mfuncs/TF059_ECGBeat.m:13
    
    if nargin < 13 or isempty(S_a):
        S_a=- 0.28
# /tmp/mfuncs/TF059_ECGBeat.m:14
    
    if nargin < 14 or isempty(S_ctr):
        S_ctr=0.418
# /tmp/mfuncs/TF059_ECGBeat.m:15
    
    if nargin < 15 or isempty(S_w):
        S_w=0.012
# /tmp/mfuncs/TF059_ECGBeat.m:16
    
    if nargin < 16 or isempty(ST_a):
        ST_a=0.045
# /tmp/mfuncs/TF059_ECGBeat.m:17
    
    if nargin < 17 or isempty(ST_lenscale):
        ST_lenscale=struct('rise_k',90,'fall_k',55,'rise_ctr',0.455,'fall_ctr',0.58)
# /tmp/mfuncs/TF059_ECGBeat.m:18
    
    if nargin < 18 or isempty(T_a):
        T_a=0.34
# /tmp/mfuncs/TF059_ECGBeat.m:19
    
    if nargin < 19 or isempty(T_ctr):
        T_ctr=0.68
# /tmp/mfuncs/TF059_ECGBeat.m:20
    
    if nargin < 20 or isempty(T_w):
        T_w=0.06
# /tmp/mfuncs/TF059_ECGBeat.m:21
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF059_ECGBeat.m:23
    baselineECG=dot(baseline_amp1,sin(dot(dot(dot(2,pi),1.25),x))) + dot(baseline_amp2,sin(dot(dot(dot(2,pi),3.1),x) + 0.4))
# /tmp/mfuncs/TF059_ECGBeat.m:24
    Pwave=dot(P_a,exp(dot(- 0.5,((x - P_ctr) / P_w) ** 2)))
# /tmp/mfuncs/TF059_ECGBeat.m:25
    Qwave=dot(Q_a,exp(dot(- 0.5,((x - Q_ctr) / Q_w) ** 2)))
# /tmp/mfuncs/TF059_ECGBeat.m:26
    Rwave=dot(R_a,exp(dot(- 0.5,((x - R_ctr) / R_w) ** 2)))
# /tmp/mfuncs/TF059_ECGBeat.m:27
    Swave=dot(S_a,exp(dot(- 0.5,((x - S_ctr) / S_w) ** 2)))
# /tmp/mfuncs/TF059_ECGBeat.m:28
    STseg=dot(ST_a,(1.0 / (1 + exp(dot(- ST_lenscale.rise_k,(x - ST_lenscale.rise_ctr)))) - 1.0 / (1 + exp(dot(- ST_lenscale.fall_k,(x - ST_lenscale.fall_ctr))))))
# /tmp/mfuncs/TF059_ECGBeat.m:29
    Twave=dot(T_a,exp(dot(- 0.5,((x - T_ctr) / T_w) ** 2)))
# /tmp/mfuncs/TF059_ECGBeat.m:30
    f=baselineECG + Pwave + Qwave + Rwave + Swave + STseg + Twave
# /tmp/mfuncs/TF059_ECGBeat.m:31
    meta=copy(struct)
# /tmp/mfuncs/TF059_ECGBeat.m:32
    meta.ID = copy('TF059')
# /tmp/mfuncs/TF059_ECGBeat.m:33
    meta.Name = copy('ECG Beat')
# /tmp/mfuncs/TF059_ECGBeat.m:34
    meta.Category = copy(5)
# /tmp/mfuncs/TF059_ECGBeat.m:35
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF059_ECGBeat.m:36
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF059_ECGBeat.m:37
    meta.Morphology = copy('Small P wave, sharp QRS complex, broad T wave, and weak baseline wander')
# /tmp/mfuncs/TF059_ECGBeat.m:38
    return x,f,meta
    
if __name__ == '__main__':
    pass
    