# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF217_ThermostatCycle(N=None,base=None,on=None,off=None,amp=None,*args,**kwargs):
    varargin = TF217_ThermostatCycle.varargin
    nargin = TF217_ThermostatCycle.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF217_ThermostatCycle.m:2
    
    if nargin < 2 or isempty(base):
        base=0.25
# /tmp/mfuncs/TF217_ThermostatCycle.m:3
    
    if nargin < 3 or isempty(on):
        on=concat([0.05,0.28,0.52,0.76])
# /tmp/mfuncs/TF217_ThermostatCycle.m:4
    
    if nargin < 4 or isempty(off):
        off=concat([0.18,0.41,0.65,0.89])
# /tmp/mfuncs/TF217_ThermostatCycle.m:5
    
    if nargin < 5 or isempty(amp):
        amp=concat([0.22,0.2,0.23,0.19])
# /tmp/mfuncs/TF217_ThermostatCycle.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF217_ThermostatCycle.m:7
    f=base + dot(0.18,x)
# /tmp/mfuncs/TF217_ThermostatCycle.m:8
    for k in arange(1,numel(on)).reshape(-1):
        f=f + dot(amp(k),(S(x,on(k),0.018) - S(x,off(k),0.038)))
# /tmp/mfuncs/TF217_ThermostatCycle.m:10
    
    f=f + dot(0.025,sin(dot(dot(dot(2,pi),4),x)))
# /tmp/mfuncs/TF217_ThermostatCycle.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF217_ThermostatCycle.m:13
    meta.ID = copy('TF217')
# /tmp/mfuncs/TF217_ThermostatCycle.m:14
    meta.Name = copy('Thermostat Cycle')
# /tmp/mfuncs/TF217_ThermostatCycle.m:15
    meta.Category = copy(11)
# /tmp/mfuncs/TF217_ThermostatCycle.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF217_ThermostatCycle.m:17
    meta.Parameters = copy(struct('base',base,'on',on,'off',off,'amp',amp))
# /tmp/mfuncs/TF217_ThermostatCycle.m:18
    meta.Morphology = copy('Repetitive on-off steps with low-frequency drift')
# /tmp/mfuncs/TF217_ThermostatCycle.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    