# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF073_LidarMultiEcho(N=None,base_a=None,base_b=None,cL=None,aL=None,wL=None,extra_a=None,extra_ctr=None,extra_w=None,*args,**kwargs):
    varargin = TF073_LidarMultiEcho.varargin
    nargin = TF073_LidarMultiEcho.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF073_LidarMultiEcho.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=0.018
# /tmp/mfuncs/TF073_LidarMultiEcho.m:3
    
    if nargin < 3 or isempty(base_b):
        base_b=0.012
# /tmp/mfuncs/TF073_LidarMultiEcho.m:4
    
    if nargin < 4 or isempty(cL):
        cL=concat([0.16,0.34,0.515,0.542,0.73,0.88])
# /tmp/mfuncs/TF073_LidarMultiEcho.m:5
    
    if nargin < 5 or isempty(aL):
        aL=concat([0.3,0.62,1.0,0.72,0.44,0.21])
# /tmp/mfuncs/TF073_LidarMultiEcho.m:6
    
    if nargin < 6 or isempty(wL):
        wL=concat([0.01,0.014,0.009,0.008,0.017,0.006])
# /tmp/mfuncs/TF073_LidarMultiEcho.m:7
    
    if nargin < 7 or isempty(extra_a):
        extra_a=0.045
# /tmp/mfuncs/TF073_LidarMultiEcho.m:8
    
    if nargin < 8 or isempty(extra_ctr):
        extra_ctr=0.64
# /tmp/mfuncs/TF073_LidarMultiEcho.m:9
    
    if nargin < 9 or isempty(extra_w):
        extra_w=0.09
# /tmp/mfuncs/TF073_LidarMultiEcho.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF073_LidarMultiEcho.m:12
    f=base_a + dot(base_b,x)
# /tmp/mfuncs/TF073_LidarMultiEcho.m:13
    for k in arange(1,numel(cL)).reshape(-1):
        f=f + dot(aL(k),exp(dot(- 0.5,((x - cL(k)) / wL(k)) ** 2)))
# /tmp/mfuncs/TF073_LidarMultiEcho.m:15
    
    f=f + dot(extra_a,exp(dot(- 0.5,((x - extra_ctr) / extra_w) ** 2)))
# /tmp/mfuncs/TF073_LidarMultiEcho.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF073_LidarMultiEcho.m:18
    meta.ID = copy('TF073')
# /tmp/mfuncs/TF073_LidarMultiEcho.m:19
    meta.Name = copy('Lidar Multi-Echo')
# /tmp/mfuncs/TF073_LidarMultiEcho.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF073_LidarMultiEcho.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF073_LidarMultiEcho.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF073_LidarMultiEcho.m:23
    meta.Morphology = copy('Multiple Gaussian echoes on a linear baseline')
# /tmp/mfuncs/TF073_LidarMultiEcho.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    