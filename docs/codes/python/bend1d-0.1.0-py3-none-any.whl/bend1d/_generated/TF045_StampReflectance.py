# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF045_StampReflectance(N=None,lam_min=None,lam_max=None,baseline_k=None,band1_a=None,band1_ctr=None,band1_w=None,band2_a=None,band2_ctr=None,band2_w=None,shoulder_a=None,shoulder_ctr=None,shoulder_w=None,*args,**kwargs):
    varargin = TF045_StampReflectance.varargin
    nargin = TF045_StampReflectance.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF045_StampReflectance.m:2
    
    if nargin < 2 or isempty(lam_min):
        lam_min=400
# /tmp/mfuncs/TF045_StampReflectance.m:3
    
    if nargin < 3 or isempty(lam_max):
        lam_max=700
# /tmp/mfuncs/TF045_StampReflectance.m:4
    
    if nargin < 4 or isempty(baseline_k):
        baseline_k=0.00035
# /tmp/mfuncs/TF045_StampReflectance.m:5
    
    if nargin < 5 or isempty(band1_a):
        band1_a=0.42
# /tmp/mfuncs/TF045_StampReflectance.m:6
    
    if nargin < 6 or isempty(band1_ctr):
        band1_ctr=525
# /tmp/mfuncs/TF045_StampReflectance.m:7
    
    if nargin < 7 or isempty(band1_w):
        band1_w=38
# /tmp/mfuncs/TF045_StampReflectance.m:8
    
    if nargin < 8 or isempty(band2_a):
        band2_a=0.16
# /tmp/mfuncs/TF045_StampReflectance.m:9
    
    if nargin < 9 or isempty(band2_ctr):
        band2_ctr=585
# /tmp/mfuncs/TF045_StampReflectance.m:10
    
    if nargin < 10 or isempty(band2_w):
        band2_w=24
# /tmp/mfuncs/TF045_StampReflectance.m:11
    
    if nargin < 11 or isempty(shoulder_a):
        shoulder_a=0.08
# /tmp/mfuncs/TF045_StampReflectance.m:12
    
    if nargin < 12 or isempty(shoulder_ctr):
        shoulder_ctr=455
# /tmp/mfuncs/TF045_StampReflectance.m:13
    
    if nargin < 13 or isempty(shoulder_w):
        shoulder_w=18
# /tmp/mfuncs/TF045_StampReflectance.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF045_StampReflectance.m:16
    lambda_=lam_min + dot((lam_max - lam_min),x)
# /tmp/mfuncs/TF045_StampReflectance.m:17
    baselineR=0.72 + dot(baseline_k,(lambda_ - 550))
# /tmp/mfuncs/TF045_StampReflectance.m:18
    band1=dot(band1_a,exp(dot(- 0.5,((lambda_ - band1_ctr) / band1_w) ** 2)))
# /tmp/mfuncs/TF045_StampReflectance.m:19
    band2=dot(band2_a,exp(dot(- 0.5,((lambda_ - band2_ctr) / band2_w) ** 2)))
# /tmp/mfuncs/TF045_StampReflectance.m:20
    shoulder=dot(shoulder_a,exp(dot(- 0.5,((lambda_ - shoulder_ctr) / shoulder_w) ** 2)))
# /tmp/mfuncs/TF045_StampReflectance.m:21
    f=baselineR - band1 - band2 - shoulder
# /tmp/mfuncs/TF045_StampReflectance.m:22
    meta=copy(struct)
# /tmp/mfuncs/TF045_StampReflectance.m:23
    meta.ID = copy('TF045')
# /tmp/mfuncs/TF045_StampReflectance.m:24
    meta.Name = copy('Stamp Reflectance')
# /tmp/mfuncs/TF045_StampReflectance.m:25
    meta.Category = copy(4)
# /tmp/mfuncs/TF045_StampReflectance.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF045_StampReflectance.m:27
    meta.Parameters = copy(struct('lam_min',lam_min,'lam_max',lam_max,'baseline_k',baseline_k,'band1_a',band1_a,'band1_ctr',band1_ctr,'band1_w',band1_w,'band2_a',band2_a,'band2_ctr',band2_ctr,'band2_w',band2_w,'shoulder_a',shoulder_a,'shoulder_ctr',shoulder_ctr,'shoulder_w',shoulder_w))
# /tmp/mfuncs/TF045_StampReflectance.m:28
    meta.Morphology = copy('Visible reflectance with broad absorption, shoulder and weak band')
# /tmp/mfuncs/TF045_StampReflectance.m:33
    return x,f,meta
    
if __name__ == '__main__':
    pass
    