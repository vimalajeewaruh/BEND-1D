# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF148_PhaseResetBurst(N=None,phaseModAmp=None,phaseModCtr=None,phaseModW=None,burstAmp=None,burstCtr=None,burstW=None,burstFreq=None,*args,**kwargs):
    varargin = TF148_PhaseResetBurst.varargin
    nargin = TF148_PhaseResetBurst.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF148_PhaseResetBurst.m:2
    
    if nargin < 2 or isempty(phaseModAmp):
        phaseModAmp=0.95
# /tmp/mfuncs/TF148_PhaseResetBurst.m:3
    
    if nargin < 3 or isempty(phaseModCtr):
        phaseModCtr=0.48
# /tmp/mfuncs/TF148_PhaseResetBurst.m:4
    
    if nargin < 4 or isempty(phaseModW):
        phaseModW=0.003
# /tmp/mfuncs/TF148_PhaseResetBurst.m:5
    
    if nargin < 5 or isempty(burstAmp):
        burstAmp=0.2
# /tmp/mfuncs/TF148_PhaseResetBurst.m:6
    
    if nargin < 6 or isempty(burstCtr):
        burstCtr=0.67
# /tmp/mfuncs/TF148_PhaseResetBurst.m:7
    
    if nargin < 7 or isempty(burstW):
        burstW=0.035
# /tmp/mfuncs/TF148_PhaseResetBurst.m:8
    
    if nargin < 8 or isempty(burstFreq):
        burstFreq=70
# /tmp/mfuncs/TF148_PhaseResetBurst.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF148_PhaseResetBurst.m:11
    f=dot(0.28,sin(dot(dot(dot(2,pi),18),x) + dot(phaseModAmp,S(x,phaseModCtr,phaseModW)))) + multiply(dot(burstAmp,exp(dot(- 0.5,((x - burstCtr) / burstW) ** 2))),sin(dot(dot(dot(2,pi),burstFreq),x)))
# /tmp/mfuncs/TF148_PhaseResetBurst.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF148_PhaseResetBurst.m:13
    meta.ID = copy('TF148')
# /tmp/mfuncs/TF148_PhaseResetBurst.m:14
    meta.Name = copy('Phase Reset Burst')
# /tmp/mfuncs/TF148_PhaseResetBurst.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF148_PhaseResetBurst.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF148_PhaseResetBurst.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF148_PhaseResetBurst.m:18
    meta.Morphology = copy('High-frequency burst plus a phase-resetting component')
# /tmp/mfuncs/TF148_PhaseResetBurst.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    