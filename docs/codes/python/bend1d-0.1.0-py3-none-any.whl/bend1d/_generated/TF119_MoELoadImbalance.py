# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF119_MoELoadImbalance(N=None,base=None,lfAmp=None,step1Amp=None,step1C=None,step1W=None,step2C=None,step2W=None,hiAmp=None,hiFreq=None,hiW=None,*args,**kwargs):
    varargin = TF119_MoELoadImbalance.varargin
    nargin = TF119_MoELoadImbalance.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF119_MoELoadImbalance.m:2
    
    if nargin < 2 or isempty(base):
        base=0.42
# /tmp/mfuncs/TF119_MoELoadImbalance.m:3
    
    if nargin < 3 or isempty(lfAmp):
        lfAmp=0.025
# /tmp/mfuncs/TF119_MoELoadImbalance.m:4
    
    if nargin < 4 or isempty(step1Amp):
        step1Amp=0.28
# /tmp/mfuncs/TF119_MoELoadImbalance.m:5
    
    if nargin < 5 or isempty(step1C):
        step1C=0.38
# /tmp/mfuncs/TF119_MoELoadImbalance.m:6
    
    if nargin < 6 or isempty(step1W):
        step1W=0.012
# /tmp/mfuncs/TF119_MoELoadImbalance.m:7
    
    if nargin < 7 or isempty(step2C):
        step2C=0.7
# /tmp/mfuncs/TF119_MoELoadImbalance.m:8
    
    if nargin < 8 or isempty(step2W):
        step2W=0.018
# /tmp/mfuncs/TF119_MoELoadImbalance.m:9
    
    if nargin < 9 or isempty(hiAmp):
        hiAmp=0.08
# /tmp/mfuncs/TF119_MoELoadImbalance.m:10
    
    if nargin < 10 or isempty(hiFreq):
        hiFreq=12
# /tmp/mfuncs/TF119_MoELoadImbalance.m:11
    
    if nargin < 11 or isempty(hiW):
        hiW=0.015
# /tmp/mfuncs/TF119_MoELoadImbalance.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF119_MoELoadImbalance.m:14
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF119_MoELoadImbalance.m:15
    f=base + dot(lfAmp,sin(dot(dot(dot(2,pi),4),x)))
# /tmp/mfuncs/TF119_MoELoadImbalance.m:16
    f=f + dot(step1Amp,(S(x,step1C,step1W) - S(x,step2C,step2W))) + multiply(dot(hiAmp,sin(dot(dot(dot(2,pi),hiFreq),x))),(S(x,step1C,hiW) - S(x,step2C,hiW)))
# /tmp/mfuncs/TF119_MoELoadImbalance.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF119_MoELoadImbalance.m:18
    meta.ID = copy('TF119')
# /tmp/mfuncs/TF119_MoELoadImbalance.m:19
    meta.Name = copy('MoE Load Imbalance')
# /tmp/mfuncs/TF119_MoELoadImbalance.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF119_MoELoadImbalance.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF119_MoELoadImbalance.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF119_MoELoadImbalance.m:23
    meta.Morphology = copy('Imbalance step with modulated oscillation')
# /tmp/mfuncs/TF119_MoELoadImbalance.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    