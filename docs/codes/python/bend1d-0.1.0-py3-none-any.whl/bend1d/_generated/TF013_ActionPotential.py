# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF013_ActionPotential(N=None,*args,**kwargs):
    varargin = TF013_ActionPotential.varargin
    nargin = TF013_ActionPotential.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF013_ActionPotential.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF013_ActionPotential.m:3
    depol=1.2 / (1 + exp(dot(- 180,(x - 0.23))))
# /tmp/mfuncs/TF013_ActionPotential.m:4
    repol=1.05 / (1 + exp(dot(- 55,(x - 0.53))))
# /tmp/mfuncs/TF013_ActionPotential.m:5
    undershoot=dot(0.22,exp(- ((x - 0.67) / 0.065) ** 2))
# /tmp/mfuncs/TF013_ActionPotential.m:6
    f=depol - repol - undershoot
# /tmp/mfuncs/TF013_ActionPotential.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF013_ActionPotential.m:8
    meta.ID = copy('TF013')
# /tmp/mfuncs/TF013_ActionPotential.m:9
    meta.Name = copy('Action Potential')
# /tmp/mfuncs/TF013_ActionPotential.m:10
    meta.Category = copy(12)
# /tmp/mfuncs/TF013_ActionPotential.m:11
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF013_ActionPotential.m:12
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF013_ActionPotential.m:13
    meta.Morphology = copy('Rapid depolarization, slower repolarization, after-hyperpolarization')
# /tmp/mfuncs/TF013_ActionPotential.m:14
    return x,f,meta
    
if __name__ == '__main__':
    pass
    