# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF057_PollutionEpisode(N=None,diurnal_base=None,diurnal_amp1=None,diurnal_freq=None,diurnal_amp2=None,diurnal_phase=None,episode1_a=None,episode1_ctr=None,episode1_w=None,episode2_a=None,episode2_ctr=None,episode2_w=None,*args,**kwargs):
    varargin = TF057_PollutionEpisode.varargin
    nargin = TF057_PollutionEpisode.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF057_PollutionEpisode.m:2
    
    if nargin < 2 or isempty(diurnal_base):
        diurnal_base=0.36
# /tmp/mfuncs/TF057_PollutionEpisode.m:3
    
    if nargin < 3 or isempty(diurnal_amp1):
        diurnal_amp1=0.11
# /tmp/mfuncs/TF057_PollutionEpisode.m:4
    
    if nargin < 4 or isempty(diurnal_freq):
        diurnal_freq=7
# /tmp/mfuncs/TF057_PollutionEpisode.m:5
    
    if nargin < 5 or isempty(diurnal_amp2):
        diurnal_amp2=0.04
# /tmp/mfuncs/TF057_PollutionEpisode.m:6
    
    if nargin < 6 or isempty(diurnal_phase):
        diurnal_phase=- 0.5
# /tmp/mfuncs/TF057_PollutionEpisode.m:7
    
    if nargin < 7 or isempty(episode1_a):
        episode1_a=0.62
# /tmp/mfuncs/TF057_PollutionEpisode.m:8
    
    if nargin < 8 or isempty(episode1_ctr):
        episode1_ctr=0.38
# /tmp/mfuncs/TF057_PollutionEpisode.m:9
    
    if nargin < 9 or isempty(episode1_w):
        episode1_w=0.03
# /tmp/mfuncs/TF057_PollutionEpisode.m:10
    
    if nargin < 10 or isempty(episode2_a):
        episode2_a=0.42
# /tmp/mfuncs/TF057_PollutionEpisode.m:11
    
    if nargin < 11 or isempty(episode2_ctr):
        episode2_ctr=0.73
# /tmp/mfuncs/TF057_PollutionEpisode.m:12
    
    if nargin < 12 or isempty(episode2_w):
        episode2_w=0.055
# /tmp/mfuncs/TF057_PollutionEpisode.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF057_PollutionEpisode.m:15
    diurnal=diurnal_base + dot(diurnal_amp1,sin(dot(dot(dot(2,pi),diurnal_freq),x) + diurnal_phase)) + dot(diurnal_amp2,sin(dot(dot(dot(2,pi),(dot(2,diurnal_freq))),x) + 0.2))
# /tmp/mfuncs/TF057_PollutionEpisode.m:16
    episode1=dot(episode1_a,exp(dot(- 0.5,((x - episode1_ctr) / episode1_w) ** 2)))
# /tmp/mfuncs/TF057_PollutionEpisode.m:17
    episode2=dot(episode2_a,exp(dot(- 0.5,((x - episode2_ctr) / episode2_w) ** 2)))
# /tmp/mfuncs/TF057_PollutionEpisode.m:18
    f=diurnal + episode1 + episode2
# /tmp/mfuncs/TF057_PollutionEpisode.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF057_PollutionEpisode.m:20
    meta.ID = copy('TF057')
# /tmp/mfuncs/TF057_PollutionEpisode.m:21
    meta.Name = copy('Pollution Episode')
# /tmp/mfuncs/TF057_PollutionEpisode.m:22
    meta.Category = copy(4)
# /tmp/mfuncs/TF057_PollutionEpisode.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF057_PollutionEpisode.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF057_PollutionEpisode.m:25
    meta.Morphology = copy('Diurnal cycle with transient concentration episodes')
# /tmp/mfuncs/TF057_PollutionEpisode.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    