# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF181_GWChirpRingdown(N=None,xc=None,*args,**kwargs):
    varargin = TF181_GWChirpRingdown.varargin
    nargin = TF181_GWChirpRingdown.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF181_GWChirpRingdown.m:2
    
    if nargin < 2 or isempty(xc):
        xc=0.72
# /tmp/mfuncs/TF181_GWChirpRingdown.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF181_GWChirpRingdown.m:4
    pre=x < xc
# /tmp/mfuncs/TF181_GWChirpRingdown.m:5
    A=0.12 + dot(0.88,(x / xc) ** 1.6)
# /tmp/mfuncs/TF181_GWChirpRingdown.m:6
    phase=dot(dot(2,pi),(dot(4,x) + dot(5,x ** 2) + dot(12,x ** 3) + dot(18,x ** 5)))
# /tmp/mfuncs/TF181_GWChirpRingdown.m:7
    phasec=dot(dot(2,pi),(dot(4,xc) + dot(5,xc ** 2) + dot(12,xc ** 3) + dot(18,xc ** 5)))
# /tmp/mfuncs/TF181_GWChirpRingdown.m:8
    f=zeros(size(x))
# /tmp/mfuncs/TF181_GWChirpRingdown.m:9
    f[pre]=multiply(A(pre),sin(phase(pre)))
# /tmp/mfuncs/TF181_GWChirpRingdown.m:10
    u=max(x - xc,0)
# /tmp/mfuncs/TF181_GWChirpRingdown.m:11
    f[logical_not(pre)]=multiply(exp(dot(- 14,u(logical_not(pre)))),sin(dot(dot(dot(2,pi),42),u(logical_not(pre))) + phasec))
# /tmp/mfuncs/TF181_GWChirpRingdown.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF181_GWChirpRingdown.m:13
    meta.ID = copy('TF181')
# /tmp/mfuncs/TF181_GWChirpRingdown.m:14
    meta.Name = copy('GW Chirp + Ringdown')
# /tmp/mfuncs/TF181_GWChirpRingdown.m:15
    meta.Category = copy(10)
# /tmp/mfuncs/TF181_GWChirpRingdown.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF181_GWChirpRingdown.m:17
    meta.Parameters = copy(struct('xc',xc))
# /tmp/mfuncs/TF181_GWChirpRingdown.m:18
    meta.Morphology = copy('Chirp up to cutoff with exponential ringdown')
# /tmp/mfuncs/TF181_GWChirpRingdown.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    