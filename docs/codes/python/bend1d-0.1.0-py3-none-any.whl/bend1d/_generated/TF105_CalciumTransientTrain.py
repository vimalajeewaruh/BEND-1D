# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF105_CalciumTransientTrain(N=None,base=None,linTrend=None,cCT=None,aCT=None,riseRate=None,decayRate=None,*args,**kwargs):
    varargin = TF105_CalciumTransientTrain.varargin
    nargin = TF105_CalciumTransientTrain.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:2
    
    if nargin < 2 or isempty(base):
        base=0.05
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:3
    
    if nargin < 3 or isempty(linTrend):
        linTrend=0.01
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:4
    
    if nargin < 4 or isempty(cCT):
        cCT=concat([0.16,0.29,0.43,0.455,0.67,0.82])
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:5
    
    if nargin < 5 or isempty(aCT):
        aCT=concat([0.28,0.52,0.72,0.45,0.35,0.18])
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:6
    
    if nargin < 6 or isempty(riseRate):
        riseRate=120
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:7
    
    if nargin < 7 or isempty(decayRate):
        decayRate=10
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:10
    f=base + dot(linTrend,x)
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:11
    for k in arange(1,numel(cCT)).reshape(-1):
        u=max(x - cCT(k),0)
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:13
        f=f + multiply(multiply(dot(aCT(k),(x >= cCT(k))),(1 - exp(dot(- riseRate,u)))),exp(dot(- decayRate,u)))
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:14
    
    meta=copy(struct)
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:16
    meta.ID = copy('TF105')
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:17
    meta.Name = copy('Calcium Transient Train')
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:18
    meta.Category = copy(6)
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:21
    meta.Morphology = copy('Series of calcium transients with rise and decay')
# /tmp/mfuncs/TF105_CalciumTransientTrain.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    