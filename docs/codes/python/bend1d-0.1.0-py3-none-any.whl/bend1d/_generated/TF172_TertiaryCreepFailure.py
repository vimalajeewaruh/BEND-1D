# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF172_TertiaryCreepFailure(N=None,a1=None,a2=None,a3=None,a4=None,break1=None,break2=None,break3=None,*args,**kwargs):
    varargin = TF172_TertiaryCreepFailure.varargin
    nargin = TF172_TertiaryCreepFailure.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:2
    
    if nargin < 2 or isempty(a1):
        a1=0.22
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:3
    
    if nargin < 3 or isempty(a2):
        a2=0.22
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:4
    
    if nargin < 4 or isempty(a3):
        a3=0.1
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:5
    
    if nargin < 5 or isempty(a4):
        a4=0.18
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:6
    
    if nargin < 6 or isempty(break1):
        break1=0.3
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:7
    
    if nargin < 7 or isempty(break2):
        break2=0.56
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:8
    
    if nargin < 8 or isempty(break3):
        break3=0.82
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:10
    f=zeros(size(x))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:11
    m1=x < break1
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:12
    m2=logical_and((x >= break1),(x < break2))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:13
    m3=logical_and((x >= break2),(x < break3))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:14
    m4=x >= break3
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:15
    f[m1]=dot(a1,(1 - exp(dot(- 10,x(m1)))))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:16
    f[m2]=0.209 + dot(a2,(x(m2) - break1))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:17
    u=(x(m3) - break2) / (break3 - break2)
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:18
    f[m3]=0.266 + dot(a3,u) + dot(0.62,u ** 4)
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:19
    f[m4]=0.28 + dot(a4,exp(dot(- 10,(x(m4) - break3))))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:21
    meta.ID = copy('TF172')
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:22
    meta.Name = copy('Tertiary Creep Failure')
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:23
    meta.Category = copy(9)
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:25
    meta.Parameters = copy(struct('a1',a1,'a2',a2,'a3',a3,'a4',a4,'break1',break1,'break2',break2,'break3',break3))
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:26
    meta.Morphology = copy('Piecewise creep evolution with tertiary acceleration')
# /tmp/mfuncs/TF172_TertiaryCreepFailure.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    