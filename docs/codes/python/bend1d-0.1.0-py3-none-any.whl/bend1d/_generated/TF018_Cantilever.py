# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF018_Cantilever(N=None,*args,**kwargs):
    varargin = TF018_Cantilever.varargin
    nargin = TF018_Cantilever.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF018_Cantilever.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF018_Cantilever.m:3
    beta1=1.875104068711961
# /tmp/mfuncs/TF018_Cantilever.m:4
    beta3=7.854757438237612
# /tmp/mfuncs/TF018_Cantilever.m:5
    c1=(cosh(beta1) + cos(beta1)) / (sinh(beta1) + sin(beta1))
# /tmp/mfuncs/TF018_Cantilever.m:6
    c3=(cosh(beta3) + cos(beta3)) / (sinh(beta3) + sin(beta3))
# /tmp/mfuncs/TF018_Cantilever.m:7
    phi1=cosh(dot(beta1,x)) - cos(dot(beta1,x)) - dot(c1,(sinh(dot(beta1,x)) - sin(dot(beta1,x))))
# /tmp/mfuncs/TF018_Cantilever.m:8
    phi3=cosh(dot(beta3,x)) - cos(dot(beta3,x)) - dot(c3,(sinh(dot(beta3,x)) - sin(dot(beta3,x))))
# /tmp/mfuncs/TF018_Cantilever.m:9
    phi1=phi1 / max(abs(phi1))
# /tmp/mfuncs/TF018_Cantilever.m:10
    phi3=phi3 / max(abs(phi3))
# /tmp/mfuncs/TF018_Cantilever.m:11
    xCrack=0.63
# /tmp/mfuncs/TF018_Cantilever.m:12
    hinge=max(x - xCrack,0) - multiply((1 - xCrack),x)
# /tmp/mfuncs/TF018_Cantilever.m:13
    f=phi1 + dot(0.18,phi3) + dot(0.12,hinge)
# /tmp/mfuncs/TF018_Cantilever.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF018_Cantilever.m:15
    meta.ID = copy('TF018')
# /tmp/mfuncs/TF018_Cantilever.m:16
    meta.Name = copy('Cantilever')
# /tmp/mfuncs/TF018_Cantilever.m:17
    meta.Category = copy(2)
# /tmp/mfuncs/TF018_Cantilever.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF018_Cantilever.m:19
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF018_Cantilever.m:20
    meta.Morphology = copy('Euler-Bernoulli first mode with third-mode perturbation and hinge')
# /tmp/mfuncs/TF018_Cantilever.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    