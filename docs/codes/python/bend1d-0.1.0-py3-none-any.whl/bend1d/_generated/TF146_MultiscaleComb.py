# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF146_MultiscaleComb(N=None,peakAmp1=None,peakW1=None,peakAmp2=None,peakW2=None,spikeAmp=None,spikeW=None,*args,**kwargs):
    varargin = TF146_MultiscaleComb.varargin
    nargin = TF146_MultiscaleComb.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF146_MultiscaleComb.m:2
    
    if nargin < 2 or isempty(peakAmp1):
        peakAmp1=0.25
# /tmp/mfuncs/TF146_MultiscaleComb.m:3
    
    if nargin < 3 or isempty(peakW1):
        peakW1=0.03
# /tmp/mfuncs/TF146_MultiscaleComb.m:4
    
    if nargin < 4 or isempty(peakAmp2):
        peakAmp2=0.16
# /tmp/mfuncs/TF146_MultiscaleComb.m:5
    
    if nargin < 5 or isempty(peakW2):
        peakW2=0.01
# /tmp/mfuncs/TF146_MultiscaleComb.m:6
    
    if nargin < 6 or isempty(spikeAmp):
        spikeAmp=0.07
# /tmp/mfuncs/TF146_MultiscaleComb.m:7
    
    if nargin < 7 or isempty(spikeW):
        spikeW=0.003
# /tmp/mfuncs/TF146_MultiscaleComb.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF146_MultiscaleComb.m:10
    f=zeros(size(x))
# /tmp/mfuncs/TF146_MultiscaleComb.m:11
    for c in arange(0.1,0.9,0.2).reshape(-1):
        f=f + dot(peakAmp1,exp(dot(- 0.5,((x - c) / peakW1) ** 2)))
# /tmp/mfuncs/TF146_MultiscaleComb.m:12
    
    for c in arange(0.15,0.95,0.1).reshape(-1):
        f=f + dot(peakAmp2,exp(dot(- 0.5,((x - c) / peakW2) ** 2)))
# /tmp/mfuncs/TF146_MultiscaleComb.m:13
    
    cs=arange(0.18,0.93,0.05)
# /tmp/mfuncs/TF146_MultiscaleComb.m:14
    for k in arange(1,numel(cs)).reshape(-1):
        f=f + dot(dot(spikeAmp,(- 1) ** k),exp(dot(- 0.5,((x - cs(k)) / spikeW) ** 2)))
# /tmp/mfuncs/TF146_MultiscaleComb.m:15
    
    meta=copy(struct)
# /tmp/mfuncs/TF146_MultiscaleComb.m:16
    meta.ID = copy('TF146')
# /tmp/mfuncs/TF146_MultiscaleComb.m:17
    meta.Name = copy('Multiscale Comb')
# /tmp/mfuncs/TF146_MultiscaleComb.m:18
    meta.Category = copy(9)
# /tmp/mfuncs/TF146_MultiscaleComb.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF146_MultiscaleComb.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF146_MultiscaleComb.m:21
    meta.Morphology = copy('Comb of peaks at several scales with alternating polarity fine spikes')
# /tmp/mfuncs/TF146_MultiscaleComb.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    