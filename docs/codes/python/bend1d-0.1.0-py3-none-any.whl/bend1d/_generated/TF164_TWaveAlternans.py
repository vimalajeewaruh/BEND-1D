# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF164_TWaveAlternans(N=None,rTA=None,tAmpTA=None,*args,**kwargs):
    varargin = TF164_TWaveAlternans.varargin
    nargin = TF164_TWaveAlternans.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF164_TWaveAlternans.m:2
    
    if nargin < 2 or isempty(rTA):
        rTA=concat([0.11,0.305,0.5,0.695,0.89])
# /tmp/mfuncs/TF164_TWaveAlternans.m:3
    
    if nargin < 3 or isempty(tAmpTA):
        tAmpTA=concat([0.3,0.27,0.3,0.27,0.3])
# /tmp/mfuncs/TF164_TWaveAlternans.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF164_TWaveAlternans.m:5
    f=zeros(size(x))
# /tmp/mfuncs/TF164_TWaveAlternans.m:6
    for k in arange(1,numel(rTA)).reshape(-1):
        rc=rTA(k)
# /tmp/mfuncs/TF164_TWaveAlternans.m:8
        f=f + dot(0.12,exp(dot(- 0.5,((x - (rc - 0.06)) / 0.018) ** 2))) - dot(0.14,exp(dot(- 0.5,((x - (rc - 0.012)) / 0.005) ** 2))) + dot(1.0,exp(dot(- 0.5,((x - rc) / 0.0042) ** 2))) - dot(0.25,exp(dot(- 0.5,((x - (rc + 0.012)) / 0.006) ** 2))) + dot(tAmpTA(k),exp(dot(- 0.5,((x - (rc + 0.07)) / 0.027) ** 2)))
# /tmp/mfuncs/TF164_TWaveAlternans.m:9
    
    meta=copy(struct)
# /tmp/mfuncs/TF164_TWaveAlternans.m:15
    meta.ID = copy('TF164')
# /tmp/mfuncs/TF164_TWaveAlternans.m:16
    meta.Name = copy('T-Wave Alternans')
# /tmp/mfuncs/TF164_TWaveAlternans.m:17
    meta.Category = copy(9)
# /tmp/mfuncs/TF164_TWaveAlternans.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF164_TWaveAlternans.m:19
    meta.Parameters = copy(struct('rTA',rTA,'tAmpTA',tAmpTA))
# /tmp/mfuncs/TF164_TWaveAlternans.m:20
    meta.Morphology = copy('Alternating T-wave patterns with multi-component shapes')
# /tmp/mfuncs/TF164_TWaveAlternans.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    