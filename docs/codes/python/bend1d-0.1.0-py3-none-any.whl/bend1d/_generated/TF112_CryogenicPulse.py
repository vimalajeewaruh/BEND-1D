# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF112_CryogenicPulse(N=None,mainC=None,mainRise=None,mainDecay=None,precC=None,precW=None,precAmp=None,secC=None,secW=None,secAmp=None,*args,**kwargs):
    varargin = TF112_CryogenicPulse.varargin
    nargin = TF112_CryogenicPulse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF112_CryogenicPulse.m:2
    
    if nargin < 2 or isempty(mainC):
        mainC=0.28
# /tmp/mfuncs/TF112_CryogenicPulse.m:3
    
    if nargin < 3 or isempty(mainRise):
        mainRise=170
# /tmp/mfuncs/TF112_CryogenicPulse.m:4
    
    if nargin < 4 or isempty(mainDecay):
        mainDecay=7
# /tmp/mfuncs/TF112_CryogenicPulse.m:5
    
    if nargin < 5 or isempty(precC):
        precC=0.245
# /tmp/mfuncs/TF112_CryogenicPulse.m:6
    
    if nargin < 6 or isempty(precW):
        precW=0.01
# /tmp/mfuncs/TF112_CryogenicPulse.m:7
    
    if nargin < 7 or isempty(precAmp):
        precAmp=0.08
# /tmp/mfuncs/TF112_CryogenicPulse.m:8
    
    if nargin < 8 or isempty(secC):
        secC=0.62
# /tmp/mfuncs/TF112_CryogenicPulse.m:9
    
    if nargin < 9 or isempty(secW):
        secW=0.02
# /tmp/mfuncs/TF112_CryogenicPulse.m:10
    
    if nargin < 10 or isempty(secAmp):
        secAmp=0.18
# /tmp/mfuncs/TF112_CryogenicPulse.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF112_CryogenicPulse.m:13
    uCP=max(x - mainC,0)
# /tmp/mfuncs/TF112_CryogenicPulse.m:14
    mainCP=multiply(multiply(dot(0.95,(x >= mainC)),(1 - exp(dot(- mainRise,uCP)))),exp(dot(- mainDecay,uCP)))
# /tmp/mfuncs/TF112_CryogenicPulse.m:15
    precCP=dot(precAmp,exp(dot(- 0.5,((x - precC) / precW) ** 2)))
# /tmp/mfuncs/TF112_CryogenicPulse.m:16
    secCP=dot(secAmp,exp(dot(- 0.5,((x - secC) / secW) ** 2)))
# /tmp/mfuncs/TF112_CryogenicPulse.m:17
    f=mainCP + precCP + secCP
# /tmp/mfuncs/TF112_CryogenicPulse.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF112_CryogenicPulse.m:19
    meta.ID = copy('TF112')
# /tmp/mfuncs/TF112_CryogenicPulse.m:20
    meta.Name = copy('Cryogenic Pulse')
# /tmp/mfuncs/TF112_CryogenicPulse.m:21
    meta.Category = copy(6)
# /tmp/mfuncs/TF112_CryogenicPulse.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF112_CryogenicPulse.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF112_CryogenicPulse.m:24
    meta.Morphology = copy('Main pulse with precursor and secondary bumps')
# /tmp/mfuncs/TF112_CryogenicPulse.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    