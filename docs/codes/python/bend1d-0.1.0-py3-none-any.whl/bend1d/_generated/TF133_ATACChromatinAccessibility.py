# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF133_ATACChromatinAccessibility(N=None,baseline=None,lfFreq=None,lfAmp=None,broadA=None,ampA=None,widA=None,sharpA=None,ampS=None,sharpW=None,*args,**kwargs):
    varargin = TF133_ATACChromatinAccessibility.varargin
    nargin = TF133_ATACChromatinAccessibility.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.06
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:3
    
    if nargin < 3 or isempty(lfFreq):
        lfFreq=4
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:4
    
    if nargin < 4 or isempty(lfAmp):
        lfAmp=0.018
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:5
    
    if nargin < 5 or isempty(broadA):
        broadA=concat([0.2,0.52,0.77])
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:6
    
    if nargin < 6 or isempty(ampA):
        ampA=concat([0.22,0.3,0.18])
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:7
    
    if nargin < 7 or isempty(widA):
        widA=concat([0.07,0.085,0.06])
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:8
    
    if nargin < 8 or isempty(sharpA):
        sharpA=concat([0.18,0.235,0.49,0.54,0.705,0.79])
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:9
    
    if nargin < 9 or isempty(ampS):
        ampS=concat([0.16,0.12,0.2,0.1,0.08,0.15])
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:10
    
    if nargin < 10 or isempty(sharpW):
        sharpW=0.007
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:13
    f=baseline + dot(lfAmp,sin(dot(dot(dot(2,pi),lfFreq),x)))
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:14
    for k in arange(1,numel(broadA)).reshape(-1):
        f=f + dot(ampA(k),exp(dot(- 0.5,((x - broadA(k)) / widA(k)) ** 2)))
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:16
    
    for k in arange(1,numel(sharpA)).reshape(-1):
        f=f + dot(ampS(k),exp(dot(- 0.5,((x - sharpA(k)) / sharpW) ** 2)))
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:19
    
    meta=copy(struct)
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:21
    meta.ID = copy('TF133')
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:22
    meta.Name = copy('ATAC Chromatin Accessibility')
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:23
    meta.Category = copy(9)
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:26
    meta.Morphology = copy('Broad accessibility humps with sharp narrow peaks')
# /tmp/mfuncs/TF133_ATACChromatinAccessibility.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    