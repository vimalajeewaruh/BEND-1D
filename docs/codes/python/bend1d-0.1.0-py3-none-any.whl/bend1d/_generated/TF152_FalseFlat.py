# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF152_FalseFlat(N=None,ampL=None,ctrL=None,widL=None,ampR=None,ctrR=None,widR=None,oscAmp=None,oscFreq=None,stepAmp=None,stepWin1=None,stepWin2=None,*args,**kwargs):
    varargin = TF152_FalseFlat.varargin
    nargin = TF152_FalseFlat.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF152_FalseFlat.m:2
    
    if nargin < 2 or isempty(ampL):
        ampL=0.55
# /tmp/mfuncs/TF152_FalseFlat.m:3
    
    if nargin < 3 or isempty(ctrL):
        ctrL=0.17
# /tmp/mfuncs/TF152_FalseFlat.m:4
    
    if nargin < 4 or isempty(widL):
        widL=0.09
# /tmp/mfuncs/TF152_FalseFlat.m:5
    
    if nargin < 5 or isempty(ampR):
        ampR=0.62
# /tmp/mfuncs/TF152_FalseFlat.m:6
    
    if nargin < 6 or isempty(ctrR):
        ctrR=0.84
# /tmp/mfuncs/TF152_FalseFlat.m:7
    
    if nargin < 7 or isempty(widR):
        widR=0.08
# /tmp/mfuncs/TF152_FalseFlat.m:8
    
    if nargin < 8 or isempty(oscAmp):
        oscAmp=0.035
# /tmp/mfuncs/TF152_FalseFlat.m:9
    
    if nargin < 9 or isempty(oscFreq):
        oscFreq=19
# /tmp/mfuncs/TF152_FalseFlat.m:10
    
    if nargin < 10 or isempty(stepAmp):
        stepAmp=0.045
# /tmp/mfuncs/TF152_FalseFlat.m:11
    
    if nargin < 11 or isempty(stepWin1):
        stepWin1=0.49
# /tmp/mfuncs/TF152_FalseFlat.m:12
    
    if nargin < 12 or isempty(stepWin2):
        stepWin2=0.6
# /tmp/mfuncs/TF152_FalseFlat.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF152_FalseFlat.m:15
    f=dot(ampL,exp(dot(- 0.5,((x - ctrL) / widL) ** 2))) + dot(ampR,exp(dot(- 0.5,((x - ctrR) / widR) ** 2))) + multiply(dot(oscAmp,sin(dot(dot(dot(2,pi),oscFreq),x))),(S(x,0.35,0.02) - S(x,0.66,0.02))) + dot(stepAmp,(S(x,stepWin1,0.003) - S(x,stepWin2,0.003)))
# /tmp/mfuncs/TF152_FalseFlat.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF152_FalseFlat.m:17
    meta.ID = copy('TF152')
# /tmp/mfuncs/TF152_FalseFlat.m:18
    meta.Name = copy('False Flat')
# /tmp/mfuncs/TF152_FalseFlat.m:19
    meta.Category = copy(9)
# /tmp/mfuncs/TF152_FalseFlat.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF152_FalseFlat.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF152_FalseFlat.m:22
    meta.Morphology = copy('Apparent flat regions containing localized high-frequency and tiny step features')
# /tmp/mfuncs/TF152_FalseFlat.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    