# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF219_HeatwaveFrontBreak(N=None,base=None,modAmp=None,*args,**kwargs):
    varargin = TF219_HeatwaveFrontBreak.varargin
    nargin = TF219_HeatwaveFrontBreak.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:2
    
    if nargin < 2 or isempty(base):
        base=0.18
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:3
    
    if nargin < 3 or isempty(modAmp):
        modAmp=0.02
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:5
    f=base + dot(0.72,S(x,0.28,0.075)) - dot(0.82,S(x,0.79,0.012))
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:6
    f=f + multiply((modAmp + dot(0.05,S(x,0.35,0.08))),sin(dot(dot(dot(2,pi),9),x)))
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:8
    meta.ID = copy('TF219')
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:9
    meta.Name = copy('Heatwave Front Break')
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:10
    meta.Category = copy(11)
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:11
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:12
    meta.Parameters = copy(struct('base',base,'modAmp',modAmp))
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:13
    meta.Morphology = copy('Slow front with sharp break and modulated ripples')
# /tmp/mfuncs/TF219_HeatwaveFrontBreak.m:14
    return x,f,meta
    
if __name__ == '__main__':
    pass
    