# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF200_ThermalThrottle(N=None,thermalBase=None,throttleDepth=None,*args,**kwargs):
    varargin = TF200_ThermalThrottle.varargin
    nargin = TF200_ThermalThrottle.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF200_ThermalThrottle.m:2
    
    if nargin < 2 or isempty(thermalBase):
        thermalBase=0.12
# /tmp/mfuncs/TF200_ThermalThrottle.m:3
    
    if nargin < 3 or isempty(throttleDepth):
        throttleDepth=0.16
# /tmp/mfuncs/TF200_ThermalThrottle.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF200_ThermalThrottle.m:5
    thermal=thermalBase + dot(0.78,(1 - exp(dot(- 4,x))))
# /tmp/mfuncs/TF200_ThermalThrottle.m:6
    gate=S(x,0.44,0.01)
# /tmp/mfuncs/TF200_ThermalThrottle.m:7
    sq=dot(0.5,(1 + sign(sin(dot(dot(dot(2,pi),12),(x - 0.44))))))
# /tmp/mfuncs/TF200_ThermalThrottle.m:8
    f=thermal - multiply(dot(throttleDepth,gate),sq) + multiply(dot(0.045,gate),sin(dot(dot(dot(2,pi),24),(x - 0.44))))
# /tmp/mfuncs/TF200_ThermalThrottle.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF200_ThermalThrottle.m:10
    meta.ID = copy('TF200')
# /tmp/mfuncs/TF200_ThermalThrottle.m:11
    meta.Name = copy('Thermal Throttle')
# /tmp/mfuncs/TF200_ThermalThrottle.m:12
    meta.Category = copy(10)
# /tmp/mfuncs/TF200_ThermalThrottle.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF200_ThermalThrottle.m:14
    meta.Parameters = copy(struct('thermalBase',thermalBase,'throttleDepth',throttleDepth))
# /tmp/mfuncs/TF200_ThermalThrottle.m:15
    meta.Morphology = copy('Thermal ramp with gated duty-cycle throttling')
# /tmp/mfuncs/TF200_ThermalThrottle.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    