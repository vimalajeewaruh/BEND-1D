# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF179_EqualEnergyScaleLadder(N=None,cEES=None,wEES=None,wref=None,ampEES=None,*args,**kwargs):
    varargin = TF179_EqualEnergyScaleLadder.varargin
    nargin = TF179_EqualEnergyScaleLadder.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:2
    
    if nargin < 2 or isempty(cEES):
        cEES=concat([0.1,0.27,0.45,0.65,0.85])
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:3
    
    if nargin < 3 or isempty(wEES):
        wEES=concat([0.005,0.008,0.013,0.022,0.037])
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:4
    
    if nargin < 4 or isempty(wref):
        wref=0.013
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:5
    
    if nargin < 5 or isempty(ampEES):
        ampEES=1.0
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:8
    for k in arange(1,numel(cEES)).reshape(-1):
        z=(x - cEES(k)) / wEES(k)
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:10
        A=dot(sqrt(wref / wEES(k)),ampEES)
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:11
        f=f + multiply(dot(A,(1 - z ** 2)),exp(dot(- 0.5,z ** 2)))
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:14
    meta.ID = copy('TF179')
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:15
    meta.Name = copy('Equal-Energy Scale Ladder')
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:16
    meta.Category = copy(9)
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:18
    meta.Parameters = copy(struct('centers',cEES,'widths',wEES,'wref',wref,'amp',ampEES))
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:19
    meta.Morphology = copy('Scale-normalized bumps with equal energy')
# /tmp/mfuncs/TF179_EqualEnergyScaleLadder.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    