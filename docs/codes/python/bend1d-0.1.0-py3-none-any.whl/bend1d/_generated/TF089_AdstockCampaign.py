# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF089_AdstockCampaign(N=None,baseLevel=None,baseSlope=None,cAD=None,aAD=None,rAD=None,seasonAmp=None,*args,**kwargs):
    varargin = TF089_AdstockCampaign.varargin
    nargin = TF089_AdstockCampaign.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF089_AdstockCampaign.m:2
    
    if nargin < 2 or isempty(baseLevel):
        baseLevel=0.12
# /tmp/mfuncs/TF089_AdstockCampaign.m:3
    
    if nargin < 3 or isempty(baseSlope):
        baseSlope=0.025
# /tmp/mfuncs/TF089_AdstockCampaign.m:4
    
    if nargin < 4 or isempty(cAD):
        cAD=concat([0.12,0.29,0.47,0.66,0.81])
# /tmp/mfuncs/TF089_AdstockCampaign.m:5
    
    if nargin < 5 or isempty(aAD):
        aAD=concat([0.32,0.26,0.42,0.3,0.22])
# /tmp/mfuncs/TF089_AdstockCampaign.m:6
    
    if nargin < 6 or isempty(rAD):
        rAD=concat([7.0,9.0,6.0,8.5,10.0])
# /tmp/mfuncs/TF089_AdstockCampaign.m:7
    
    if nargin < 7 or isempty(seasonAmp):
        seasonAmp=0.025
# /tmp/mfuncs/TF089_AdstockCampaign.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF089_AdstockCampaign.m:10
    f=baseLevel + dot(baseSlope,x)
# /tmp/mfuncs/TF089_AdstockCampaign.m:11
    for k in arange(1,numel(cAD)).reshape(-1):
        u=max(x - cAD(k),0)
# /tmp/mfuncs/TF089_AdstockCampaign.m:13
        f=f + multiply(dot(aAD(k),(x >= cAD(k))),exp(dot(- rAD(k),u)))
# /tmp/mfuncs/TF089_AdstockCampaign.m:14
    
    f=f + dot(seasonAmp,sin(dot(dot(dot(2,pi),4),x)))
# /tmp/mfuncs/TF089_AdstockCampaign.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF089_AdstockCampaign.m:18
    meta.ID = copy('TF089')
# /tmp/mfuncs/TF089_AdstockCampaign.m:19
    meta.Name = copy('Adstock Campaign')
# /tmp/mfuncs/TF089_AdstockCampaign.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF089_AdstockCampaign.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF089_AdstockCampaign.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF089_AdstockCampaign.m:23
    meta.Morphology = copy('Baseline trend with multiple adstock decays and small seasonality')
# /tmp/mfuncs/TF089_AdstockCampaign.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    