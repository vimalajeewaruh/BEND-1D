# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF008_ImpactSpring(N=None,xImpact=None,*args,**kwargs):
    varargin = TF008_ImpactSpring.varargin
    nargin = TF008_ImpactSpring.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF008_ImpactSpring.m:2
    
    if nargin < 2 or isempty(xImpact):
        xImpact=0.27
# /tmp/mfuncs/TF008_ImpactSpring.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF008_ImpactSpring.m:4
    u=max(x - xImpact,0)
# /tmp/mfuncs/TF008_ImpactSpring.m:5
    impactPulse=dot(1.2,exp(dot(- 0.5,((x - xImpact) / 0.006) ** 2)))
# /tmp/mfuncs/TF008_ImpactSpring.m:6
    ring1=multiply(multiply((x >= xImpact),exp(dot(- 8,u))),sin(dot(dot(34,pi),u)))
# /tmp/mfuncs/TF008_ImpactSpring.m:7
    ring2=multiply(multiply(multiply((x >= xImpact),0.28),exp(dot(- 11,u))),sin(dot(dot(82,pi),u)))
# /tmp/mfuncs/TF008_ImpactSpring.m:8
    f=impactPulse + ring1 + ring2
# /tmp/mfuncs/TF008_ImpactSpring.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF008_ImpactSpring.m:10
    meta.ID = copy('TF008')
# /tmp/mfuncs/TF008_ImpactSpring.m:11
    meta.Name = copy('Impact Spring')
# /tmp/mfuncs/TF008_ImpactSpring.m:12
    meta.Category = copy(7)
# /tmp/mfuncs/TF008_ImpactSpring.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF008_ImpactSpring.m:14
    meta.Parameters = copy(struct('xImpact',xImpact))
# /tmp/mfuncs/TF008_ImpactSpring.m:15
    meta.Morphology = copy('Narrow impact pulse with damped modal rings')
# /tmp/mfuncs/TF008_ImpactSpring.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    