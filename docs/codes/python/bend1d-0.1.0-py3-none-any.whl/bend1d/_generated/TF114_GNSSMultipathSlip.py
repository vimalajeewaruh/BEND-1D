# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF114_GNSSMultipathSlip(N=None,osc1Amp=None,osc1Freq=None,osc2Amp=None,osc2Freq=None,stepC=None,stepW=None,decayRate=None,decayAmp=None,*args,**kwargs):
    varargin = TF114_GNSSMultipathSlip.varargin
    nargin = TF114_GNSSMultipathSlip.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:2
    
    if nargin < 2 or isempty(osc1Amp):
        osc1Amp=0.12
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:3
    
    if nargin < 3 or isempty(osc1Freq):
        osc1Freq=5
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:4
    
    if nargin < 4 or isempty(osc2Amp):
        osc2Amp=0.035
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:5
    
    if nargin < 5 or isempty(osc2Freq):
        osc2Freq=17
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:6
    
    if nargin < 6 or isempty(stepC):
        stepC=0.57
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:7
    
    if nargin < 7 or isempty(stepW):
        stepW=0.003
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:8
    
    if nargin < 8 or isempty(decayRate):
        decayRate=5
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:9
    
    if nargin < 9 or isempty(decayAmp):
        decayAmp=0.25
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:12
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:13
    f=dot(osc1Amp,sin(dot(dot(dot(2,pi),osc1Freq),x))) + dot(osc2Amp,sin(dot(dot(dot(2,pi),osc2Freq),x) + 0.4))
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:14
    f=f + dot(0.42,S(x,stepC,stepW))
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:15
    u=max(x - stepC,0)
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:16
    f=f - multiply(multiply((x >= stepC),decayAmp),(1 - exp(dot(- decayRate,u))))
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:18
    meta.ID = copy('TF114')
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:19
    meta.Name = copy('GNSS Multipath Slip')
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:23
    meta.Morphology = copy('Rising step with subsequent decay')
# /tmp/mfuncs/TF114_GNSSMultipathSlip.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    