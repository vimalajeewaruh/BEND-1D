# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF167_NanoindentationPopIn(N=None,*args,**kwargs):
    varargin = TF167_NanoindentationPopIn.varargin
    nargin = TF167_NanoindentationPopIn.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:3
    f=zeros(size(x))
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:4
    loadMask=x <= 0.7
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:5
    f[loadMask]=dot(1.08,(x(loadMask) / 0.7) ** 1.5)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:6
    f[loadMask]=f(loadMask) - dot(0.055,S(x(loadMask),0.29,0.0018)) - dot(0.07,S(x(loadMask),0.47,0.0018))
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:7
    __,i70=min(abs(x - 0.7),nargout=2)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:8
    f70=f(i70)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:9
    unloadMask=x > 0.7
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:10
    f[unloadMask]=dot(f70,((1 - x(unloadMask)) / 0.3) ** 1.32)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:11
    f=f - dot(0.11,exp(dot(- 0.5,((x - 0.925) / 0.018) ** 2)))
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:13
    meta.ID = copy('TF167')
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:14
    meta.Name = copy('Nanoindentation Pop-In')
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:17
    meta.Parameters = copy(struct('loadPoint',0.7))
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:18
    meta.Morphology = copy('Loading-unloading curve with localized pop-in reductions')
# /tmp/mfuncs/TF167_NanoindentationPopIn.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    