# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF051_RogueWave(N=None,sea_a=None,sea_mod=None,sea_f=None,rogue_a=None,rogue_ctr=None,rogue_w=None,rogue_freq=None,rogue_phase=None,*args,**kwargs):
    varargin = TF051_RogueWave.varargin
    nargin = TF051_RogueWave.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF051_RogueWave.m:2
    
    if nargin < 2 or isempty(sea_a):
        sea_a=0.48
# /tmp/mfuncs/TF051_RogueWave.m:3
    
    if nargin < 3 or isempty(sea_mod):
        sea_mod=0.15
# /tmp/mfuncs/TF051_RogueWave.m:4
    
    if nargin < 4 or isempty(sea_f):
        sea_f=9
# /tmp/mfuncs/TF051_RogueWave.m:5
    
    if nargin < 5 or isempty(rogue_a):
        rogue_a=1.55
# /tmp/mfuncs/TF051_RogueWave.m:6
    
    if nargin < 6 or isempty(rogue_ctr):
        rogue_ctr=0.61
# /tmp/mfuncs/TF051_RogueWave.m:7
    
    if nargin < 7 or isempty(rogue_w):
        rogue_w=0.03
# /tmp/mfuncs/TF051_RogueWave.m:8
    
    if nargin < 8 or isempty(rogue_freq):
        rogue_freq=9
# /tmp/mfuncs/TF051_RogueWave.m:9
    
    if nargin < 9 or isempty(rogue_phase):
        rogue_phase=pi / 2
# /tmp/mfuncs/TF051_RogueWave.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF051_RogueWave.m:12
    sea=multiply((sea_a + dot(sea_mod,sin(dot(dot(dot(2,pi),0.8),x)))),(sin(dot(dot(dot(2,pi),sea_f),x)) + dot(0.2,sin(dot(dot(dot(2,pi),(dot(2,sea_f))),x) + 0.5))))
# /tmp/mfuncs/TF051_RogueWave.m:13
    rogue=multiply(dot(rogue_a,exp(dot(- 0.5,((x - rogue_ctr) / rogue_w) ** 2))),sin(dot(dot(dot(2,pi),rogue_freq),(x - rogue_ctr)) + rogue_phase))
# /tmp/mfuncs/TF051_RogueWave.m:14
    f=sea + rogue
# /tmp/mfuncs/TF051_RogueWave.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF051_RogueWave.m:16
    meta.ID = copy('TF051')
# /tmp/mfuncs/TF051_RogueWave.m:17
    meta.Name = copy('Rogue Wave')
# /tmp/mfuncs/TF051_RogueWave.m:18
    meta.Category = copy(4)
# /tmp/mfuncs/TF051_RogueWave.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF051_RogueWave.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF051_RogueWave.m:21
    meta.Morphology = copy('Narrow-band wave train with an extreme crest-trough event')
# /tmp/mfuncs/TF051_RogueWave.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    