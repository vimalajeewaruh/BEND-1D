# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF230_RegularityQuilt(N=None,intervals=None,*args,**kwargs):
    varargin = TF230_RegularityQuilt.varargin
    nargin = TF230_RegularityQuilt.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF230_RegularityQuilt.m:2
    
    if nargin < 2 or isempty(intervals):
        intervals=concat([[0,0.2,4,1.0],[0.2,0.4,3,- 0.85],[0.4,0.6,2,0.9],[0.6,0.8,1.5,- 0.8],[0.8,1.0,0.5,0.65]])
# /tmp/mfuncs/TF230_RegularityQuilt.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF230_RegularityQuilt.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF230_RegularityQuilt.m:7
    for k in arange(1,size(intervals,1)).reshape(-1):
        aa=intervals(k,1)
# /tmp/mfuncs/TF230_RegularityQuilt.m:9
        bb=intervals(k,2)
# /tmp/mfuncs/TF230_RegularityQuilt.m:9
        pp=intervals(k,3)
# /tmp/mfuncs/TF230_RegularityQuilt.m:9
        A0=intervals(k,4)
# /tmp/mfuncs/TF230_RegularityQuilt.m:9
        m=logical_and((x >= aa),(x <= bb))
# /tmp/mfuncs/TF230_RegularityQuilt.m:10
        s=(x(m) - aa) / (bb - aa)
# /tmp/mfuncs/TF230_RegularityQuilt.m:11
        bump=(multiply(dot(4,s),(1 - s))) ** pp
# /tmp/mfuncs/TF230_RegularityQuilt.m:12
        f[m]=dot(A0,bump)
# /tmp/mfuncs/TF230_RegularityQuilt.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF230_RegularityQuilt.m:15
    meta.ID = copy('TF230')
# /tmp/mfuncs/TF230_RegularityQuilt.m:16
    meta.Name = copy('Regularity Quilt')
# /tmp/mfuncs/TF230_RegularityQuilt.m:17
    meta.Category = copy(12)
# /tmp/mfuncs/TF230_RegularityQuilt.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF230_RegularityQuilt.m:19
    meta.Parameters = copy(struct('intervals',intervals))
# /tmp/mfuncs/TF230_RegularityQuilt.m:20
    meta.Morphology = copy('Piecewise bumps with varying regularity and sign')
# /tmp/mfuncs/TF230_RegularityQuilt.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
