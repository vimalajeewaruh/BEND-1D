# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF085_SolarFlare(N=None,precAmp1=None,precC1=None,precW1=None,precAmp2=None,precC2=None,precW2=None,precAmp3=None,precC3=None,precW3=None,riseAmp=None,riseC=None,riseW=None,decayAmp1=None,decayRate1=None,decayAmp2=None,decayRate2=None,baseLevel=None,postAmp=None,postC=None,postW=None,*args,**kwargs):
    varargin = TF085_SolarFlare.varargin
    nargin = TF085_SolarFlare.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF085_SolarFlare.m:2
    
    if nargin < 2 or isempty(precAmp1):
        precAmp1=0.08
# /tmp/mfuncs/TF085_SolarFlare.m:3
    
    if nargin < 3 or isempty(precC1):
        precC1=0.3
# /tmp/mfuncs/TF085_SolarFlare.m:4
    
    if nargin < 4 or isempty(precW1):
        precW1=0.01
# /tmp/mfuncs/TF085_SolarFlare.m:5
    
    if nargin < 5 or isempty(precAmp2):
        precAmp2=0.12
# /tmp/mfuncs/TF085_SolarFlare.m:6
    
    if nargin < 6 or isempty(precC2):
        precC2=0.345
# /tmp/mfuncs/TF085_SolarFlare.m:7
    
    if nargin < 7 or isempty(precW2):
        precW2=0.007
# /tmp/mfuncs/TF085_SolarFlare.m:8
    
    if nargin < 8 or isempty(precAmp3):
        precAmp3=0.07
# /tmp/mfuncs/TF085_SolarFlare.m:9
    
    if nargin < 9 or isempty(precC3):
        precC3=0.385
# /tmp/mfuncs/TF085_SolarFlare.m:10
    
    if nargin < 10 or isempty(precW3):
        precW3=0.006
# /tmp/mfuncs/TF085_SolarFlare.m:11
    
    if nargin < 11 or isempty(riseAmp):
        riseAmp=0.9
# /tmp/mfuncs/TF085_SolarFlare.m:12
    
    if nargin < 12 or isempty(riseC):
        riseC=0.46
# /tmp/mfuncs/TF085_SolarFlare.m:13
    
    if nargin < 13 or isempty(riseW):
        riseW=0.008
# /tmp/mfuncs/TF085_SolarFlare.m:14
    
    if nargin < 14 or isempty(decayAmp1):
        decayAmp1=0.58
# /tmp/mfuncs/TF085_SolarFlare.m:15
    
    if nargin < 15 or isempty(decayRate1):
        decayRate1=5.2
# /tmp/mfuncs/TF085_SolarFlare.m:16
    
    if nargin < 16 or isempty(decayAmp2):
        decayAmp2=0.32
# /tmp/mfuncs/TF085_SolarFlare.m:17
    
    if nargin < 17 or isempty(decayRate2):
        decayRate2=18
# /tmp/mfuncs/TF085_SolarFlare.m:18
    
    if nargin < 18 or isempty(baseLevel):
        baseLevel=0.08
# /tmp/mfuncs/TF085_SolarFlare.m:19
    
    if nargin < 19 or isempty(postAmp):
        postAmp=0.055
# /tmp/mfuncs/TF085_SolarFlare.m:20
    
    if nargin < 20 or isempty(postC):
        postC=0.64
# /tmp/mfuncs/TF085_SolarFlare.m:21
    
    if nargin < 21 or isempty(postW):
        postW=0.018
# /tmp/mfuncs/TF085_SolarFlare.m:22
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF085_SolarFlare.m:24
    precSF=dot(precAmp1,exp(dot(- 0.5,((x - precC1) / precW1) ** 2))) + dot(precAmp2,exp(dot(- 0.5,((x - precC2) / precW2) ** 2))) + dot(precAmp3,exp(dot(- 0.5,((x - precC3) / precW3) ** 2)))
# /tmp/mfuncs/TF085_SolarFlare.m:25
    riseSF=dot(riseAmp,(1.0 / (1 + exp(- (x - riseC) / riseW))))
# /tmp/mfuncs/TF085_SolarFlare.m:26
    u=max(x - 0.49,0)
# /tmp/mfuncs/TF085_SolarFlare.m:27
    decaySF=multiply((x >= 0.49),(dot(decayAmp1,exp(dot(- decayRate1,u))) + dot(decayAmp2,exp(dot(- decayRate2,u)))))
# /tmp/mfuncs/TF085_SolarFlare.m:28
    f=baseLevel + precSF + riseSF
# /tmp/mfuncs/TF085_SolarFlare.m:29
    idx=x >= 0.49
# /tmp/mfuncs/TF085_SolarFlare.m:30
    f[idx]=baseLevel + decaySF(idx)
# /tmp/mfuncs/TF085_SolarFlare.m:31
    f=f + dot(postAmp,exp(dot(- 0.5,((x - postC) / postW) ** 2)))
# /tmp/mfuncs/TF085_SolarFlare.m:32
    meta=copy(struct)
# /tmp/mfuncs/TF085_SolarFlare.m:33
    meta.ID = copy('TF085')
# /tmp/mfuncs/TF085_SolarFlare.m:34
    meta.Name = copy('Solar Flare')
# /tmp/mfuncs/TF085_SolarFlare.m:35
    meta.Category = copy(6)
# /tmp/mfuncs/TF085_SolarFlare.m:36
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF085_SolarFlare.m:37
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF085_SolarFlare.m:38
    meta.Morphology = copy('Precursor peaks, rapid rise and multi-timescale decay')
# /tmp/mfuncs/TF085_SolarFlare.m:39
    return x,f,meta
    
if __name__ == '__main__':
    pass
    