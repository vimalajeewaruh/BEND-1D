# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF194_RadarMicroDoppler(N=None,amp1=None,amp2=None,mod1=None,mod2=None,*args,**kwargs):
    varargin = TF194_RadarMicroDoppler.varargin
    nargin = TF194_RadarMicroDoppler.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:2
    
    if nargin < 2 or isempty(amp1):
        amp1=1
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:3
    
    if nargin < 3 or isempty(amp2):
        amp2=0.24
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:4
    
    if nargin < 4 or isempty(mod1):
        mod1=1.25
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:5
    
    if nargin < 5 or isempty(mod2):
        mod2=0.7
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:7
    phase1=dot(dot(2,pi),(dot(17,x) + dot(5,x ** 2))) + dot(mod1,sin(dot(dot(dot(2,pi),2.7),x)))
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:8
    phase2=dot(dot(2,pi),(dot(39,x) + dot(2.5,x ** 2))) + dot(mod2,sin(dot(dot(dot(2,pi),5.2),x)))
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:9
    f=dot(multiply((0.58 + dot(0.25,cos(dot(dot(dot(2,pi),1.8),x)))),sin(phase1)),amp1) + dot(amp2,sin(phase2))
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:11
    meta.ID = copy('TF194')
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:12
    meta.Name = copy('Radar Micro-Doppler')
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:15
    meta.Parameters = copy(struct('amp1',amp1,'amp2',amp2,'mod1',mod1,'mod2',mod2))
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:16
    meta.Morphology = copy('Amplitude-modulated dual-component micro-Doppler signal')
# /tmp/mfuncs/TF194_RadarMicroDoppler.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    