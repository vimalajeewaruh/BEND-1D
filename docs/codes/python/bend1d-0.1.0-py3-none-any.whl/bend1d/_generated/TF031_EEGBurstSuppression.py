# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF031_EEGBurstSuppression(N=None,burstCenters=None,burstWidths=None,burstAmp=None,oscCoef=None,*args,**kwargs):
    varargin = TF031_EEGBurstSuppression.varargin
    nargin = TF031_EEGBurstSuppression.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:2
    
    if nargin < 2 or isempty(burstCenters):
        burstCenters=concat([0.17,0.46,0.75])
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:3
    
    if nargin < 3 or isempty(burstWidths):
        burstWidths=concat([0.095,0.125,0.085])
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:4
    
    if nargin < 4 or isempty(burstAmp):
        burstAmp=concat([0.95,1.15,0.82])
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:5
    
    if nargin < 5 or isempty(oscCoef):
        oscCoef=struct('a',31,'b',4.5,'c1',53,'phi1',0.7,'c2',79,'phi2',- 0.4)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:7
    f=dot(0.018,sin(dot(dot(dot(2,pi),5),x)))
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:8
    osc=sin(dot(dot(2,pi),(dot(oscCoef.a,x) + dot(oscCoef.b,x ** 2)))) + dot(0.52,sin(dot(dot(dot(2,pi),oscCoef.c1),x) + oscCoef.phi1)) + dot(0.23,sin(dot(dot(dot(2,pi),oscCoef.c2),x) + oscCoef.phi2))
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:9
    for k in arange(1,numel(burstCenters)).reshape(-1):
        c=burstCenters(k)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:11
        s=burstWidths(k)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:11
        w=exp(dot(- 0.5,((x - c) / s) ** 2)) ** 2
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:12
        f=f + multiply(dot(burstAmp(k),w),osc)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:15
    meta.ID = copy('TF031')
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:16
    meta.Name = copy('EEG Burst-Suppression')
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:17
    meta.Category = copy(3)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:19
    meta.Parameters = copy(struct('burstCenters',burstCenters,'burstWidths',burstWidths,'burstAmp',burstAmp,'oscCoef',oscCoef))
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:20
    meta.Morphology = copy('High-frequency bursts separated by near-quiescent intervals with weak slow component')
# /tmp/mfuncs/TF031_EEGBurstSuppression.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    