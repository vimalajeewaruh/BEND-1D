# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF041_SonarMultipath(N=None,c1_center=None,c1_width=None,c1_f0=None,c1_f1=None,c1_amp=None,c2_center=None,c2_width=None,c2_f0=None,c2_f1=None,c2_amp=None,c3_center=None,c3_width=None,c3_f0=None,c3_f1=None,c3_amp=None,rev_start=None,rev_amp=None,rev_decay=None,rev_f1=None,rev_f2=None,*args,**kwargs):
    varargin = TF041_SonarMultipath.varargin
    nargin = TF041_SonarMultipath.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF041_SonarMultipath.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF041_SonarMultipath.m:6
    if nargin < 2 or isempty(c1_center):
        c1_center=0.22
# /tmp/mfuncs/TF041_SonarMultipath.m:7
    
    if nargin < 3 or isempty(c1_width):
        c1_width=0.03
# /tmp/mfuncs/TF041_SonarMultipath.m:8
    
    if nargin < 4 or isempty(c1_f0):
        c1_f0=28
# /tmp/mfuncs/TF041_SonarMultipath.m:9
    
    if nargin < 5 or isempty(c1_f1):
        c1_f1=145
# /tmp/mfuncs/TF041_SonarMultipath.m:10
    
    if nargin < 6 or isempty(c1_amp):
        c1_amp=1.0
# /tmp/mfuncs/TF041_SonarMultipath.m:11
    
    if nargin < 7 or isempty(c2_center):
        c2_center=0.405
# /tmp/mfuncs/TF041_SonarMultipath.m:12
    
    if nargin < 8 or isempty(c2_width):
        c2_width=0.036
# /tmp/mfuncs/TF041_SonarMultipath.m:13
    
    if nargin < 9 or isempty(c2_f0):
        c2_f0=28
# /tmp/mfuncs/TF041_SonarMultipath.m:14
    
    if nargin < 10 or isempty(c2_f1):
        c2_f1=120
# /tmp/mfuncs/TF041_SonarMultipath.m:15
    
    if nargin < 11 or isempty(c2_amp):
        c2_amp=0.48
# /tmp/mfuncs/TF041_SonarMultipath.m:16
    
    if nargin < 12 or isempty(c3_center):
        c3_center=0.545
# /tmp/mfuncs/TF041_SonarMultipath.m:17
    
    if nargin < 13 or isempty(c3_width):
        c3_width=0.043
# /tmp/mfuncs/TF041_SonarMultipath.m:18
    
    if nargin < 14 or isempty(c3_f0):
        c3_f0=26
# /tmp/mfuncs/TF041_SonarMultipath.m:19
    
    if nargin < 15 or isempty(c3_f1):
        c3_f1=105
# /tmp/mfuncs/TF041_SonarMultipath.m:20
    
    if nargin < 16 or isempty(c3_amp):
        c3_amp=0.28
# /tmp/mfuncs/TF041_SonarMultipath.m:21
    
    if nargin < 17 or isempty(rev_start):
        rev_start=0.56
# /tmp/mfuncs/TF041_SonarMultipath.m:22
    
    if nargin < 18 or isempty(rev_amp):
        rev_amp=0.18
# /tmp/mfuncs/TF041_SonarMultipath.m:23
    
    if nargin < 19 or isempty(rev_decay):
        rev_decay=5.5
# /tmp/mfuncs/TF041_SonarMultipath.m:24
    
    if nargin < 20 or isempty(rev_f1):
        rev_f1=18
# /tmp/mfuncs/TF041_SonarMultipath.m:25
    
    if nargin < 21 or isempty(rev_f2):
        rev_f2=43
# /tmp/mfuncs/TF041_SonarMultipath.m:26
    
    f=chirp_packet(x,c1_center,c1_width,c1_f0,c1_f1,c1_amp) + chirp_packet(x,c2_center,c2_width,c2_f0,c2_f1,c2_amp) + chirp_packet(x,c3_center,c3_width,c3_f0,c3_f1,c3_amp)
# /tmp/mfuncs/TF041_SonarMultipath.m:28
    uRev=x - rev_start
# /tmp/mfuncs/TF041_SonarMultipath.m:32
    indRev=uRev >= 0
# /tmp/mfuncs/TF041_SonarMultipath.m:33
    rev=zeros(size(x))
# /tmp/mfuncs/TF041_SonarMultipath.m:34
    if any(indRev):
        rev[indRev]=multiply(dot(rev_amp,exp(dot(- rev_decay,uRev(indRev)))),(sin(dot(dot(dot(2,pi),rev_f1),uRev(indRev))) + dot(0.35,sin(dot(dot(dot(2,pi),rev_f2),uRev(indRev)) + 0.5))))
# /tmp/mfuncs/TF041_SonarMultipath.m:36
    
    f=f + rev
# /tmp/mfuncs/TF041_SonarMultipath.m:39
    meta=copy(struct)
# /tmp/mfuncs/TF041_SonarMultipath.m:40
    meta.ID = copy('TF041')
# /tmp/mfuncs/TF041_SonarMultipath.m:41
    meta.Name = copy('Sonar Multipath')
# /tmp/mfuncs/TF041_SonarMultipath.m:42
    meta.Category = copy(3)
# /tmp/mfuncs/TF041_SonarMultipath.m:43
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF041_SonarMultipath.m:44
    meta.Parameters = copy(struct('c1_center',c1_center,'c1_width',c1_width,'c1_f0',c1_f0,'c1_f1',c1_f1,'c1_amp',c1_amp,'c2_center',c2_center,'c2_width',c2_width,'c2_f0',c2_f0,'c2_f1',c2_f1,'c2_amp',c2_amp,'c3_center',c3_center,'c3_width',c3_width,'c3_f0',c3_f0,'c3_f1',c3_f1,'c3_amp',c3_amp,'rev_start',rev_start,'rev_amp',rev_amp,'rev_decay',rev_decay,'rev_f1',rev_f1,'rev_f2',rev_f2))
# /tmp/mfuncs/TF041_SonarMultipath.m:45
    meta.Morphology = copy('Localized FM ping with delayed replicas and reverberation')
# /tmp/mfuncs/TF041_SonarMultipath.m:50
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    # Helper: chirp packet used by TF041
    
@function
def chirp_packet(x=None,center=None,width=None,f0=None,f1=None,amp=None,*args,**kwargs):
    varargin = chirp_packet.varargin
    nargin = chirp_packet.nargin

    u=(x - center) / width
# /tmp/mfuncs/TF041_SonarMultipath.m:55
    env=exp(dot(- 0.5,u ** 2))
# /tmp/mfuncs/TF041_SonarMultipath.m:56
    k=(f1 - f0) / width
# /tmp/mfuncs/TF041_SonarMultipath.m:57
    
    phase=dot(dot(2,pi),(dot(f0,(x - center)) + multiply(dot(0.5,(f1 - f0)),(x - center) ** 2) / width))
# /tmp/mfuncs/TF041_SonarMultipath.m:58
    y=multiply(dot(amp,env),sin(phase))
# /tmp/mfuncs/TF041_SonarMultipath.m:59
    return y
    
if __name__ == '__main__':
    pass
    