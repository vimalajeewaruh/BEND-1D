# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF202_SleepSpindleKComplex(N=None,kamp=None,kcent=None,kwidth=None,*args,**kwargs):
    varargin = TF202_SleepSpindleKComplex.varargin
    nargin = TF202_SleepSpindleKComplex.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:2
    
    if nargin < 2 or isempty(kamp):
        kamp=- 0.75
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:3
    
    if nargin < 3 or isempty(kcent):
        kcent=0.43
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:4
    
    if nargin < 4 or isempty(kwidth):
        kwidth=0.035
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:6
    kcomp=dot(kamp,G(x,kcent,kwidth)) + dot(0.48,G(x,0.475,0.048))
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:7
    spindle=multiply(dot(0.32,G(x,0.66,0.075)),sin(dot(dot(dot(2,pi),37),(x - 0.66))))
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:8
    slow=dot(0.06,sin(dot(dot(dot(2,pi),2.4),x)))
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:9
    f=slow + kcomp + spindle
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:11
    meta.ID = copy('TF202')
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:12
    meta.Name = copy('Sleep Spindle + K-Complex')
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:15
    meta.Parameters = copy(struct('kamp',kamp,'kcent',kcent,'kwidth',kwidth))
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:16
    meta.Morphology = copy('K-complex with overlapping spindle oscillation')
# /tmp/mfuncs/TF202_SleepSpindleKComplex.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    