# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF124_NestedWavePackets(N=None,p1Amp=None,p1C=None,p1W=None,p1Freq=None,p2Amp=None,p2C=None,p2W=None,p2Freq=None,p3Amp=None,p3C=None,p3W=None,p3Freq=None,*args,**kwargs):
    varargin = TF124_NestedWavePackets.varargin
    nargin = TF124_NestedWavePackets.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF124_NestedWavePackets.m:2
    
    if nargin < 2 or isempty(p1Amp):
        p1Amp=0.3
# /tmp/mfuncs/TF124_NestedWavePackets.m:3
    
    if nargin < 3 or isempty(p1C):
        p1C=0.5
# /tmp/mfuncs/TF124_NestedWavePackets.m:4
    
    if nargin < 4 or isempty(p1W):
        p1W=0.22
# /tmp/mfuncs/TF124_NestedWavePackets.m:5
    
    if nargin < 5 or isempty(p1Freq):
        p1Freq=8
# /tmp/mfuncs/TF124_NestedWavePackets.m:6
    
    if nargin < 6 or isempty(p2Amp):
        p2Amp=0.24
# /tmp/mfuncs/TF124_NestedWavePackets.m:7
    
    if nargin < 7 or isempty(p2C):
        p2C=0.56
# /tmp/mfuncs/TF124_NestedWavePackets.m:8
    
    if nargin < 8 or isempty(p2W):
        p2W=0.08
# /tmp/mfuncs/TF124_NestedWavePackets.m:9
    
    if nargin < 9 or isempty(p2Freq):
        p2Freq=28
# /tmp/mfuncs/TF124_NestedWavePackets.m:10
    
    if nargin < 10 or isempty(p3Amp):
        p3Amp=0.17
# /tmp/mfuncs/TF124_NestedWavePackets.m:11
    
    if nargin < 11 or isempty(p3C):
        p3C=0.59
# /tmp/mfuncs/TF124_NestedWavePackets.m:12
    
    if nargin < 12 or isempty(p3W):
        p3W=0.022
# /tmp/mfuncs/TF124_NestedWavePackets.m:13
    
    if nargin < 13 or isempty(p3Freq):
        p3Freq=85
# /tmp/mfuncs/TF124_NestedWavePackets.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF124_NestedWavePackets.m:16
    p1=multiply(dot(p1Amp,exp(dot(- 0.5,((x - p1C) / p1W) ** 2))),sin(dot(dot(dot(2,pi),p1Freq),x)))
# /tmp/mfuncs/TF124_NestedWavePackets.m:17
    p2=multiply(dot(p2Amp,exp(dot(- 0.5,((x - p2C) / p2W) ** 2))),sin(dot(dot(dot(2,pi),p2Freq),x)))
# /tmp/mfuncs/TF124_NestedWavePackets.m:18
    p3=multiply(dot(p3Amp,exp(dot(- 0.5,((x - p3C) / p3W) ** 2))),sin(dot(dot(dot(2,pi),p3Freq),x)))
# /tmp/mfuncs/TF124_NestedWavePackets.m:19
    f=p1 + p2 + p3
# /tmp/mfuncs/TF124_NestedWavePackets.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF124_NestedWavePackets.m:21
    meta.ID = copy('TF124')
# /tmp/mfuncs/TF124_NestedWavePackets.m:22
    meta.Name = copy('Nested Wave Packets')
# /tmp/mfuncs/TF124_NestedWavePackets.m:23
    meta.Category = copy(6)
# /tmp/mfuncs/TF124_NestedWavePackets.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF124_NestedWavePackets.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF124_NestedWavePackets.m:26
    meta.Morphology = copy('Multiple nested oscillatory packets at different scales')
# /tmp/mfuncs/TF124_NestedWavePackets.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    