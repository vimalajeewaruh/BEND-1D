# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF229_CancellationNeedle(N=None,g1Amp=None,g1Wide=None,g1ToneAmp=None,g2Scale=None,needleA=None,needlePos=None,needleW1=None,needleW2=None,smallAdd=None,*args,**kwargs):
    varargin = TF229_CancellationNeedle.varargin
    nargin = TF229_CancellationNeedle.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF229_CancellationNeedle.m:2
    
    if nargin < 2 or isempty(g1Amp):
        g1Amp=1.1
# /tmp/mfuncs/TF229_CancellationNeedle.m:3
    
    if nargin < 3 or isempty(g1Wide):
        g1Wide=0.18
# /tmp/mfuncs/TF229_CancellationNeedle.m:4
    
    if nargin < 4 or isempty(g1ToneAmp):
        g1ToneAmp=0.22
# /tmp/mfuncs/TF229_CancellationNeedle.m:5
    
    if nargin < 5 or isempty(g2Scale):
        g2Scale=1.004
# /tmp/mfuncs/TF229_CancellationNeedle.m:6
    
    if nargin < 6 or isempty(needleA):
        needleA=0.16
# /tmp/mfuncs/TF229_CancellationNeedle.m:7
    
    if nargin < 7 or isempty(needlePos):
        needlePos=0.635
# /tmp/mfuncs/TF229_CancellationNeedle.m:8
    
    if nargin < 8 or isempty(needleW1):
        needleW1=0.006
# /tmp/mfuncs/TF229_CancellationNeedle.m:9
    
    if nargin < 9 or isempty(needleW2):
        needleW2=0.009
# /tmp/mfuncs/TF229_CancellationNeedle.m:10
    
    if nargin < 10 or isempty(smallAdd):
        smallAdd=0.018
# /tmp/mfuncs/TF229_CancellationNeedle.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF229_CancellationNeedle.m:12
    g1=dot(g1Amp,G(x,0.5,g1Wide)) + dot(g1ToneAmp,sin(dot(dot(dot(2,pi),2),x)))
# /tmp/mfuncs/TF229_CancellationNeedle.m:13
    g2=dot(g2Scale,g1) + dot(smallAdd,G(x,0.44,0.1))
# /tmp/mfuncs/TF229_CancellationNeedle.m:14
    needle=G(x,needlePos,needleW1) - dot(0.62,G(x,0.648,needleW2))
# /tmp/mfuncs/TF229_CancellationNeedle.m:15
    f=g1 - dot(0.995,g2) + dot(needleA,needle)
# /tmp/mfuncs/TF229_CancellationNeedle.m:16
    f=f / max(abs(f))
# /tmp/mfuncs/TF229_CancellationNeedle.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF229_CancellationNeedle.m:18
    meta.ID = copy('TF229')
# /tmp/mfuncs/TF229_CancellationNeedle.m:19
    meta.Name = copy('Cancellation Needle')
# /tmp/mfuncs/TF229_CancellationNeedle.m:20
    meta.Category = copy(12)
# /tmp/mfuncs/TF229_CancellationNeedle.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF229_CancellationNeedle.m:22
    meta.Parameters = copy(struct('g1Amp',g1Amp,'g1Wide',g1Wide,'g1ToneAmp',g1ToneAmp,'g2Scale',g2Scale,'needleA',needleA,'needlePos',needlePos,'needleW1',needleW1,'needleW2',needleW2,'smallAdd',smallAdd))
# /tmp/mfuncs/TF229_CancellationNeedle.m:23
    meta.Morphology = copy('Nearly cancelling components leaving a narrow needle')
# /tmp/mfuncs/TF229_CancellationNeedle.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    