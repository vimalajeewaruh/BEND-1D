# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF193_GNSSMultipathFade(N=None,base=None,lowAmp=None,highAmp=None,w=None,*args,**kwargs):
    varargin = TF193_GNSSMultipathFade.varargin
    nargin = TF193_GNSSMultipathFade.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:2
    
    if nargin < 2 or isempty(base):
        base=0.65
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:3
    
    if nargin < 3 or isempty(lowAmp):
        lowAmp=0.035
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:4
    
    if nargin < 4 or isempty(highAmp):
        highAmp=0.06
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:5
    
    if nargin < 5 or isempty(w):
        w=concat([0.018,0.011,0.026,0.014])
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:7
    f=base + dot(0.08,sin(dot(dot(dot(2,pi),1.5),x))) + dot(lowAmp,sin(dot(dot(dot(2,pi),16),x) + 0.4))
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:8
    c=concat([0.23,0.51,0.73,0.86])
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:9
    a=concat([0.42,0.56,0.34,0.46])
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:9
    for k in arange(1,4).reshape(-1):
        f=f - dot(a(k),G(x,c(k),w(k)))
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:11
    
    f=f + multiply(dot(highAmp,sin(dot(dot(dot(2,pi),33),x))),G(x,0.52,0.08))
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:14
    meta.ID = copy('TF193')
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:15
    meta.Name = copy('GNSS Multipath Fade')
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:16
    meta.Category = copy(10)
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:18
    meta.Parameters = copy(struct('base',base,'lowAmp',lowAmp,'highAmp',highAmp,'centers',c,'amps',a,'widths',w))
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:19
    meta.Morphology = copy('Multipath dips with high-frequency modulation')
# /tmp/mfuncs/TF193_GNSSMultipathFade.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    