# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF020_ThermalRunaway(N=None,xcTR=None,marginTR=None,*args,**kwargs):
    varargin = TF020_ThermalRunaway.varargin
    nargin = TF020_ThermalRunaway.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF020_ThermalRunaway.m:2
    
    if nargin < 2 or isempty(xcTR):
        xcTR=0.68
# /tmp/mfuncs/TF020_ThermalRunaway.m:3
    
    if nargin < 3 or isempty(marginTR):
        marginTR=0.035
# /tmp/mfuncs/TF020_ThermalRunaway.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF020_ThermalRunaway.m:5
    f=zeros(size(x))
# /tmp/mfuncs/TF020_ThermalRunaway.m:6
    pre=x < xcTR
# /tmp/mfuncs/TF020_ThermalRunaway.m:7
    base=- log(1 - x(pre) / (xcTR + marginTR))
# /tmp/mfuncs/TF020_ThermalRunaway.m:8
    osc=multiply(dot(0.12,(x(pre) / xcTR) ** 3),sin(dot(dot(20,pi),x(pre))))
# /tmp/mfuncs/TF020_ThermalRunaway.m:9
    f[pre]=base + osc
# /tmp/mfuncs/TF020_ThermalRunaway.m:10
    oscCrit=dot(0.12,sin(dot(dot(20,pi),xcTR)))
# /tmp/mfuncs/TF020_ThermalRunaway.m:11
    fcrit=- log(1 - xcTR / (xcTR + marginTR)) + oscCrit
# /tmp/mfuncs/TF020_ThermalRunaway.m:12
    post=logical_not(pre)
# /tmp/mfuncs/TF020_ThermalRunaway.m:13
    u=x(post) - xcTR
# /tmp/mfuncs/TF020_ThermalRunaway.m:14
    f[post]=dot(fcrit,exp(dot(- 11,u))) - dot(0.18,exp(- ((x(post) - 0.8) / 0.035) ** 2))
# /tmp/mfuncs/TF020_ThermalRunaway.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF020_ThermalRunaway.m:16
    meta.ID = copy('TF020')
# /tmp/mfuncs/TF020_ThermalRunaway.m:17
    meta.Name = copy('Thermal Runaway')
# /tmp/mfuncs/TF020_ThermalRunaway.m:18
    meta.Category = copy(2)
# /tmp/mfuncs/TF020_ThermalRunaway.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF020_ThermalRunaway.m:20
    meta.Parameters = copy(struct('xcTR',xcTR,'marginTR',marginTR))
# /tmp/mfuncs/TF020_ThermalRunaway.m:21
    meta.Morphology = copy('Log-accelerating pre-critical rise with exponential quench')
# /tmp/mfuncs/TF020_ThermalRunaway.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    