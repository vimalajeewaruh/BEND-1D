# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF065_AFMForceCurve(N=None,baseline_slope=None,adh_amp=None,adh_ctr=None,adh_w=None,contact_start=None,contact_end=None,contact_lin=None,contact_pow=None,contact_osc_amp=None,contact_osc_freq=None,post_amp=None,post_slope=None,post_snap_amp=None,post_snap_rate=None,*args,**kwargs):
    varargin = TF065_AFMForceCurve.varargin
    nargin = TF065_AFMForceCurve.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF065_AFMForceCurve.m:2
    
    if nargin < 2 or isempty(baseline_slope):
        baseline_slope=0.025
# /tmp/mfuncs/TF065_AFMForceCurve.m:3
    
    if nargin < 3 or isempty(adh_amp):
        adh_amp=- 0.07
# /tmp/mfuncs/TF065_AFMForceCurve.m:4
    
    if nargin < 4 or isempty(adh_ctr):
        adh_ctr=0.305
# /tmp/mfuncs/TF065_AFMForceCurve.m:5
    
    if nargin < 5 or isempty(adh_w):
        adh_w=0.014
# /tmp/mfuncs/TF065_AFMForceCurve.m:6
    
    if nargin < 6 or isempty(contact_start):
        contact_start=0.33
# /tmp/mfuncs/TF065_AFMForceCurve.m:7
    
    if nargin < 7 or isempty(contact_end):
        contact_end=0.78
# /tmp/mfuncs/TF065_AFMForceCurve.m:8
    
    if nargin < 8 or isempty(contact_lin):
        contact_lin=0.025
# /tmp/mfuncs/TF065_AFMForceCurve.m:9
    
    if nargin < 9 or isempty(contact_pow):
        contact_pow=1.42
# /tmp/mfuncs/TF065_AFMForceCurve.m:10
    
    if nargin < 10 or isempty(contact_osc_amp):
        contact_osc_amp=0.02
# /tmp/mfuncs/TF065_AFMForceCurve.m:11
    
    if nargin < 11 or isempty(contact_osc_freq):
        contact_osc_freq=9
# /tmp/mfuncs/TF065_AFMForceCurve.m:12
    
    if nargin < 12 or isempty(post_amp):
        post_amp=0.03
# /tmp/mfuncs/TF065_AFMForceCurve.m:13
    
    if nargin < 13 or isempty(post_slope):
        post_slope=0.015
# /tmp/mfuncs/TF065_AFMForceCurve.m:14
    
    if nargin < 14 or isempty(post_snap_amp):
        post_snap_amp=- 0.115
# /tmp/mfuncs/TF065_AFMForceCurve.m:15
    
    if nargin < 15 or isempty(post_snap_rate):
        post_snap_rate=24
# /tmp/mfuncs/TF065_AFMForceCurve.m:16
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF065_AFMForceCurve.m:18
    f=0.018 + dot(baseline_slope,x)
# /tmp/mfuncs/TF065_AFMForceCurve.m:19
    adhesionApproach=dot(adh_amp,exp(dot(- 0.5,((x - adh_ctr) / adh_w) ** 2)))
# /tmp/mfuncs/TF065_AFMForceCurve.m:20
    f=f + adhesionApproach
# /tmp/mfuncs/TF065_AFMForceCurve.m:21
    contact=logical_and((x >= contact_start),(x < contact_end))
# /tmp/mfuncs/TF065_AFMForceCurve.m:23
    uContact=max(x - contact_start,0)
# /tmp/mfuncs/TF065_AFMForceCurve.m:24
    idx=copy(contact)
# /tmp/mfuncs/TF065_AFMForceCurve.m:25
    f[idx]=0.025 + dot(contact_lin,x(idx)) + dot(3.35,uContact(idx) ** contact_pow) + dot(contact_osc_amp,sin(dot(dot(dot(2,pi),contact_osc_freq),x(idx))))
# /tmp/mfuncs/TF065_AFMForceCurve.m:26
    post=(x >= contact_end)
# /tmp/mfuncs/TF065_AFMForceCurve.m:28
    f[post]=post_amp + dot(post_slope,(x(post) - contact_end)) + dot(post_snap_amp,exp(dot(- post_snap_rate,(x(post) - contact_end))))
# /tmp/mfuncs/TF065_AFMForceCurve.m:29
    meta=copy(struct)
# /tmp/mfuncs/TF065_AFMForceCurve.m:31
    meta.ID = copy('TF065')
# /tmp/mfuncs/TF065_AFMForceCurve.m:32
    meta.Name = copy('AFM Force Curve')
# /tmp/mfuncs/TF065_AFMForceCurve.m:33
    meta.Category = copy(6)
# /tmp/mfuncs/TF065_AFMForceCurve.m:34
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF065_AFMForceCurve.m:35
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF065_AFMForceCurve.m:36
    meta.Morphology = copy('Approach, adhesion dip, contact nonlinear loading, and abrupt snap-off')
# /tmp/mfuncs/TF065_AFMForceCurve.m:37
    return x,f,meta
    
if __name__ == '__main__':
    pass
    