# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF182_FRBScatterTail(N=None,c1=None,s1=None,tau1=None,c2=None,s2=None,tau2=None,*args,**kwargs):
    varargin = TF182_FRBScatterTail.varargin
    nargin = TF182_FRBScatterTail.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF182_FRBScatterTail.m:2
    
    if nargin < 2 or isempty(c1):
        c1=0.31
# /tmp/mfuncs/TF182_FRBScatterTail.m:3
    
    if nargin < 3 or isempty(s1):
        s1=0.0045
# /tmp/mfuncs/TF182_FRBScatterTail.m:4
    
    if nargin < 4 or isempty(tau1):
        tau1=0.038
# /tmp/mfuncs/TF182_FRBScatterTail.m:5
    
    if nargin < 5 or isempty(c2):
        c2=0.347
# /tmp/mfuncs/TF182_FRBScatterTail.m:6
    
    if nargin < 6 or isempty(s2):
        s2=0.0032
# /tmp/mfuncs/TF182_FRBScatterTail.m:7
    
    if nargin < 7 or isempty(tau2):
        tau2=0.024
# /tmp/mfuncs/TF182_FRBScatterTail.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF182_FRBScatterTail.m:9
    exg=lambda z=None,c=None,s=None,tau=None: multiply(dot(0.5,exp(s ** 2 / (dot(2,tau ** 2)) - (z - c) / tau)),erfc((s ** 2 / tau - (z - c)) / (dot(sqrt(2),s))))
# /tmp/mfuncs/TF182_FRBScatterTail.m:10
    e1=exg(x,c1,s1,tau1)
# /tmp/mfuncs/TF182_FRBScatterTail.m:11
    e2=exg(x,c2,s2,tau2)
# /tmp/mfuncs/TF182_FRBScatterTail.m:12
    e1=e1 / max(e1)
# /tmp/mfuncs/TF182_FRBScatterTail.m:13
    e2=e2 / max(e2)
# /tmp/mfuncs/TF182_FRBScatterTail.m:13
    f=e1 + dot(0.42,e2)
# /tmp/mfuncs/TF182_FRBScatterTail.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF182_FRBScatterTail.m:15
    meta.ID = copy('TF182')
# /tmp/mfuncs/TF182_FRBScatterTail.m:16
    meta.Name = copy('Fast Radio Burst with Scattering Tail')
# /tmp/mfuncs/TF182_FRBScatterTail.m:17
    meta.Category = copy(10)
# /tmp/mfuncs/TF182_FRBScatterTail.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF182_FRBScatterTail.m:19
    meta.Parameters = copy(struct('c1',c1,'s1',s1,'tau1',tau1,'c2',c2,'s2',s2,'tau2',tau2))
# /tmp/mfuncs/TF182_FRBScatterTail.m:20
    meta.Morphology = copy('Two scattered pulse components with tails')
# /tmp/mfuncs/TF182_FRBScatterTail.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    