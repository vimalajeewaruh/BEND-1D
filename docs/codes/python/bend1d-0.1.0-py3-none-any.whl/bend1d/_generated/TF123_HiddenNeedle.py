# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF123_HiddenNeedle(N=None,broadAmp=None,broadC=None,broadW=None,needleAmp=None,needleC=None,needleW=None,shoulderAmp=None,shoulderC=None,shoulderW=None,*args,**kwargs):
    varargin = TF123_HiddenNeedle.varargin
    nargin = TF123_HiddenNeedle.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF123_HiddenNeedle.m:2
    
    if nargin < 2 or isempty(broadAmp):
        broadAmp=0.8
# /tmp/mfuncs/TF123_HiddenNeedle.m:3
    
    if nargin < 3 or isempty(broadC):
        broadC=0.52
# /tmp/mfuncs/TF123_HiddenNeedle.m:4
    
    if nargin < 4 or isempty(broadW):
        broadW=0.2
# /tmp/mfuncs/TF123_HiddenNeedle.m:5
    
    if nargin < 5 or isempty(needleAmp):
        needleAmp=0.085
# /tmp/mfuncs/TF123_HiddenNeedle.m:6
    
    if nargin < 6 or isempty(needleC):
        needleC=0.565
# /tmp/mfuncs/TF123_HiddenNeedle.m:7
    
    if nargin < 7 or isempty(needleW):
        needleW=0.0035
# /tmp/mfuncs/TF123_HiddenNeedle.m:8
    
    if nargin < 8 or isempty(shoulderAmp):
        shoulderAmp=- 0.04
# /tmp/mfuncs/TF123_HiddenNeedle.m:9
    
    if nargin < 9 or isempty(shoulderC):
        shoulderC=0.61
# /tmp/mfuncs/TF123_HiddenNeedle.m:10
    
    if nargin < 10 or isempty(shoulderW):
        shoulderW=0.016
# /tmp/mfuncs/TF123_HiddenNeedle.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF123_HiddenNeedle.m:13
    broad=dot(broadAmp,exp(dot(- 0.5,((x - broadC) / broadW) ** 2)))
# /tmp/mfuncs/TF123_HiddenNeedle.m:14
    needle=dot(needleAmp,exp(dot(- 0.5,((x - needleC) / needleW) ** 2)))
# /tmp/mfuncs/TF123_HiddenNeedle.m:15
    shoulder=dot(shoulderAmp,exp(dot(- 0.5,((x - shoulderC) / shoulderW) ** 2)))
# /tmp/mfuncs/TF123_HiddenNeedle.m:16
    f=broad + needle + shoulder
# /tmp/mfuncs/TF123_HiddenNeedle.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF123_HiddenNeedle.m:18
    meta.ID = copy('TF123')
# /tmp/mfuncs/TF123_HiddenNeedle.m:19
    meta.Name = copy('Hidden Needle')
# /tmp/mfuncs/TF123_HiddenNeedle.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF123_HiddenNeedle.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF123_HiddenNeedle.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF123_HiddenNeedle.m:23
    meta.Morphology = copy('Broad feature with a narrow hidden spike')
# /tmp/mfuncs/TF123_HiddenNeedle.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    