# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF225_YieldShockRecovery(N=None,*args,**kwargs):
    varargin = TF225_YieldShockRecovery.varargin
    nargin = TF225_YieldShockRecovery.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF225_YieldShockRecovery.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF225_YieldShockRecovery.m:3
    f=0.18 + dot(0.1,x)
# /tmp/mfuncs/TF225_YieldShockRecovery.m:4
    c=concat([0.43,0.76])
# /tmp/mfuncs/TF225_YieldShockRecovery.m:5
    a=concat([0.72,- 0.32])
# /tmp/mfuncs/TF225_YieldShockRecovery.m:6
    t1=concat([0.055,0.04])
# /tmp/mfuncs/TF225_YieldShockRecovery.m:7
    t2=concat([0.24,0.14])
# /tmp/mfuncs/TF225_YieldShockRecovery.m:8
    for k in arange(1,2).reshape(-1):
        u=max(x - c(k),0)
# /tmp/mfuncs/TF225_YieldShockRecovery.m:10
        f=f + multiply(multiply((x >= c(k)),a(k)),(dot(0.72,exp(- u / t1(k))) + dot(0.28,exp(- u / t2(k)))))
# /tmp/mfuncs/TF225_YieldShockRecovery.m:11
    
    meta=copy(struct)
# /tmp/mfuncs/TF225_YieldShockRecovery.m:13
    meta.ID = copy('TF225')
# /tmp/mfuncs/TF225_YieldShockRecovery.m:14
    meta.Name = copy('Yield Shock + Recovery')
# /tmp/mfuncs/TF225_YieldShockRecovery.m:15
    meta.Category = copy(12)
# /tmp/mfuncs/TF225_YieldShockRecovery.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF225_YieldShockRecovery.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF225_YieldShockRecovery.m:18
    meta.Morphology = copy('Sudden shocks followed by fast and slow recoveries')
# /tmp/mfuncs/TF225_YieldShockRecovery.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    