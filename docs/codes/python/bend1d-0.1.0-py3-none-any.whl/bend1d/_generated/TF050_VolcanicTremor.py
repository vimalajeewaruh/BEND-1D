# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF050_VolcanicTremor(N=None,env_k=None,env_ctr=None,carrier1_a=None,carrier2_a=None,burst1_a=None,burst1_ctr=None,burst1_w=None,burst2_a=None,burst2_ctr=None,burst2_w=None,*args,**kwargs):
    varargin = TF050_VolcanicTremor.varargin
    nargin = TF050_VolcanicTremor.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF050_VolcanicTremor.m:2
    
    if nargin < 2 or isempty(env_k):
        env_k=55
# /tmp/mfuncs/TF050_VolcanicTremor.m:3
    
    if nargin < 3 or isempty(env_ctr):
        env_ctr=0.29
# /tmp/mfuncs/TF050_VolcanicTremor.m:4
    
    if nargin < 4 or isempty(carrier1_a):
        carrier1_a=1
# /tmp/mfuncs/TF050_VolcanicTremor.m:5
    
    if nargin < 5 or isempty(carrier2_a):
        carrier2_a=0.33
# /tmp/mfuncs/TF050_VolcanicTremor.m:6
    
    if nargin < 6 or isempty(burst1_a):
        burst1_a=0.55
# /tmp/mfuncs/TF050_VolcanicTremor.m:7
    
    if nargin < 7 or isempty(burst1_ctr):
        burst1_ctr=0.49
# /tmp/mfuncs/TF050_VolcanicTremor.m:8
    
    if nargin < 8 or isempty(burst1_w):
        burst1_w=0.045
# /tmp/mfuncs/TF050_VolcanicTremor.m:9
    
    if nargin < 9 or isempty(burst2_a):
        burst2_a=0.42
# /tmp/mfuncs/TF050_VolcanicTremor.m:10
    
    if nargin < 10 or isempty(burst2_ctr):
        burst2_ctr=0.72
# /tmp/mfuncs/TF050_VolcanicTremor.m:11
    
    if nargin < 11 or isempty(burst2_w):
        burst2_w=0.035
# /tmp/mfuncs/TF050_VolcanicTremor.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF050_VolcanicTremor.m:14
    envVT=1.0 / (1 + exp(dot(- env_k,(x - env_ctr))))
# /tmp/mfuncs/TF050_VolcanicTremor.m:15
    carrierVT=dot(carrier1_a,sin(dot(dot(2,pi),(dot(17,x) + dot(0.9,x ** 2))))) + dot(carrier2_a,sin(dot(dot(dot(2,pi),35),x) + 0.4))
# /tmp/mfuncs/TF050_VolcanicTremor.m:16
    burstVT=1 + dot(burst1_a,exp(dot(- 0.5,((x - burst1_ctr) / burst1_w) ** 2))) + dot(burst2_a,exp(dot(- 0.5,((x - burst2_ctr) / burst2_w) ** 2)))
# /tmp/mfuncs/TF050_VolcanicTremor.m:17
    f=multiply(multiply(envVT,burstVT),carrierVT)
# /tmp/mfuncs/TF050_VolcanicTremor.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF050_VolcanicTremor.m:19
    meta.ID = copy('TF050')
# /tmp/mfuncs/TF050_VolcanicTremor.m:20
    meta.Name = copy('Volcanic Tremor')
# /tmp/mfuncs/TF050_VolcanicTremor.m:21
    meta.Category = copy(4)
# /tmp/mfuncs/TF050_VolcanicTremor.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF050_VolcanicTremor.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF050_VolcanicTremor.m:24
    meta.Morphology = copy('Onset of persistent tremor with recurrent amplitude bursts')
# /tmp/mfuncs/TF050_VolcanicTremor.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    