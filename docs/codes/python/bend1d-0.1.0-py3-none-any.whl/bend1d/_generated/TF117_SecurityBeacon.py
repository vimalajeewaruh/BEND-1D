# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF117_SecurityBeacon(N=None,base=None,lfAmp=None,pulseCs=None,pulseAmp=None,pulseW=None,hiFreq=None,hiAmp=None,*args,**kwargs):
    varargin = TF117_SecurityBeacon.varargin
    nargin = TF117_SecurityBeacon.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF117_SecurityBeacon.m:2
    
    if nargin < 2 or isempty(base):
        base=0.2
# /tmp/mfuncs/TF117_SecurityBeacon.m:3
    
    if nargin < 3 or isempty(lfAmp):
        lfAmp=0.05
# /tmp/mfuncs/TF117_SecurityBeacon.m:4
    
    if nargin < 4 or isempty(pulseCs):
        pulseCs=concat([0.18,0.42,0.67,0.83])
# /tmp/mfuncs/TF117_SecurityBeacon.m:5
    
    if nargin < 5 or isempty(pulseAmp):
        pulseAmp=0.18
# /tmp/mfuncs/TF117_SecurityBeacon.m:6
    
    if nargin < 6 or isempty(pulseW):
        pulseW=0.02
# /tmp/mfuncs/TF117_SecurityBeacon.m:7
    
    if nargin < 7 or isempty(hiFreq):
        hiFreq=18
# /tmp/mfuncs/TF117_SecurityBeacon.m:8
    
    if nargin < 8 or isempty(hiAmp):
        hiAmp=0.045
# /tmp/mfuncs/TF117_SecurityBeacon.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF117_SecurityBeacon.m:11
    f=base + dot(lfAmp,sin(dot(dot(dot(2,pi),2),x)))
# /tmp/mfuncs/TF117_SecurityBeacon.m:12
    for c in pulseCs.reshape(-1):
        f=f + dot(pulseAmp,exp(dot(- 0.5,((x - c) / pulseW) ** 2)))
# /tmp/mfuncs/TF117_SecurityBeacon.m:14
    
    f=f + dot(hiAmp,sin(dot(dot(dot(2,pi),hiFreq),x)))
# /tmp/mfuncs/TF117_SecurityBeacon.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF117_SecurityBeacon.m:17
    meta.ID = copy('TF117')
# /tmp/mfuncs/TF117_SecurityBeacon.m:18
    meta.Name = copy('Security Beacon')
# /tmp/mfuncs/TF117_SecurityBeacon.m:19
    meta.Category = copy(6)
# /tmp/mfuncs/TF117_SecurityBeacon.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF117_SecurityBeacon.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF117_SecurityBeacon.m:22
    meta.Morphology = copy('Periodic beacon with localized pulses')
# /tmp/mfuncs/TF117_SecurityBeacon.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    