# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF173_TransformerInrush(N=None,A=None,decay1=None,decay2=None,osc1=None,osc2=None,phase=None,*args,**kwargs):
    varargin = TF173_TransformerInrush.varargin
    nargin = TF173_TransformerInrush.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF173_TransformerInrush.m:2
    
    if nargin < 2 or isempty(A):
        A=0.35
# /tmp/mfuncs/TF173_TransformerInrush.m:3
    
    if nargin < 3 or isempty(decay1):
        decay1=5
# /tmp/mfuncs/TF173_TransformerInrush.m:4
    
    if nargin < 4 or isempty(decay2):
        decay2=4
# /tmp/mfuncs/TF173_TransformerInrush.m:5
    
    if nargin < 5 or isempty(osc1):
        osc1=8
# /tmp/mfuncs/TF173_TransformerInrush.m:6
    
    if nargin < 6 or isempty(osc2):
        osc2=16
# /tmp/mfuncs/TF173_TransformerInrush.m:7
    
    if nargin < 7 or isempty(phase):
        phase=0.45
# /tmp/mfuncs/TF173_TransformerInrush.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF173_TransformerInrush.m:9
    f=multiply((A + dot(1.05,exp(dot(- decay1,x)))),sin(dot(dot(dot(2,pi),osc1),x))) + dot(0.48,exp(dot(- decay2,x))) + multiply(dot(0.26,exp(dot(- 5.5,x))),sin(dot(dot(dot(2,pi),osc2),x) + phase))
# /tmp/mfuncs/TF173_TransformerInrush.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF173_TransformerInrush.m:11
    meta.ID = copy('TF173')
# /tmp/mfuncs/TF173_TransformerInrush.m:12
    meta.Name = copy('Transformer Inrush')
# /tmp/mfuncs/TF173_TransformerInrush.m:13
    meta.Category = copy(9)
# /tmp/mfuncs/TF173_TransformerInrush.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF173_TransformerInrush.m:15
    meta.Parameters = copy(struct('A',A,'decay1',decay1,'decay2',decay2,'osc1',osc1,'osc2',osc2,'phase',phase))
# /tmp/mfuncs/TF173_TransformerInrush.m:16
    meta.Morphology = copy('Damped oscillatory inrush current with transient envelope')
# /tmp/mfuncs/TF173_TransformerInrush.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    