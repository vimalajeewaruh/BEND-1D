# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF078_LatencyIncident(N=None,base_a=None,base_amp=None,base_freq=None,ramp_amp=None,ramp_c1=None,ramp_w1=None,ramp_c2=None,ramp_w2=None,cLI=None,aLI=None,wLI=None,ring_amp=None,ring_ctr=None,ring_decay=None,*args,**kwargs):
    varargin = TF078_LatencyIncident.varargin
    nargin = TF078_LatencyIncident.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF078_LatencyIncident.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=0.16
# /tmp/mfuncs/TF078_LatencyIncident.m:3
    
    if nargin < 3 or isempty(base_amp):
        base_amp=0.025
# /tmp/mfuncs/TF078_LatencyIncident.m:4
    
    if nargin < 4 or isempty(base_freq):
        base_freq=3
# /tmp/mfuncs/TF078_LatencyIncident.m:5
    
    if nargin < 5 or isempty(ramp_amp):
        ramp_amp=0.33
# /tmp/mfuncs/TF078_LatencyIncident.m:6
    
    if nargin < 6 or isempty(ramp_c1):
        ramp_c1=0.36
# /tmp/mfuncs/TF078_LatencyIncident.m:7
    
    if nargin < 7 or isempty(ramp_w1):
        ramp_w1=0.05
# /tmp/mfuncs/TF078_LatencyIncident.m:8
    
    if nargin < 8 or isempty(ramp_c2):
        ramp_c2=0.63
# /tmp/mfuncs/TF078_LatencyIncident.m:9
    
    if nargin < 9 or isempty(ramp_w2):
        ramp_w2=0.02
# /tmp/mfuncs/TF078_LatencyIncident.m:10
    
    if nargin < 10 or isempty(cLI):
        cLI=concat([0.5,0.535,0.56,0.585,0.615])
# /tmp/mfuncs/TF078_LatencyIncident.m:11
    
    if nargin < 11 or isempty(aLI):
        aLI=concat([0.22,0.42,0.3,0.55,0.26])
# /tmp/mfuncs/TF078_LatencyIncident.m:12
    
    if nargin < 12 or isempty(wLI):
        wLI=concat([0.008,0.006,0.007,0.005,0.008])
# /tmp/mfuncs/TF078_LatencyIncident.m:13
    
    if nargin < 13 or isempty(ring_amp):
        ring_amp=0.22
# /tmp/mfuncs/TF078_LatencyIncident.m:14
    
    if nargin < 14 or isempty(ring_ctr):
        ring_ctr=0.63
# /tmp/mfuncs/TF078_LatencyIncident.m:15
    
    if nargin < 15 or isempty(ring_decay):
        ring_decay=10
# /tmp/mfuncs/TF078_LatencyIncident.m:16
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF078_LatencyIncident.m:18
    baseLI=base_a + dot(base_amp,sin(dot(dot(dot(2,pi),base_freq),x)))
# /tmp/mfuncs/TF078_LatencyIncident.m:19
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF078_LatencyIncident.m:20
    rampLI=dot(ramp_amp,(sigmoid(x,ramp_c1,ramp_w1) - sigmoid(x,ramp_c2,ramp_w2)))
# /tmp/mfuncs/TF078_LatencyIncident.m:21
    f=baseLI + rampLI
# /tmp/mfuncs/TF078_LatencyIncident.m:22
    for k in arange(1,numel(cLI)).reshape(-1):
        f=f + dot(aLI(k),exp(dot(- 0.5,((x - cLI(k)) / wLI(k)) ** 2)))
# /tmp/mfuncs/TF078_LatencyIncident.m:24
    
    uLI=max(x - ring_ctr,0)
# /tmp/mfuncs/TF078_LatencyIncident.m:26
    f=f + multiply(multiply((x >= ring_ctr),ring_amp),exp(dot(- ring_decay,uLI)))
# /tmp/mfuncs/TF078_LatencyIncident.m:27
    meta=copy(struct)
# /tmp/mfuncs/TF078_LatencyIncident.m:28
    meta.ID = copy('TF078')
# /tmp/mfuncs/TF078_LatencyIncident.m:29
    meta.Name = copy('Latency Incident')
# /tmp/mfuncs/TF078_LatencyIncident.m:30
    meta.Category = copy(6)
# /tmp/mfuncs/TF078_LatencyIncident.m:31
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF078_LatencyIncident.m:32
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF078_LatencyIncident.m:33
    meta.Morphology = copy('Ramp with multiple narrow latency spikes and post-incident ringing')
# /tmp/mfuncs/TF078_LatencyIncident.m:34
    return x,f,meta
    
if __name__ == '__main__':
    pass
    