# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF087_PromotionDemand(N=None,seasonBase=None,seasonSlope=None,seasonAmp1=None,seasonAmp2=None,promoAmp=None,promoC1=None,promoW1=None,promoC2=None,promoW2=None,stockAmp=None,stockC1=None,stockW1=None,stockC2=None,stockW2=None,carryAmp=None,carryC=None,carryRate=None,*args,**kwargs):
    varargin = TF087_PromotionDemand.varargin
    nargin = TF087_PromotionDemand.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF087_PromotionDemand.m:2
    
    if nargin < 2 or isempty(seasonBase):
        seasonBase=0.34
# /tmp/mfuncs/TF087_PromotionDemand.m:3
    
    if nargin < 3 or isempty(seasonSlope):
        seasonSlope=0.055
# /tmp/mfuncs/TF087_PromotionDemand.m:4
    
    if nargin < 4 or isempty(seasonAmp1):
        seasonAmp1=0.065
# /tmp/mfuncs/TF087_PromotionDemand.m:5
    
    if nargin < 5 or isempty(seasonAmp2):
        seasonAmp2=0.025
# /tmp/mfuncs/TF087_PromotionDemand.m:6
    
    if nargin < 6 or isempty(promoAmp):
        promoAmp=0.36
# /tmp/mfuncs/TF087_PromotionDemand.m:7
    
    if nargin < 7 or isempty(promoC1):
        promoC1=0.34
# /tmp/mfuncs/TF087_PromotionDemand.m:8
    
    if nargin < 8 or isempty(promoW1):
        promoW1=0.01
# /tmp/mfuncs/TF087_PromotionDemand.m:9
    
    if nargin < 9 or isempty(promoC2):
        promoC2=0.58
# /tmp/mfuncs/TF087_PromotionDemand.m:10
    
    if nargin < 10 or isempty(promoW2):
        promoW2=0.016
# /tmp/mfuncs/TF087_PromotionDemand.m:11
    
    if nargin < 11 or isempty(stockAmp):
        stockAmp=- 0.25
# /tmp/mfuncs/TF087_PromotionDemand.m:12
    
    if nargin < 12 or isempty(stockC1):
        stockC1=0.48
# /tmp/mfuncs/TF087_PromotionDemand.m:13
    
    if nargin < 13 or isempty(stockW1):
        stockW1=0.006
# /tmp/mfuncs/TF087_PromotionDemand.m:14
    
    if nargin < 14 or isempty(stockC2):
        stockC2=0.535
# /tmp/mfuncs/TF087_PromotionDemand.m:15
    
    if nargin < 15 or isempty(stockW2):
        stockW2=0.006
# /tmp/mfuncs/TF087_PromotionDemand.m:16
    
    if nargin < 16 or isempty(carryAmp):
        carryAmp=0.15
# /tmp/mfuncs/TF087_PromotionDemand.m:17
    
    if nargin < 17 or isempty(carryC):
        carryC=0.58
# /tmp/mfuncs/TF087_PromotionDemand.m:18
    
    if nargin < 18 or isempty(carryRate):
        carryRate=8
# /tmp/mfuncs/TF087_PromotionDemand.m:19
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF087_PromotionDemand.m:21
    seasonPD=seasonBase + dot(seasonSlope,x) + dot(seasonAmp1,sin(dot(dot(dot(2,pi),5),x) - 0.4)) + dot(seasonAmp2,sin(dot(dot(dot(2,pi),10),x)))
# /tmp/mfuncs/TF087_PromotionDemand.m:22
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF087_PromotionDemand.m:23
    promoPD=dot(promoAmp,(sigmoid(x,promoC1,promoW1) - sigmoid(x,promoC2,promoW2)))
# /tmp/mfuncs/TF087_PromotionDemand.m:24
    stockoutPD=dot(stockAmp,(sigmoid(x,stockC1,stockW1) - sigmoid(x,stockC2,stockW2)))
# /tmp/mfuncs/TF087_PromotionDemand.m:25
    uPD=max(x - carryC,0)
# /tmp/mfuncs/TF087_PromotionDemand.m:26
    carryPD=multiply(multiply((x >= carryC),carryAmp),exp(dot(- carryRate,uPD)))
# /tmp/mfuncs/TF087_PromotionDemand.m:27
    f=seasonPD + promoPD + stockoutPD + carryPD
# /tmp/mfuncs/TF087_PromotionDemand.m:28
    meta=copy(struct)
# /tmp/mfuncs/TF087_PromotionDemand.m:30
    meta.ID = copy('TF087')
# /tmp/mfuncs/TF087_PromotionDemand.m:31
    meta.Name = copy('Promotion Demand')
# /tmp/mfuncs/TF087_PromotionDemand.m:32
    meta.Category = copy(6)
# /tmp/mfuncs/TF087_PromotionDemand.m:33
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF087_PromotionDemand.m:34
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF087_PromotionDemand.m:35
    meta.Morphology = copy('Seasonal baseline with promotion bump, stockout dip and carry')
# /tmp/mfuncs/TF087_PromotionDemand.m:36
    return x,f,meta
    
if __name__ == '__main__':
    pass
    