# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF175_LorenzWingSwitch(N=None,sigmaL=None,rhoL=None,betaL=None,dtL=None,burnL=None,initCond=None,*args,**kwargs):
    varargin = TF175_LorenzWingSwitch.varargin
    nargin = TF175_LorenzWingSwitch.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:2
    
    if nargin < 2 or isempty(sigmaL):
        sigmaL=10
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:3
    
    if nargin < 3 or isempty(rhoL):
        rhoL=28
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:4
    
    if nargin < 4 or isempty(betaL):
        betaL=8 / 3
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:5
    
    if nargin < 5 or isempty(dtL):
        dtL=0.01
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:6
    
    if nargin < 6 or isempty(burnL):
        burnL=1200
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:7
    
    if nargin < 7 or isempty(initCond):
        initCond=concat([[1],[1],[1]])
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:9
    totL=N + burnL
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:10
    YL=zeros(3,totL)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:11
    YL[arange(),1]=np.asarray(initCond).reshape(-1,order='F')
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:12
    rhsL=lambda v=None: concat([[dot(sigmaL,(v(2) - v(1)))],[dot(v(1),(rhoL - v(3))) - v(2)],[dot(v(1),v(2)) - dot(betaL,v(3))]])
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:13
    for k in arange(1,totL - 1).reshape(-1):
        yy=YL(arange(),k)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:15
        k1=rhsL(yy)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:16
        k2=rhsL(yy + dot(dot(0.5,dtL),k1))
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:17
        k3=rhsL(yy + dot(dot(0.5,dtL),k2))
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:18
        k4=rhsL(yy + dot(dtL,k3))
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:19
        next_value=yy + dot(dtL,(k1 + dot(2,k2) + dot(2,k3) + k4)) / 6
        YL[arange(),k + 1]=np.asarray(next_value).reshape(-1,order='F')[:3]
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:20
    
    f=matlabarray(np.asarray(YL)[0,int(burnL):]).T
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:22
    f=f - mean(f)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:23
    f=f / max(abs(f))
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:24
    meta=copy(struct)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:25
    meta.ID = copy('TF175')
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:26
    meta.Name = copy('Lorenz Wing Switch')
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:27
    meta.Category = copy(9)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:29
    meta.Parameters = copy(struct('sigma',sigmaL,'rho',rhoL,'beta',betaL,'dt',dtL,'burn',burnL,'initCond',initCond))
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:30
    meta.Morphology = copy('Chaotic Lorenz attractor projected with wing switching')
# /tmp/mfuncs/TF175_LorenzWingSwitch.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
