# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF216_ElevatorRideAcceleration(N=None,a1=None,a2=None,hfAmp=None,*args,**kwargs):
    varargin = TF216_ElevatorRideAcceleration.varargin
    nargin = TF216_ElevatorRideAcceleration.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:2
    
    if nargin < 2 or isempty(a1):
        a1=0.62
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:3
    
    if nargin < 3 or isempty(a2):
        a2=0.58
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:4
    
    if nargin < 4 or isempty(hfAmp):
        hfAmp=0.18
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:6
    f=dot(a1,(S(x,0.08,0.008) - S(x,0.22,0.008))) - dot(a2,(S(x,0.68,0.008) - S(x,0.8,0.008)))
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:7
    u=max(x - 0.8,0)
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:8
    f=f + multiply(multiply(multiply((x >= 0.8),hfAmp),exp(dot(- 22,u))),sin(dot(dot(dot(2,pi),30),u)))
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:10
    meta.ID = copy('TF216')
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:11
    meta.Name = copy('Elevator Ride Acceleration')
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:12
    meta.Category = copy(11)
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:14
    meta.Parameters = copy(struct('a1',a1,'a2',a2,'hfAmp',hfAmp))
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:15
    meta.Morphology = copy('Acceleration pulses with high-frequency end oscillation')
# /tmp/mfuncs/TF216_ElevatorRideAcceleration.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    