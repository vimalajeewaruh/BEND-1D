# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF015_VanHove(N=None,xcVH=None,deltaVH=None,*args,**kwargs):
    varargin = TF015_VanHove.varargin
    nargin = TF015_VanHove.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF015_VanHove.m:2
    
    if nargin < 2 or isempty(xcVH):
        xcVH=0.57
# /tmp/mfuncs/TF015_VanHove.m:3
    
    if nargin < 3 or isempty(deltaVH):
        deltaVH=0.006
# /tmp/mfuncs/TF015_VanHove.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF015_VanHove.m:5
    bandEnvelope=sqrt(max(multiply(x,(1 - x)),0))
# /tmp/mfuncs/TF015_VanHove.m:6
    f=multiply(- bandEnvelope,log(sqrt((x - xcVH) ** 2 + deltaVH ** 2)))
# /tmp/mfuncs/TF015_VanHove.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF015_VanHove.m:8
    meta.ID = copy('TF015')
# /tmp/mfuncs/TF015_VanHove.m:9
    meta.Name = copy('Van Hove')
# /tmp/mfuncs/TF015_VanHove.m:10
    meta.Category = copy(14)
# /tmp/mfuncs/TF015_VanHove.m:11
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF015_VanHove.m:12
    meta.Parameters = copy(struct('xcVH',xcVH,'deltaVH',deltaVH))
# /tmp/mfuncs/TF015_VanHove.m:13
    meta.Morphology = copy('Regularized logarithmic singularity with finite-band envelope')
# /tmp/mfuncs/TF015_VanHove.m:14
    return x,f,meta
    
if __name__ == '__main__':
    pass
    