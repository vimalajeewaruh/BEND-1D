# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF127_NoiseBursts(N=None,baseFreq=None,burstCenters=None,burstAmp=None,burstW=None,*args,**kwargs):
    varargin = TF127_NoiseBursts.varargin
    nargin = TF127_NoiseBursts.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF127_NoiseBursts.m:2
    
    if nargin < 2 or isempty(baseFreq):
        baseFreq=5
# /tmp/mfuncs/TF127_NoiseBursts.m:3
    
    if nargin < 3 or isempty(burstCenters):
        burstCenters=concat([0.2,0.5,0.75])
# /tmp/mfuncs/TF127_NoiseBursts.m:4
    
    if nargin < 4 or isempty(burstAmp):
        burstAmp=concat([0.6,0.8,0.5])
# /tmp/mfuncs/TF127_NoiseBursts.m:5
    
    if nargin < 5 or isempty(burstW):
        burstW=0.02
# /tmp/mfuncs/TF127_NoiseBursts.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF127_NoiseBursts.m:8
    f=dot(0.05,sin(dot(dot(dot(2,pi),baseFreq),x)))
# /tmp/mfuncs/TF127_NoiseBursts.m:9
    for k in arange(1,numel(burstCenters)).reshape(-1):
        env=exp(dot(- 0.5,((x - burstCenters(k)) / burstW) ** 2))
# /tmp/mfuncs/TF127_NoiseBursts.m:11
        f=f + multiply(dot(burstAmp(k),env),randn(size(x)))
# /tmp/mfuncs/TF127_NoiseBursts.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF127_NoiseBursts.m:14
    meta.ID = copy('TF127')
# /tmp/mfuncs/TF127_NoiseBursts.m:15
    meta.Name = copy('Noise Bursts')
# /tmp/mfuncs/TF127_NoiseBursts.m:16
    meta.Category = copy(8)
# /tmp/mfuncs/TF127_NoiseBursts.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF127_NoiseBursts.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF127_NoiseBursts.m:19
    meta.Morphology = copy('Low-frequency sine with localized noisy bursts')
# /tmp/mfuncs/TF127_NoiseBursts.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    