# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF140_BridgeStrainEvent(N=None,baseline=None,trendAmp=None,trendSlope=None,bumpCenters=None,bumpAmp=None,bumpW=None,eventOnset=None,eventStep=None,eventOscAmp=None,eventOscFreq=None,eventDecay=None,*args,**kwargs):
    varargin = TF140_BridgeStrainEvent.varargin
    nargin = TF140_BridgeStrainEvent.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.18
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:3
    
    if nargin < 3 or isempty(trendAmp):
        trendAmp=0.16
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:4
    
    if nargin < 4 or isempty(trendSlope):
        trendSlope=0.16
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:5
    
    if nargin < 5 or isempty(bumpCenters):
        bumpCenters=concat([0.18,0.34,0.52,0.76])
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:6
    
    if nargin < 6 or isempty(bumpAmp):
        bumpAmp=0.16
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:7
    
    if nargin < 7 or isempty(bumpW):
        bumpW=0.025
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:8
    
    if nargin < 8 or isempty(eventOnset):
        eventOnset=0.62
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:9
    
    if nargin < 9 or isempty(eventStep):
        eventStep=0.1
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:10
    
    if nargin < 10 or isempty(eventOscAmp):
        eventOscAmp=0.1
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:11
    
    if nargin < 11 or isempty(eventOscFreq):
        eventOscFreq=28
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:12
    
    if nargin < 12 or isempty(eventDecay):
        eventDecay=12
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:15
    f=baseline + dot(trendAmp,x) + dot(0.05,sin(dot(dot(dot(2,pi),1.5),x)))
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:16
    for c in bumpCenters.reshape(-1):
        f=f + dot(bumpAmp,exp(dot(- 0.5,((x - c) / bumpW) ** 2)))
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:18
    
    u=max(x - eventOnset,0)
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:20
    f=f + dot(eventStep,S(x,eventOnset,0.004)) + multiply(multiply(multiply((x >= eventOnset),eventOscAmp),exp(dot(- eventDecay,u))),sin(dot(dot(dot(2,pi),eventOscFreq),u)))
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:21
    meta=copy(struct)
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:23
    meta.ID = copy('TF140')
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:24
    meta.Name = copy('Bridge Strain Event')
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:25
    meta.Category = copy(9)
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:28
    meta.Morphology = copy('Baseline trend with localized bumps and a decaying post-event oscillation')
# /tmp/mfuncs/TF140_BridgeStrainEvent.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    