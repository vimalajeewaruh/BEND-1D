# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF203_PupilLightReflex(N=None,respAmp=None,respOnset=None,respTau=None,baselineBumpAmp=None,*args,**kwargs):
    varargin = TF203_PupilLightReflex.varargin
    nargin = TF203_PupilLightReflex.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF203_PupilLightReflex.m:2
    
    if nargin < 2 or isempty(respAmp):
        respAmp=0.72
# /tmp/mfuncs/TF203_PupilLightReflex.m:3
    
    if nargin < 3 or isempty(respOnset):
        respOnset=0.25
# /tmp/mfuncs/TF203_PupilLightReflex.m:4
    
    if nargin < 4 or isempty(respTau):
        respTau=struct('rise',0.014,'decay',0.22)
# /tmp/mfuncs/TF203_PupilLightReflex.m:5
    
    if nargin < 5 or isempty(baselineBumpAmp):
        baselineBumpAmp=0.1
# /tmp/mfuncs/TF203_PupilLightReflex.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF203_PupilLightReflex.m:7
    u=max(x - respOnset,0)
# /tmp/mfuncs/TF203_PupilLightReflex.m:8
    resp=multiply(multiply((x >= respOnset),(1 - exp(- u / respTau.rise))),exp(- u / respTau.decay))
# /tmp/mfuncs/TF203_PupilLightReflex.m:9
    f=1 - dot(respAmp,resp) + dot(baselineBumpAmp,G(x,0.68,0.07))
# /tmp/mfuncs/TF203_PupilLightReflex.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF203_PupilLightReflex.m:11
    meta.ID = copy('TF203')
# /tmp/mfuncs/TF203_PupilLightReflex.m:12
    meta.Name = copy('Pupil Light Reflex')
# /tmp/mfuncs/TF203_PupilLightReflex.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF203_PupilLightReflex.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF203_PupilLightReflex.m:15
    meta.Parameters = copy(struct('respAmp',respAmp,'respOnset',respOnset,'respTau',respTau,'baselineBumpAmp',baselineBumpAmp))
# /tmp/mfuncs/TF203_PupilLightReflex.m:16
    meta.Morphology = copy('Rapid constriction with slow recovery and baseline bump')
# /tmp/mfuncs/TF203_PupilLightReflex.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    