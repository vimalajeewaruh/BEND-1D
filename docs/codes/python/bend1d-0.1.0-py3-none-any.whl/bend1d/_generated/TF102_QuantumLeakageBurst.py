# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF102_QuantumLeakageBurst(N=None,base=None,oscFreq=None,burstCs=None,burstAmp=None,burstW=None,sigA=None,sigB=None,*args,**kwargs):
    varargin = TF102_QuantumLeakageBurst.varargin
    nargin = TF102_QuantumLeakageBurst.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:2
    
    if nargin < 2 or isempty(base):
        base=0.08
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:3
    
    if nargin < 3 or isempty(oscFreq):
        oscFreq=4
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:4
    
    if nargin < 4 or isempty(burstCs):
        burstCs=concat([0.24,0.47,0.71])
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:5
    
    if nargin < 5 or isempty(burstAmp):
        burstAmp=0.2
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:6
    
    if nargin < 6 or isempty(burstW):
        burstW=0.02
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:7
    
    if nargin < 7 or isempty(sigA):
        sigA=0.54
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:8
    
    if nargin < 8 or isempty(sigB):
        sigB=0.64
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:11
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:12
    f=base + dot(0.02,sin(dot(dot(dot(2,pi),oscFreq),x)))
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:13
    for c in burstCs.reshape(-1):
        f=f + dot(burstAmp,exp(dot(- 0.5,((x - c) / burstW) ** 2)))
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:15
    
    f=f + dot(0.1,(S(x,sigA,0.004) - S(x,sigB,0.006)))
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:18
    meta.ID = copy('TF102')
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:19
    meta.Name = copy('Quantum Leakage Burst')
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:23
    meta.Morphology = copy('Baseline oscillation with localized leakage bursts')
# /tmp/mfuncs/TF102_QuantumLeakageBurst.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    