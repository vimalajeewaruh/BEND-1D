# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF025_Platinum5Y(N=None,*args,**kwargs):
    varargin = TF025_Platinum5Y.varargin
    nargin = TF025_Platinum5Y.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF025_Platinum5Y.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF025_Platinum5Y.m:3
    platinumRawUSD=concat([1009,973,1017,1038,945,994,1049,1043,965,958,957,869,909,881,915,989,1011,1053,959,971,1051,1063,971,950,925,921,892,906,935,926,894,909,940,1015,985,979,945,967,999,966,938,949,978,980,959,980,1251,1391,1343,1435,1616,1565,1893,2434,2137,2046,2028,1998,1726,1622])
# /tmp/mfuncs/TF025_Platinum5Y.m:4
    ps=copy(platinumRawUSD)
# /tmp/mfuncs/TF025_Platinum5Y.m:6
    ps[1]=(dot(7,platinumRawUSD(1)) + platinumRawUSD(2)) / 8
# /tmp/mfuncs/TF025_Platinum5Y.m:7
    ps[end()]=(platinumRawUSD(end() - 1) + dot(7,platinumRawUSD(end()))) / 8
# /tmp/mfuncs/TF025_Platinum5Y.m:8
    ps_values=np.asarray(ps).reshape(-1,order='F')
    raw_values=np.asarray(platinumRawUSD).reshape(-1,order='F')
    ps_values[1:-1]=(raw_values[:-2] + 6*raw_values[1:-1] + raw_values[2:]) / 8
    ps=matlabarray(ps_values)
# /tmp/mfuncs/TF025_Platinum5Y.m:9
    tMonth=linspace(0,1,numel(platinumRawUSD))
# /tmp/mfuncs/TF025_Platinum5Y.m:10
    fUSD=interp1(tMonth,ps,x,'pchip')
# /tmp/mfuncs/TF025_Platinum5Y.m:11
    f=(fUSD - mean(fUSD)) / std(fUSD)
# /tmp/mfuncs/TF025_Platinum5Y.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF025_Platinum5Y.m:13
    meta.ID = copy('TF025')
# /tmp/mfuncs/TF025_Platinum5Y.m:14
    meta.Name = copy('Platinum5Y')
# /tmp/mfuncs/TF025_Platinum5Y.m:15
    meta.Category = copy(2)
# /tmp/mfuncs/TF025_Platinum5Y.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF025_Platinum5Y.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF025_Platinum5Y.m:18
    meta.Morphology = copy('5-year monthly platinum price (standardized)')
# /tmp/mfuncs/TF025_Platinum5Y.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
