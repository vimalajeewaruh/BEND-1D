# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF144_NeedleInChirp(N=None,envAmp=None,envSlope=None,chirpAmp=None,needleAmp=None,needleCtr=None,needleW=None,*args,**kwargs):
    varargin = TF144_NeedleInChirp.varargin
    nargin = TF144_NeedleInChirp.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF144_NeedleInChirp.m:2
    
    if nargin < 2 or isempty(envAmp):
        envAmp=0.65
# /tmp/mfuncs/TF144_NeedleInChirp.m:3
    
    if nargin < 3 or isempty(envSlope):
        envSlope=0.35
# /tmp/mfuncs/TF144_NeedleInChirp.m:4
    
    if nargin < 4 or isempty(chirpAmp):
        chirpAmp=0.34
# /tmp/mfuncs/TF144_NeedleInChirp.m:5
    
    if nargin < 5 or isempty(needleAmp):
        needleAmp=0.11
# /tmp/mfuncs/TF144_NeedleInChirp.m:6
    
    if nargin < 6 or isempty(needleCtr):
        needleCtr=0.72
# /tmp/mfuncs/TF144_NeedleInChirp.m:7
    
    if nargin < 7 or isempty(needleW):
        needleW=0.003
# /tmp/mfuncs/TF144_NeedleInChirp.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF144_NeedleInChirp.m:10
    f=multiply(multiply((envAmp + dot(envSlope,x)),chirpAmp),sin(dot(dot(2,pi),(dot(8,x) + dot(26,x ** 2))))) + dot(needleAmp,exp(dot(- 0.5,((x - needleCtr) / needleW) ** 2)))
# /tmp/mfuncs/TF144_NeedleInChirp.m:11
    meta=copy(struct)
# /tmp/mfuncs/TF144_NeedleInChirp.m:12
    meta.ID = copy('TF144')
# /tmp/mfuncs/TF144_NeedleInChirp.m:13
    meta.Name = copy('Needle in Chirp')
# /tmp/mfuncs/TF144_NeedleInChirp.m:14
    meta.Category = copy(9)
# /tmp/mfuncs/TF144_NeedleInChirp.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF144_NeedleInChirp.m:16
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF144_NeedleInChirp.m:17
    meta.Morphology = copy('Chirped oscillation with a sharp localized spike')
# /tmp/mfuncs/TF144_NeedleInChirp.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    