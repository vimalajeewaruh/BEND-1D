# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF154_CompressionStorm(N=None,baseline=None,cCS=None,baseWid=None,widDecay=None,baseAmp=None,ampDecay=None,chirpAmp=None,chirpPhase=None,*args,**kwargs):
    varargin = TF154_CompressionStorm.varargin
    nargin = TF154_CompressionStorm.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF154_CompressionStorm.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.05
# /tmp/mfuncs/TF154_CompressionStorm.m:3
    
    if nargin < 3 or isempty(cCS):
        cCS=concat([0.18,0.36,0.52,0.64,0.73,0.795,0.842,0.876,0.902,0.922,0.938])
# /tmp/mfuncs/TF154_CompressionStorm.m:4
    
    if nargin < 4 or isempty(baseWid):
        baseWid=0.025
# /tmp/mfuncs/TF154_CompressionStorm.m:5
    
    if nargin < 5 or isempty(widDecay):
        widDecay=0.76
# /tmp/mfuncs/TF154_CompressionStorm.m:6
    
    if nargin < 6 or isempty(baseAmp):
        baseAmp=0.24
# /tmp/mfuncs/TF154_CompressionStorm.m:7
    
    if nargin < 7 or isempty(ampDecay):
        ampDecay=0.93
# /tmp/mfuncs/TF154_CompressionStorm.m:8
    
    if nargin < 8 or isempty(chirpAmp):
        chirpAmp=0.12
# /tmp/mfuncs/TF154_CompressionStorm.m:9
    
    if nargin < 9 or isempty(chirpPhase):
        chirpPhase=0
# /tmp/mfuncs/TF154_CompressionStorm.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF154_CompressionStorm.m:12
    f=dot(baseline,ones(size(x)))
# /tmp/mfuncs/TF154_CompressionStorm.m:13
    for k in arange(1,numel(cCS)).reshape(-1):
        wid=dot(baseWid,(widDecay ** (k - 1)))
# /tmp/mfuncs/TF154_CompressionStorm.m:15
        amp=dot(baseAmp,(ampDecay ** (k - 1)))
# /tmp/mfuncs/TF154_CompressionStorm.m:16
        f=f + dot(dot(amp,(- 1) ** (k + 1)),exp(dot(- 0.5,((x - cCS(k)) / wid) ** 2)))
# /tmp/mfuncs/TF154_CompressionStorm.m:17
    
    f=f + dot(dot(chirpAmp,x ** 2.0),sin(dot(dot(2,pi),(dot(6,x) + dot(45,x ** 3))) + chirpPhase))
# /tmp/mfuncs/TF154_CompressionStorm.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF154_CompressionStorm.m:20
    meta.ID = copy('TF154')
# /tmp/mfuncs/TF154_CompressionStorm.m:21
    meta.Name = copy('Compression Storm')
# /tmp/mfuncs/TF154_CompressionStorm.m:22
    meta.Category = copy(9)
# /tmp/mfuncs/TF154_CompressionStorm.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF154_CompressionStorm.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF154_CompressionStorm.m:25
    meta.Morphology = copy('Sequence of alternating Gaussians with compressing width and chirped modulation')
# /tmp/mfuncs/TF154_CompressionStorm.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    