# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF106_NanoporeCurrent(N=None,levels=None,edges=None,transAmp1=None,transC1=None,transW1=None,transAmp2=None,transC2=None,transW2=None,*args,**kwargs):
    varargin = TF106_NanoporeCurrent.varargin
    nargin = TF106_NanoporeCurrent.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF106_NanoporeCurrent.m:2
    
    if nargin < 2 or isempty(levels):
        levels=concat([0.72,0.5,0.64,0.39,0.58,0.46])
# /tmp/mfuncs/TF106_NanoporeCurrent.m:3
    
    if nargin < 3 or isempty(edges):
        edges=concat([0,0.16,0.31,0.5,0.67,0.82,1])
# /tmp/mfuncs/TF106_NanoporeCurrent.m:4
    
    if nargin < 4 or isempty(transAmp1):
        transAmp1=0.05
# /tmp/mfuncs/TF106_NanoporeCurrent.m:5
    
    if nargin < 5 or isempty(transC1):
        transC1=0.545
# /tmp/mfuncs/TF106_NanoporeCurrent.m:6
    
    if nargin < 6 or isempty(transW1):
        transW1=0.008
# /tmp/mfuncs/TF106_NanoporeCurrent.m:7
    
    if nargin < 7 or isempty(transAmp2):
        transAmp2=- 0.1
# /tmp/mfuncs/TF106_NanoporeCurrent.m:8
    
    if nargin < 8 or isempty(transC2):
        transC2=0.735
# /tmp/mfuncs/TF106_NanoporeCurrent.m:9
    
    if nargin < 9 or isempty(transW2):
        transW2=0.004
# /tmp/mfuncs/TF106_NanoporeCurrent.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF106_NanoporeCurrent.m:12
    f=zeros(size(x))
# /tmp/mfuncs/TF106_NanoporeCurrent.m:13
    for k in arange(1,numel(levels)).reshape(-1):
        idx=logical_and((x >= edges(k)),(x < edges(k + 1)))
# /tmp/mfuncs/TF106_NanoporeCurrent.m:15
        f[idx]=levels(k)
# /tmp/mfuncs/TF106_NanoporeCurrent.m:16
    
    f[x >= edges(end() - 1)]=levels(end())
# /tmp/mfuncs/TF106_NanoporeCurrent.m:18
    f=f + dot(transAmp1,exp(dot(- 0.5,((x - transC1) / transW1) ** 2))) + dot(transAmp2,exp(dot(- 0.5,((x - transC2) / transW2) ** 2)))
# /tmp/mfuncs/TF106_NanoporeCurrent.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF106_NanoporeCurrent.m:20
    meta.ID = copy('TF106')
# /tmp/mfuncs/TF106_NanoporeCurrent.m:21
    meta.Name = copy('Nanopore Current')
# /tmp/mfuncs/TF106_NanoporeCurrent.m:22
    meta.Category = copy(6)
# /tmp/mfuncs/TF106_NanoporeCurrent.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF106_NanoporeCurrent.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF106_NanoporeCurrent.m:25
    meta.Morphology = copy('Step-like current with brief transients')
# /tmp/mfuncs/TF106_NanoporeCurrent.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    