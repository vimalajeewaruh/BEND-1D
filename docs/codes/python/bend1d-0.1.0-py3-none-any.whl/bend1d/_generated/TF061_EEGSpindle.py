# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF061_EEGSpindle(N=None,background_amp1=None,background_freq1=None,background_phase1=None,background_amp2=None,background_freq2=None,background_phase2=None,env_ctr=None,env_w=None,spindle_a=None,spindle_basefreq=None,spindle_freqmod_ctr=None,spindle_freqmod_coeff=None,*args,**kwargs):
    varargin = TF061_EEGSpindle.varargin
    nargin = TF061_EEGSpindle.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF061_EEGSpindle.m:2
    
    if nargin < 2 or isempty(background_amp1):
        background_amp1=0.055
# /tmp/mfuncs/TF061_EEGSpindle.m:3
    
    if nargin < 3 or isempty(background_freq1):
        background_freq1=4.2
# /tmp/mfuncs/TF061_EEGSpindle.m:4
    
    if nargin < 4 or isempty(background_phase1):
        background_phase1=0.3
# /tmp/mfuncs/TF061_EEGSpindle.m:5
    
    if nargin < 5 or isempty(background_amp2):
        background_amp2=0.028
# /tmp/mfuncs/TF061_EEGSpindle.m:6
    
    if nargin < 6 or isempty(background_freq2):
        background_freq2=7.1
# /tmp/mfuncs/TF061_EEGSpindle.m:7
    
    if nargin < 7 or isempty(background_phase2):
        background_phase2=- 0.5
# /tmp/mfuncs/TF061_EEGSpindle.m:8
    
    if nargin < 8 or isempty(env_ctr):
        env_ctr=0.56
# /tmp/mfuncs/TF061_EEGSpindle.m:9
    
    if nargin < 9 or isempty(env_w):
        env_w=0.115
# /tmp/mfuncs/TF061_EEGSpindle.m:10
    
    if nargin < 10 or isempty(spindle_a):
        spindle_a=0.39
# /tmp/mfuncs/TF061_EEGSpindle.m:11
    
    if nargin < 11 or isempty(spindle_basefreq):
        spindle_basefreq=20
# /tmp/mfuncs/TF061_EEGSpindle.m:12
    
    if nargin < 12 or isempty(spindle_freqmod_ctr):
        spindle_freqmod_ctr=0.56
# /tmp/mfuncs/TF061_EEGSpindle.m:13
    
    if nargin < 13 or isempty(spindle_freqmod_coeff):
        spindle_freqmod_coeff=2.2
# /tmp/mfuncs/TF061_EEGSpindle.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF061_EEGSpindle.m:16
    backgroundEEG=dot(background_amp1,sin(dot(dot(dot(2,pi),background_freq1),x) + background_phase1)) + dot(background_amp2,sin(dot(dot(dot(2,pi),background_freq2),x) + background_phase2))
# /tmp/mfuncs/TF061_EEGSpindle.m:17
    envSpindle=exp(dot(- 0.5,((x - env_ctr) / env_w) ** 2))
# /tmp/mfuncs/TF061_EEGSpindle.m:19
    phaseSpindle=dot(dot(2,pi),(dot(spindle_basefreq,x) + dot(spindle_freqmod_coeff,(x - spindle_freqmod_ctr) ** 2)))
# /tmp/mfuncs/TF061_EEGSpindle.m:20
    spindle=multiply(dot(spindle_a,envSpindle),sin(phaseSpindle))
# /tmp/mfuncs/TF061_EEGSpindle.m:21
    f=backgroundEEG + spindle
# /tmp/mfuncs/TF061_EEGSpindle.m:22
    meta=copy(struct)
# /tmp/mfuncs/TF061_EEGSpindle.m:24
    meta.ID = copy('TF061')
# /tmp/mfuncs/TF061_EEGSpindle.m:25
    meta.Name = copy('EEG Spindle')
# /tmp/mfuncs/TF061_EEGSpindle.m:26
    meta.Category = copy(5)
# /tmp/mfuncs/TF061_EEGSpindle.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF061_EEGSpindle.m:28
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF061_EEGSpindle.m:29
    meta.Morphology = copy('Low-frequency background with a localized, mildly frequency-modulated spindle burst')
# /tmp/mfuncs/TF061_EEGSpindle.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    