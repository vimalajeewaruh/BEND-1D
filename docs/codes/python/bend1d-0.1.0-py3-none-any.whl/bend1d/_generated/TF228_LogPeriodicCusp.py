# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF228_LogPeriodicCusp(N=None,xc=None,pow=None,modAmp=None,freq=None,eps=None,*args,**kwargs):
    varargin = TF228_LogPeriodicCusp.varargin
    nargin = TF228_LogPeriodicCusp.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:2
    
    if nargin < 2 or isempty(xc):
        xc=0.57
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:3
    
    if nargin < 3 or isempty(pow):
        pow=0.34
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:4
    
    if nargin < 4 or isempty(modAmp):
        modAmp=0.62
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:5
    
    if nargin < 5 or isempty(freq):
        freq=10.5
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:6
    
    if nargin < 6 or isempty(eps):
        eps=0.0025
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:8
    u=x - xc
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:9
    au=abs(u)
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:9
    f=multiply(au ** pow,(1 + dot(modAmp,sin(dot(freq,log(au + eps))))))
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:10
    f=f - mean(f)
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:11
    f=f / max(abs(f))
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:13
    meta.ID = copy('TF228')
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:14
    meta.Name = copy('Log-Periodic Cusp')
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:15
    meta.Category = copy(12)
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:17
    meta.Parameters = copy(struct('xc',xc,'pow',pow,'modAmp',modAmp,'freq',freq,'eps',eps))
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:18
    meta.Morphology = copy('Cusp with log-periodic modulation')
# /tmp/mfuncs/TF228_LogPeriodicCusp.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    