# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF161_CapnogramBreaths(N=None,startsCB=None,*args,**kwargs):
    varargin = TF161_CapnogramBreaths.varargin
    nargin = TF161_CapnogramBreaths.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF161_CapnogramBreaths.m:2
    
    if nargin < 2 or isempty(startsCB):
        startsCB=concat([0.01,0.205,0.4,0.595,0.79])
# /tmp/mfuncs/TF161_CapnogramBreaths.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF161_CapnogramBreaths.m:4
    f=zeros(size(x))
# /tmp/mfuncs/TF161_CapnogramBreaths.m:5
    for k in arange(1,numel(startsCB)).reshape(-1):
        rise=startsCB(k) + 0.045
# /tmp/mfuncs/TF161_CapnogramBreaths.m:7
        fall=startsCB(k) + 0.145
# /tmp/mfuncs/TF161_CapnogramBreaths.m:8
        gate=S(x,rise,0.0035) - S(x,fall,0.0035)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:9
        slope=0.8 + dot(0.12,(x - rise)) / (fall - rise)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:10
        if k == 4:
            slope=0.7 + dot(0.34,(x - rise)) / (fall - rise)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:12
        f=f + multiply(gate,slope)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:14
    
    f=f - dot(0.12,exp(dot(- 0.5,((x - 0.685) / 0.009) ** 2)))
# /tmp/mfuncs/TF161_CapnogramBreaths.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:17
    meta.ID = copy('TF161')
# /tmp/mfuncs/TF161_CapnogramBreaths.m:18
    meta.Name = copy('Capnogram Breaths')
# /tmp/mfuncs/TF161_CapnogramBreaths.m:19
    meta.Category = copy(9)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF161_CapnogramBreaths.m:22
    meta.Morphology = copy('Series of breaths modeled with gated rises and falls')
# /tmp/mfuncs/TF161_CapnogramBreaths.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    