# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF049_Seismogram(N=None,baseline_a=None,p_ctr=None,p_w=None,p_amp=None,s_ctr=None,s_w=None,s_amp=None,c_amp=None,c_ctr=None,c_decay=None,c1_freq=None,c2_amp=None,c2_freq=None,*args,**kwargs):
    varargin = TF049_Seismogram.varargin
    nargin = TF049_Seismogram.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF049_Seismogram.m:2
    
    if nargin < 2 or isempty(baseline_a):
        baseline_a=0.01
# /tmp/mfuncs/TF049_Seismogram.m:3
    
    if nargin < 3 or isempty(p_ctr):
        p_ctr=0.25
# /tmp/mfuncs/TF049_Seismogram.m:4
    
    if nargin < 4 or isempty(p_w):
        p_w=0.028
# /tmp/mfuncs/TF049_Seismogram.m:5
    
    if nargin < 5 or isempty(p_amp):
        p_amp=0.42
# /tmp/mfuncs/TF049_Seismogram.m:6
    
    if nargin < 6 or isempty(s_ctr):
        s_ctr=0.43
# /tmp/mfuncs/TF049_Seismogram.m:7
    
    if nargin < 7 or isempty(s_w):
        s_w=0.055
# /tmp/mfuncs/TF049_Seismogram.m:8
    
    if nargin < 8 or isempty(s_amp):
        s_amp=1.0
# /tmp/mfuncs/TF049_Seismogram.m:9
    
    if nargin < 9 or isempty(c_amp):
        c_amp=0.4
# /tmp/mfuncs/TF049_Seismogram.m:10
    
    if nargin < 10 or isempty(c_ctr):
        c_ctr=0.47
# /tmp/mfuncs/TF049_Seismogram.m:11
    
    if nargin < 11 or isempty(c_decay):
        c_decay=4.8
# /tmp/mfuncs/TF049_Seismogram.m:12
    
    if nargin < 12 or isempty(c1_freq):
        c1_freq=31
# /tmp/mfuncs/TF049_Seismogram.m:13
    
    if nargin < 13 or isempty(c2_amp):
        c2_amp=0.35
# /tmp/mfuncs/TF049_Seismogram.m:14
    
    if nargin < 14 or isempty(c2_freq):
        c2_freq=59
# /tmp/mfuncs/TF049_Seismogram.m:15
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF049_Seismogram.m:17
    f=dot(baseline_a,sin(dot(dot(dot(2,pi),4),x)))
# /tmp/mfuncs/TF049_Seismogram.m:18
    wP=exp(dot(- 0.5,((x - p_ctr) / p_w) ** 2))
# /tmp/mfuncs/TF049_Seismogram.m:19
    pWave=multiply(dot(p_amp,wP),sin(dot(dot(2,pi),(dot(38,x) + dot(24,x ** 2)))))
# /tmp/mfuncs/TF049_Seismogram.m:20
    wS=exp(dot(- 0.5,((x - s_ctr) / s_w) ** 2))
# /tmp/mfuncs/TF049_Seismogram.m:21
    sWave=multiply(dot(s_amp,wS),(sin(dot(dot(dot(2,pi),24),x)) + dot(0.28,sin(dot(dot(dot(2,pi),51),x) + 0.5))))
# /tmp/mfuncs/TF049_Seismogram.m:22
    uC=max(x - c_ctr,0)
# /tmp/mfuncs/TF049_Seismogram.m:23
    coda=multiply(multiply(multiply((x >= c_ctr),c_amp),exp(dot(- c_decay,uC))),(sin(dot(dot(dot(2,pi),c1_freq),uC)) + dot(c2_amp,sin(dot(dot(dot(2,pi),c2_freq),uC) + 0.6))))
# /tmp/mfuncs/TF049_Seismogram.m:24
    f=f + pWave + sWave + coda
# /tmp/mfuncs/TF049_Seismogram.m:25
    meta=copy(struct)
# /tmp/mfuncs/TF049_Seismogram.m:26
    meta.ID = copy('TF049')
# /tmp/mfuncs/TF049_Seismogram.m:27
    meta.Name = copy('Seismogram')
# /tmp/mfuncs/TF049_Seismogram.m:28
    meta.Category = copy(4)
# /tmp/mfuncs/TF049_Seismogram.m:29
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF049_Seismogram.m:30
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF049_Seismogram.m:31
    meta.Morphology = copy('P- and S-wave packets with long coda on quiet baseline')
# /tmp/mfuncs/TF049_Seismogram.m:32
    return x,f,meta
    
if __name__ == '__main__':
    pass
    