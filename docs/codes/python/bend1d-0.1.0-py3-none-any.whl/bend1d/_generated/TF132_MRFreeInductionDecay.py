# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF132_MRFreeInductionDecay(N=None,a1=None,a2=None,a3=None,a4=None,decay=None,f1=None,f2=None,f3=None,f4=None,phases=None,*args,**kwargs):
    varargin = TF132_MRFreeInductionDecay.varargin
    nargin = TF132_MRFreeInductionDecay.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:2
    
    if nargin < 2 or isempty(a1):
        a1=0.55
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:3
    
    if nargin < 3 or isempty(a2):
        a2=0.34
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:4
    
    if nargin < 4 or isempty(a3):
        a3=0.18
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:5
    
    if nargin < 5 or isempty(a4):
        a4=0.06
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:6
    
    if nargin < 6 or isempty(decay):
        decay=concat([3.5,7,1.2,0.55])
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:7
    
    if nargin < 7 or isempty(f1):
        f1=concat([18,31,8,43])
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:8
    
    if nargin < 8 or isempty(phases):
        phases=concat([0,0.3,- 0.5,0.8])
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:11
    f=multiply(dot(a1,exp(dot(- decay(1),x))),cos(dot(dot(dot(2,pi),f1(1)),x) + phases(1))) + multiply(dot(a2,exp(dot(- decay(2),x))),cos(dot(dot(dot(2,pi),f1(2)),x) + phases(2))) + multiply(dot(a3,exp(dot(- decay(3),x))),cos(dot(dot(dot(2,pi),f1(3)),x) + phases(3))) + multiply(dot(a4,exp(dot(- decay(4),x))),cos(dot(dot(dot(2,pi),f1(4)),x) + phases(4)))
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:13
    meta.ID = copy('TF132')
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:14
    meta.Name = copy('MR Free Induction Decay')
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:15
    meta.Category = copy(9)
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:18
    meta.Morphology = copy('Sum of damped cosines with different decay rates and frequencies')
# /tmp/mfuncs/TF132_MRFreeInductionDecay.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    