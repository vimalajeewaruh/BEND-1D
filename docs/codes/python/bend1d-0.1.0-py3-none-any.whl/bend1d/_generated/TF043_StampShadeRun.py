# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF043_StampShadeRun(N=None,base_a=None,base_b=None,base_c=None,batch_amp=None,batch_ctr=None,batch_w=None,late_amp=None,late_ctr=None,small_amp=None,small_freq=None,*args,**kwargs):
    varargin = TF043_StampShadeRun.varargin
    nargin = TF043_StampShadeRun.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF043_StampShadeRun.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=0.2
# /tmp/mfuncs/TF043_StampShadeRun.m:3
    
    if nargin < 3 or isempty(base_b):
        base_b=0.34
# /tmp/mfuncs/TF043_StampShadeRun.m:4
    
    if nargin < 4 or isempty(base_c):
        base_c=0.035
# /tmp/mfuncs/TF043_StampShadeRun.m:5
    
    if nargin < 5 or isempty(batch_amp):
        batch_amp=0.18
# /tmp/mfuncs/TF043_StampShadeRun.m:6
    
    if nargin < 6 or isempty(batch_ctr):
        batch_ctr=0.47
# /tmp/mfuncs/TF043_StampShadeRun.m:7
    
    if nargin < 7 or isempty(batch_w):
        batch_w=180
# /tmp/mfuncs/TF043_StampShadeRun.m:8
    
    if nargin < 8 or isempty(late_amp):
        late_amp=- 0.22
# /tmp/mfuncs/TF043_StampShadeRun.m:9
    
    if nargin < 9 or isempty(late_ctr):
        late_ctr=0.47
# /tmp/mfuncs/TF043_StampShadeRun.m:10
    
    if nargin < 10 or isempty(small_amp):
        small_amp=0.018
# /tmp/mfuncs/TF043_StampShadeRun.m:11
    
    if nargin < 11 or isempty(small_freq):
        small_freq=17
# /tmp/mfuncs/TF043_StampShadeRun.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF043_StampShadeRun.m:14
    baseShade=base_a + dot(base_b,x) + dot(base_c,sin(dot(dot(dot(2,pi),2.2),x)))
# /tmp/mfuncs/TF043_StampShadeRun.m:15
    batchJump=batch_amp / (1 + exp(dot(- batch_w,(x - batch_ctr))))
# /tmp/mfuncs/TF043_StampShadeRun.m:16
    lateDrift=dot(late_amp,max(x - late_ctr,0))
# /tmp/mfuncs/TF043_StampShadeRun.m:17
    smallRunStructure=multiply(dot(small_amp,sin(dot(dot(dot(2,pi),small_freq),x))),(0.35 + dot(0.65,x)))
# /tmp/mfuncs/TF043_StampShadeRun.m:18
    f=baseShade + batchJump + lateDrift + smallRunStructure
# /tmp/mfuncs/TF043_StampShadeRun.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF043_StampShadeRun.m:20
    meta.ID = copy('TF043')
# /tmp/mfuncs/TF043_StampShadeRun.m:21
    meta.Name = copy('Stamp Shade Run')
# /tmp/mfuncs/TF043_StampShadeRun.m:22
    meta.Category = copy(4)
# /tmp/mfuncs/TF043_StampShadeRun.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF043_StampShadeRun.m:24
    meta.Parameters = copy(struct('base_a',base_a,'base_b',base_b,'base_c',base_c,'batch_amp',batch_amp,'batch_ctr',batch_ctr,'batch_w',batch_w,'late_amp',late_amp,'late_ctr',late_ctr,'small_amp',small_amp,'small_freq',small_freq))
# /tmp/mfuncs/TF043_StampShadeRun.m:25
    meta.Morphology = copy('Smooth press/ink drift with discrete replenishment and fine run structure')
# /tmp/mfuncs/TF043_StampShadeRun.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    