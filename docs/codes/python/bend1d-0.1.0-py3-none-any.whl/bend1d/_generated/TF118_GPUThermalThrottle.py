# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF118_GPUThermalThrottle(N=None,base=None,stepC1=None,stepW1=None,stepAmp=None,stepC2=None,stepW2=None,oscAmp=None,oscFreq=None,oscWindowW=None,*args,**kwargs):
    varargin = TF118_GPUThermalThrottle.varargin
    nargin = TF118_GPUThermalThrottle.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:2
    
    if nargin < 2 or isempty(base):
        base=0.2
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:3
    
    if nargin < 3 or isempty(stepC1):
        stepC1=0.28
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:4
    
    if nargin < 4 or isempty(stepW1):
        stepW1=0.06
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:5
    
    if nargin < 5 or isempty(stepAmp):
        stepAmp=0.55
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:6
    
    if nargin < 6 or isempty(stepC2):
        stepC2=0.64
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:7
    
    if nargin < 7 or isempty(stepW2):
        stepW2=0.008
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:8
    
    if nargin < 8 or isempty(oscAmp):
        oscAmp=0.06
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:9
    
    if nargin < 9 or isempty(oscFreq):
        oscFreq=8
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:10
    
    if nargin < 10 or isempty(oscWindowW):
        oscWindowW=0.01
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:13
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:14
    f=base + dot(stepAmp,S(x,stepC1,stepW1))
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:15
    f=f - dot(0.22,S(x,stepC2,stepW2)) + multiply(dot(oscAmp,sin(dot(dot(dot(2,pi),oscFreq),x))),S(x,stepC2,oscWindowW))
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:17
    meta.ID = copy('TF118')
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:18
    meta.Name = copy('GPU Thermal Throttle')
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:19
    meta.Category = copy(6)
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:22
    meta.Morphology = copy('Thermal step with throttling oscillation')
# /tmp/mfuncs/TF118_GPUThermalThrottle.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    