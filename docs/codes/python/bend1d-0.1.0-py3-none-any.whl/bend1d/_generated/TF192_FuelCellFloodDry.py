# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF192_FuelCellFloodDry(N=None,f0=None,c=None,a=None,tf=None,ts=None,*args,**kwargs):
    varargin = TF192_FuelCellFloodDry.varargin
    nargin = TF192_FuelCellFloodDry.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:2
    
    if nargin < 2 or isempty(f0):
        f0=0.82
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:3
    
    if nargin < 3 or isempty(c):
        c=concat([0.2,0.5,0.76])
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:4
    
    if nargin < 4 or isempty(a):
        a=concat([0.36,0.48,0.32])
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:5
    
    if nargin < 5 or isempty(tf):
        tf=concat([0.01,0.012,0.008])
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:6
    
    if nargin < 6 or isempty(ts):
        ts=concat([0.095,0.135,0.08])
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:8
    f=f0 + dot(0.03,sin(dot(dot(dot(2,pi),2),x)))
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:9
    for k in arange(1,numel(c)).reshape(-1):
        u=max(x - c(k),0)
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:11
        f=f - multiply(multiply(multiply((x >= c(k)),a(k)),(1 - exp(- u / tf(k)))),exp(- u / ts(k)))
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:14
    meta.ID = copy('TF192')
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:15
    meta.Name = copy('Fuel-cell Flood/Dry Cycles')
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:16
    meta.Category = copy(10)
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:18
    meta.Parameters = copy(struct('baseline',f0,'centers',c,'amps',a,'tf',tf,'ts',ts))
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:19
    meta.Morphology = copy('Transient flooding events with slow drainage')
# /tmp/mfuncs/TF192_FuelCellFloodDry.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    