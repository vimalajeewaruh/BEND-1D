# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF023_RabiChirp(N=None,*args,**kwargs):
    varargin = TF023_RabiChirp.varargin
    nargin = TF023_RabiChirp.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF023_RabiChirp.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF023_RabiChirp.m:3
    phaseR=dot(dot(2,pi),(dot(3,x) + dot(7,x ** 2)))
# /tmp/mfuncs/TF023_RabiChirp.m:4
    f=multiply(exp(dot(- 0.9,x)),sin(phaseR) ** 2)
# /tmp/mfuncs/TF023_RabiChirp.m:5
    meta=copy(struct)
# /tmp/mfuncs/TF023_RabiChirp.m:6
    meta.ID = copy('TF023')
# /tmp/mfuncs/TF023_RabiChirp.m:7
    meta.Name = copy('Rabi Chirp')
# /tmp/mfuncs/TF023_RabiChirp.m:8
    meta.Category = copy(2)
# /tmp/mfuncs/TF023_RabiChirp.m:9
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF023_RabiChirp.m:10
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF023_RabiChirp.m:11
    meta.Morphology = copy('Chirped population oscillation with decoherence')
# /tmp/mfuncs/TF023_RabiChirp.m:12
    return x,f,meta
    
if __name__ == '__main__':
    pass
    