# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF197_ModeBeatingDecay(N=None,amp1=None,amp2=None,amp3=None,*args,**kwargs):
    varargin = TF197_ModeBeatingDecay.varargin
    nargin = TF197_ModeBeatingDecay.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:2
    
    if nargin < 2 or isempty(amp1):
        amp1=1
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:3
    
    if nargin < 3 or isempty(amp2):
        amp2=0.93
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:4
    
    if nargin < 4 or isempty(amp3):
        amp3=0.28
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:6
    f=dot(multiply(exp(dot(- 2.4,x)),(sin(dot(dot(dot(2,pi),15),x)) + dot(amp2,sin(dot(dot(dot(2,pi),16.4),x) + 0.15)))),amp1) + multiply(dot(amp3,exp(dot(- 5.8,x))),sin(dot(dot(dot(2,pi),33),x) + 0.6))
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:7
    meta=copy(struct)
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:9
    meta.ID = copy('TF197')
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:10
    meta.Name = copy('Mode Beating Decay')
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:11
    meta.Category = copy(10)
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:13
    meta.Parameters = copy(struct('amp1',amp1,'amp2',amp2,'amp3',amp3))
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:14
    meta.Morphology = copy('Beating modes with exponential decay')
# /tmp/mfuncs/TF197_ModeBeatingDecay.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    