# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF036_GearDefect(N=None,shaft=None,mesh=None,phaseGear=None,ampGear=None,localDefect=None,*args,**kwargs):
    varargin = TF036_GearDefect.varargin
    nargin = TF036_GearDefect.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF036_GearDefect.m:2
    
    if nargin < 2 or isempty(shaft):
        shaft=3.2
# /tmp/mfuncs/TF036_GearDefect.m:3
    
    if nargin < 3 or isempty(mesh):
        mesh=31
# /tmp/mfuncs/TF036_GearDefect.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF036_GearDefect.m:5
    if nargin < 4 or isempty(phaseGear):
        phaseGear=dot(dot(dot(2,pi),mesh),x) + dot(0.22,sin(dot(dot(dot(2,pi),shaft),x)))
# /tmp/mfuncs/TF036_GearDefect.m:7
    else:
        if isscalar(phaseGear):
            phaseGear=repmat(phaseGear,size(x))
# /tmp/mfuncs/TF036_GearDefect.m:9
        else:
            phaseGear=interp1(linspace(0,1,numel(phaseGear)),phaseGear,x,'linear',phaseGear(end()))
# /tmp/mfuncs/TF036_GearDefect.m:11
    
    if nargin < 5 or isempty(ampGear):
        ampGear=0.78 + dot(0.22,cos(dot(dot(dot(2,pi),shaft),x)))
# /tmp/mfuncs/TF036_GearDefect.m:14
    else:
        if isscalar(ampGear):
            ampGear=repmat(ampGear,size(x))
# /tmp/mfuncs/TF036_GearDefect.m:16
        else:
            ampGear=interp1(linspace(0,1,numel(ampGear)),ampGear,x,'linear',ampGear(end()))
# /tmp/mfuncs/TF036_GearDefect.m:18
    
    carrierGear=multiply(ampGear,sin(phaseGear)) + dot(0.2,sin(dot(2,phaseGear) - 0.35))
# /tmp/mfuncs/TF036_GearDefect.m:20
    if nargin < 6 or isempty(localDefect):
        localDefect=multiply(dot(0.7,exp(dot(- 0.5,((x - 0.63) / 0.035) ** 2))),sin(dot(dot(dot(2,pi),36),x) + 0.8))
# /tmp/mfuncs/TF036_GearDefect.m:22
    else:
        if isscalar(localDefect):
            localDefect=repmat(localDefect,size(x))
# /tmp/mfuncs/TF036_GearDefect.m:24
        else:
            localDefect=interp1(linspace(0,1,numel(localDefect)),localDefect,x,'linear',localDefect(end()))
# /tmp/mfuncs/TF036_GearDefect.m:26
    
    f=carrierGear + localDefect
# /tmp/mfuncs/TF036_GearDefect.m:28
    meta=copy(struct)
# /tmp/mfuncs/TF036_GearDefect.m:29
    meta.ID = copy('TF036')
# /tmp/mfuncs/TF036_GearDefect.m:30
    meta.Name = copy('Gear Defect')
# /tmp/mfuncs/TF036_GearDefect.m:31
    meta.Category = copy(3)
# /tmp/mfuncs/TF036_GearDefect.m:32
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF036_GearDefect.m:33
    meta.Parameters = copy(struct('shaft',shaft,'mesh',mesh,'phaseGear',phaseGear,'ampGear',ampGear,'localDefect',localDefect))
# /tmp/mfuncs/TF036_GearDefect.m:34
    meta.Morphology = copy('Gear-mesh carrier with shaft modulation and a localized defect-enhanced packet')
# /tmp/mfuncs/TF036_GearDefect.m:35
    return x,f,meta
    
if __name__ == '__main__':
    pass
    