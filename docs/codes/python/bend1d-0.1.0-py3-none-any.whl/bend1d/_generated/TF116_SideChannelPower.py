# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF116_SideChannelPower(N=None,base=None,lfAmp=None,burstAmp=None,burstDecay=None,ringFreq=None,ringAmp=None,*args,**kwargs):
    varargin = TF116_SideChannelPower.varargin
    nargin = TF116_SideChannelPower.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF116_SideChannelPower.m:2
    
    if nargin < 2 or isempty(base):
        base=0.1
# /tmp/mfuncs/TF116_SideChannelPower.m:3
    
    if nargin < 3 or isempty(lfAmp):
        lfAmp=0.018
# /tmp/mfuncs/TF116_SideChannelPower.m:4
    
    if nargin < 4 or isempty(burstAmp):
        burstAmp=0.24
# /tmp/mfuncs/TF116_SideChannelPower.m:5
    
    if nargin < 5 or isempty(burstDecay):
        burstDecay=60
# /tmp/mfuncs/TF116_SideChannelPower.m:6
    
    if nargin < 6 or isempty(ringFreq):
        ringFreq=75
# /tmp/mfuncs/TF116_SideChannelPower.m:7
    
    if nargin < 7 or isempty(ringAmp):
        ringAmp=0.055
# /tmp/mfuncs/TF116_SideChannelPower.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF116_SideChannelPower.m:10
    f=base + dot(lfAmp,sin(dot(dot(dot(2,pi),3),x)))
# /tmp/mfuncs/TF116_SideChannelPower.m:11
    for c in arange(0.1,0.9,0.11).reshape(-1):
        u=max(x - c,0)
# /tmp/mfuncs/TF116_SideChannelPower.m:13
        f=f + multiply(multiply(dot(burstAmp,(x >= c)),exp(dot(- burstDecay,u))),sin(dot(dot(dot(2,pi),ringFreq),u)))
# /tmp/mfuncs/TF116_SideChannelPower.m:14
    
    f=f + dot(ringAmp,exp(dot(- 0.5,((x - 0.54) / 0.01) ** 2)))
# /tmp/mfuncs/TF116_SideChannelPower.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF116_SideChannelPower.m:17
    meta.ID = copy('TF116')
# /tmp/mfuncs/TF116_SideChannelPower.m:18
    meta.Name = copy('Side Channel Power')
# /tmp/mfuncs/TF116_SideChannelPower.m:19
    meta.Category = copy(6)
# /tmp/mfuncs/TF116_SideChannelPower.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF116_SideChannelPower.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF116_SideChannelPower.m:22
    meta.Morphology = copy('Repeated bursts with high-frequency ringing')
# /tmp/mfuncs/TF116_SideChannelPower.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    