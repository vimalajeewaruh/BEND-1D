# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF002_Planck(N=None,*args,**kwargs):
    varargin = TF002_Planck.varargin
    nargin = TF002_Planck.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF002_Planck.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF002_Planck.m:3
    lambda_=0.08 + dot(0.92,x)
# /tmp/mfuncs/TF002_Planck.m:4
    f=lambda_ ** (- 5) / expm1(2.5 / lambda_)
# /tmp/mfuncs/TF002_Planck.m:5
    meta=copy(struct)
# /tmp/mfuncs/TF002_Planck.m:6
    meta.ID = copy('TF002')
# /tmp/mfuncs/TF002_Planck.m:7
    meta.Name = copy('Planck')
# /tmp/mfuncs/TF002_Planck.m:8
    meta.Category = copy(1)
# /tmp/mfuncs/TF002_Planck.m:9
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF002_Planck.m:10
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF002_Planck.m:11
    meta.Morphology = copy('Smooth broadband spectral shape')
# /tmp/mfuncs/TF002_Planck.m:12
    return x,f,meta
    
if __name__ == '__main__':
    pass
    