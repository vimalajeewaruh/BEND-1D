# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF083_GravitationalWaveChirp(N=None,win_c1=None,win_w1=None,win_c2=None,win_w2=None,phase_coeffs=None,amp_base=None,amp_exp=None,ring_amp=None,ring_start=None,ring_rate=None,ring_freq=None,ring_phase=None,*args,**kwargs):
    varargin = TF083_GravitationalWaveChirp.varargin
    nargin = TF083_GravitationalWaveChirp.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:2
    
    if nargin < 2 or isempty(win_c1):
        win_c1=0.1
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:3
    
    if nargin < 3 or isempty(win_w1):
        win_w1=0.018
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:4
    
    if nargin < 4 or isempty(win_c2):
        win_c2=0.79
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:5
    
    if nargin < 5 or isempty(win_w2):
        win_w2=0.01
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:6
    
    if nargin < 6 or isempty(phase_coeffs):
        phase_coeffs=concat([5,4,18,38])
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:7
    
    if nargin < 7 or isempty(amp_base):
        amp_base=0.06
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:8
    
    if nargin < 8 or isempty(amp_exp):
        amp_exp=2.8
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:9
    
    if nargin < 9 or isempty(ring_amp):
        ring_amp=0.7
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:10
    
    if nargin < 10 or isempty(ring_start):
        ring_start=0.79
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:11
    
    if nargin < 11 or isempty(ring_rate):
        ring_rate=15
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:12
    
    if nargin < 12 or isempty(ring_freq):
        ring_freq=52
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:13
    
    if nargin < 13 or isempty(ring_phase):
        ring_phase=0.3
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:14
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:16
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:17
    chirpWindow=sigmoid(x,win_c1,win_w1) - sigmoid(x,win_c2,win_w2)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:18
    phaseGW=dot(dot(2,pi),(dot(phase_coeffs(1),x) + dot(phase_coeffs(2),x ** 2) + dot(phase_coeffs(3),x ** 4) + dot(phase_coeffs(4),x ** 7)))
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:19
    ampGW=amp_base + dot(0.62,x ** amp_exp)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:20
    chirpGW=multiply(multiply(chirpWindow,ampGW),sin(phaseGW))
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:21
    u=max(x - ring_start,0)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:22
    ringGW=multiply(multiply(multiply((x >= ring_start),ring_amp),exp(dot(- ring_rate,u))),sin(dot(dot(dot(2,pi),ring_freq),u) + ring_phase))
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:23
    f=chirpGW + ringGW
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:24
    meta=copy(struct)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:25
    meta.ID = copy('TF083')
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:26
    meta.Name = copy('Gravitational-Wave Chirp')
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:27
    meta.Category = copy(6)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:30
    meta.Morphology = copy('Chirp with ringdown')
# /tmp/mfuncs/TF083_GravitationalWaveChirp.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    