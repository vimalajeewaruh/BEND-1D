# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF021_Diffraction(N=None,*args,**kwargs):
    varargin = TF021_Diffraction.varargin
    nargin = TF021_Diffraction.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF021_Diffraction.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF021_Diffraction.m:3
    zD=dot(dot(18,pi),(x - 0.5))
# /tmp/mfuncs/TF021_Diffraction.m:4
    sincD=ones(size(x))
# /tmp/mfuncs/TF021_Diffraction.m:5
    nz=abs(zD) > 1e-12
# /tmp/mfuncs/TF021_Diffraction.m:6
    sincD[nz]=sin(zD(nz)) / zD(nz)
# /tmp/mfuncs/TF021_Diffraction.m:7
    fringe=0.18 + dot(0.82,cos(dot(dot(15,pi),(x - 0.5))) ** 2)
# /tmp/mfuncs/TF021_Diffraction.m:8
    zD2=dot(dot(34,pi),(x - 0.67))
# /tmp/mfuncs/TF021_Diffraction.m:9
    sincD2=ones(size(x))
# /tmp/mfuncs/TF021_Diffraction.m:10
    nz2=abs(zD2) > 1e-12
# /tmp/mfuncs/TF021_Diffraction.m:11
    sincD2[nz2]=sin(zD2(nz2)) / zD2(nz2)
# /tmp/mfuncs/TF021_Diffraction.m:12
    f=multiply(sincD ** 2,fringe) + dot(0.1,sincD2 ** 2)
# /tmp/mfuncs/TF021_Diffraction.m:13
    meta=copy(struct)
# /tmp/mfuncs/TF021_Diffraction.m:14
    meta.ID = copy('TF021')
# /tmp/mfuncs/TF021_Diffraction.m:15
    meta.Name = copy('Diffraction')
# /tmp/mfuncs/TF021_Diffraction.m:16
    meta.Category = copy(2)
# /tmp/mfuncs/TF021_Diffraction.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF021_Diffraction.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF021_Diffraction.m:19
    meta.Morphology = copy('Fraunhofer-like sinc^2 envelope with interference fringes')
# /tmp/mfuncs/TF021_Diffraction.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    