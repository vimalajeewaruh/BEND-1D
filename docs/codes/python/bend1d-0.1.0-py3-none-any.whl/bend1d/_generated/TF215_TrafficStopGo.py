# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF215_TrafficStopGo(N=None,base=None,c=None,a=None,tf=None,ts=None,*args,**kwargs):
    varargin = TF215_TrafficStopGo.varargin
    nargin = TF215_TrafficStopGo.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF215_TrafficStopGo.m:2
    
    if nargin < 2 or isempty(base):
        base=0.72
# /tmp/mfuncs/TF215_TrafficStopGo.m:3
    
    if nargin < 3 or isempty(c):
        c=concat([0.18,0.38,0.59,0.78])
# /tmp/mfuncs/TF215_TrafficStopGo.m:4
    
    if nargin < 4 or isempty(a):
        a=concat([0.48,0.38,0.55,0.44])
# /tmp/mfuncs/TF215_TrafficStopGo.m:5
    
    if nargin < 5 or isempty(tf):
        tf=concat([0.015,0.02,0.012,0.018])
# /tmp/mfuncs/TF215_TrafficStopGo.m:6
    
    if nargin < 6 or isempty(ts):
        ts=concat([0.08,0.11,0.09,0.1])
# /tmp/mfuncs/TF215_TrafficStopGo.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF215_TrafficStopGo.m:8
    f=base + dot(0.05,sin(dot(dot(dot(2,pi),0.8),x)))
# /tmp/mfuncs/TF215_TrafficStopGo.m:9
    for k in arange(1,numel(c)).reshape(-1):
        uk=max(x - c(k),0)
# /tmp/mfuncs/TF215_TrafficStopGo.m:11
        f=f - multiply(multiply(multiply((x >= c(k)),a(k)),(1 - exp(- uk / tf(k)))),exp(- uk / ts(k)))
# /tmp/mfuncs/TF215_TrafficStopGo.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF215_TrafficStopGo.m:14
    meta.ID = copy('TF215')
# /tmp/mfuncs/TF215_TrafficStopGo.m:15
    meta.Name = copy('Traffic Stop-and-Go')
# /tmp/mfuncs/TF215_TrafficStopGo.m:16
    meta.Category = copy(11)
# /tmp/mfuncs/TF215_TrafficStopGo.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF215_TrafficStopGo.m:18
    meta.Parameters = copy(struct('base',base,'c',c,'a',a,'tf',tf,'ts',ts))
# /tmp/mfuncs/TF215_TrafficStopGo.m:19
    meta.Morphology = copy('Series of desaturation-like slow recoveries (stop-go)')
# /tmp/mfuncs/TF215_TrafficStopGo.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    