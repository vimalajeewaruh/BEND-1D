# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF042_LightningSferic(N=None,t0=None,s0=None,slow_amp=None,slow_tau1=None,slow_tau2=None,ring_decay=None,ring_f1=None,ring_f2=None,ring_a1=None,ring_a2=None,td=None,sd=None,prim_amp=None,delayed_amp=None,*args,**kwargs):
    varargin = TF042_LightningSferic.varargin
    nargin = TF042_LightningSferic.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF042_LightningSferic.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF042_LightningSferic.m:3
    if nargin < 2 or isempty(t0):
        t0=0.285
# /tmp/mfuncs/TF042_LightningSferic.m:4
    
    if nargin < 3 or isempty(s0):
        s0=0.0032
# /tmp/mfuncs/TF042_LightningSferic.m:5
    
    if nargin < 4 or isempty(slow_amp):
        slow_amp=0.36
# /tmp/mfuncs/TF042_LightningSferic.m:6
    
    if nargin < 5 or isempty(slow_tau1):
        slow_tau1=10
# /tmp/mfuncs/TF042_LightningSferic.m:7
    
    if nargin < 6 or isempty(slow_tau2):
        slow_tau2=65
# /tmp/mfuncs/TF042_LightningSferic.m:8
    
    if nargin < 7 or isempty(ring_decay):
        ring_decay=23
# /tmp/mfuncs/TF042_LightningSferic.m:9
    
    if nargin < 8 or isempty(ring_f1):
        ring_f1=72
# /tmp/mfuncs/TF042_LightningSferic.m:10
    
    if nargin < 9 or isempty(ring_f2):
        ring_f2=24
# /tmp/mfuncs/TF042_LightningSferic.m:11
    
    if nargin < 10 or isempty(ring_a1):
        ring_a1=0.34
# /tmp/mfuncs/TF042_LightningSferic.m:12
    
    if nargin < 11 or isempty(ring_a2):
        ring_a2=0.14
# /tmp/mfuncs/TF042_LightningSferic.m:13
    
    if nargin < 12 or isempty(td):
        td=0.475
# /tmp/mfuncs/TF042_LightningSferic.m:14
    
    if nargin < 13 or isempty(sd):
        sd=0.0045
# /tmp/mfuncs/TF042_LightningSferic.m:15
    
    if nargin < 14 or isempty(prim_amp):
        prim_amp=1.25
# /tmp/mfuncs/TF042_LightningSferic.m:16
    
    if nargin < 15 or isempty(delayed_amp):
        delayed_amp=0.2
# /tmp/mfuncs/TF042_LightningSferic.m:17
    
    u0=(x - t0) / s0
# /tmp/mfuncs/TF042_LightningSferic.m:19
    primarySferic=multiply(dot(prim_amp,u0),exp(dot(- 0.5,u0 ** 2)))
# /tmp/mfuncs/TF042_LightningSferic.m:20
    uL=x - t0
# /tmp/mfuncs/TF042_LightningSferic.m:22
    indL=uL >= 0
# /tmp/mfuncs/TF042_LightningSferic.m:23
    slowL=zeros(size(x))
# /tmp/mfuncs/TF042_LightningSferic.m:24
    ringL=zeros(size(x))
# /tmp/mfuncs/TF042_LightningSferic.m:25
    if any(indL):
        slowL[indL]=dot(slow_amp,(exp(dot(- slow_tau1,uL(indL))) - exp(dot(- slow_tau2,uL(indL)))))
# /tmp/mfuncs/TF042_LightningSferic.m:27
        ringL[indL]=multiply(exp(dot(- ring_decay,uL(indL))),(dot(ring_a1,sin(dot(dot(dot(2,pi),ring_f1),uL(indL)))) + dot(ring_a2,sin(dot(dot(dot(2,pi),ring_f2),uL(indL)) + 0.55))))
# /tmp/mfuncs/TF042_LightningSferic.m:28
    
    ud=(x - td) / sd
# /tmp/mfuncs/TF042_LightningSferic.m:31
    delayedL=multiply(dot(delayed_amp,ud),exp(dot(- 0.5,ud ** 2)))
# /tmp/mfuncs/TF042_LightningSferic.m:32
    f=primarySferic + slowL + ringL + delayedL
# /tmp/mfuncs/TF042_LightningSferic.m:34
    meta=copy(struct)
# /tmp/mfuncs/TF042_LightningSferic.m:36
    meta.ID = copy('TF042')
# /tmp/mfuncs/TF042_LightningSferic.m:37
    meta.Name = copy('Lightning Sferic')
# /tmp/mfuncs/TF042_LightningSferic.m:38
    meta.Category = copy(3)
# /tmp/mfuncs/TF042_LightningSferic.m:39
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF042_LightningSferic.m:40
    meta.Parameters = copy(struct('t0',t0,'s0',s0,'slow_amp',slow_amp,'slow_tau1',slow_tau1,'slow_tau2',slow_tau2,'ring_decay',ring_decay,'ring_f1',ring_f1,'ring_f2',ring_f2,'ring_a1',ring_a1,'ring_a2',ring_a2,'td',td,'sd',sd,'prim_amp',prim_amp,'delayed_amp',delayed_amp))
# /tmp/mfuncs/TF042_LightningSferic.m:41
    meta.Morphology = copy('Multiscale electromagnetic transient with bipolar front and ringing')
# /tmp/mfuncs/TF042_LightningSferic.m:47
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 4: 43 - 58