# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF207_StomatalClosure(N=None,cent1=None,wid1=None,amp1=None,cent2=None,wid2=None,amp2=None,*args,**kwargs):
    varargin = TF207_StomatalClosure.varargin
    nargin = TF207_StomatalClosure.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF207_StomatalClosure.m:2
    
    if nargin < 2 or isempty(cent1):
        cent1=0.39
# /tmp/mfuncs/TF207_StomatalClosure.m:3
    
    if nargin < 3 or isempty(wid1):
        wid1=0.02
# /tmp/mfuncs/TF207_StomatalClosure.m:4
    
    if nargin < 4 or isempty(amp1):
        amp1=0.62
# /tmp/mfuncs/TF207_StomatalClosure.m:5
    
    if nargin < 5 or isempty(cent2):
        cent2=0.79
# /tmp/mfuncs/TF207_StomatalClosure.m:6
    
    if nargin < 6 or isempty(wid2):
        wid2=0.055
# /tmp/mfuncs/TF207_StomatalClosure.m:7
    
    if nargin < 7 or isempty(amp2):
        amp2=0.3
# /tmp/mfuncs/TF207_StomatalClosure.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF207_StomatalClosure.m:9
    f=1 - dot(amp1,S(x,cent1,wid1)) + dot(amp2,S(x,cent2,wid2)) - dot(0.06,G(x,0.5,0.055))
# /tmp/mfuncs/TF207_StomatalClosure.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF207_StomatalClosure.m:11
    meta.ID = copy('TF207')
# /tmp/mfuncs/TF207_StomatalClosure.m:12
    meta.Name = copy('Stomatal Closure')
# /tmp/mfuncs/TF207_StomatalClosure.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF207_StomatalClosure.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF207_StomatalClosure.m:15
    meta.Parameters = copy(struct('cent1',cent1,'wid1',wid1,'amp1',amp1,'cent2',cent2,'wid2',wid2,'amp2',amp2))
# /tmp/mfuncs/TF207_StomatalClosure.m:16
    meta.Morphology = copy('Closure dynamics with secondary reopening and dip')
# /tmp/mfuncs/TF207_StomatalClosure.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    