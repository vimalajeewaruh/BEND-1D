# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF017_Klatno(N=None,x0K=None,aK=None,*args,**kwargs):
    varargin = TF017_Klatno.varargin
    nargin = TF017_Klatno.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF017_Klatno.m:2
    
    if nargin < 2 or isempty(x0K):
        x0K=0.48
# /tmp/mfuncs/TF017_Klatno.m:3
    
    if nargin < 3 or isempty(aK):
        aK=12
# /tmp/mfuncs/TF017_Klatno.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF017_Klatno.m:5
    base=dot(4,atan(exp(dot(aK,(x - x0K))))) - pi
# /tmp/mfuncs/TF017_Klatno.m:6
    u=max(x - x0K,0)
# /tmp/mfuncs/TF017_Klatno.m:7
    swing=multiply(dot(0.18,exp(dot(- 2.2,x))),sin(dot(dot(8,pi),x)))
# /tmp/mfuncs/TF017_Klatno.m:8
    post=multiply(multiply(dot(0.1,(x >= x0K)),exp(dot(- 8,u))),sin(dot(dot(36,pi),u)))
# /tmp/mfuncs/TF017_Klatno.m:9
    f=base + swing + post
# /tmp/mfuncs/TF017_Klatno.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF017_Klatno.m:11
    meta.ID = copy('TF017')
# /tmp/mfuncs/TF017_Klatno.m:12
    meta.Name = copy('Klatno')
# /tmp/mfuncs/TF017_Klatno.m:13
    meta.Category = copy(2)
# /tmp/mfuncs/TF017_Klatno.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF017_Klatno.m:15
    meta.Parameters = copy(struct('x0K',x0K,'aK',aK))
# /tmp/mfuncs/TF017_Klatno.m:16
    meta.Morphology = copy('Nonlinear pendulum separatrix with localized derivative')
# /tmp/mfuncs/TF017_Klatno.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    