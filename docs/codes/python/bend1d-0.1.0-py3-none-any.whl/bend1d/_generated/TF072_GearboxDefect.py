# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF072_GearboxDefect(N=None,car1_freq=None,car2_freq=None,car2_phase=None,mod_amp=None,mod_freq=None,mod_phase=None,impact_centers=None,impact_amp_lo=None,impact_amp_hi=None,impact_decay=None,impact_ring_freq=None,*args,**kwargs):
    varargin = TF072_GearboxDefect.varargin
    nargin = TF072_GearboxDefect.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF072_GearboxDefect.m:2
    
    if nargin < 2 or isempty(car1_freq):
        car1_freq=46
# /tmp/mfuncs/TF072_GearboxDefect.m:3
    
    if nargin < 3 or isempty(car2_freq):
        car2_freq=92
# /tmp/mfuncs/TF072_GearboxDefect.m:4
    
    if nargin < 4 or isempty(car2_phase):
        car2_phase=0.4
# /tmp/mfuncs/TF072_GearboxDefect.m:5
    
    if nargin < 5 or isempty(mod_amp):
        mod_amp=0.28
# /tmp/mfuncs/TF072_GearboxDefect.m:6
    
    if nargin < 6 or isempty(mod_freq):
        mod_freq=5
# /tmp/mfuncs/TF072_GearboxDefect.m:7
    
    if nargin < 7 or isempty(mod_phase):
        mod_phase=- 0.3
# /tmp/mfuncs/TF072_GearboxDefect.m:8
    
    if nargin < 8 or isempty(impact_centers):
        impact_centers=arange(0.12,0.96,0.105)
# /tmp/mfuncs/TF072_GearboxDefect.m:9
    
    if nargin < 9 or isempty(impact_amp_lo):
        impact_amp_lo=0.22
# /tmp/mfuncs/TF072_GearboxDefect.m:10
    
    if nargin < 10 or isempty(impact_amp_hi):
        impact_amp_hi=0.16
# /tmp/mfuncs/TF072_GearboxDefect.m:11
    
    if nargin < 11 or isempty(impact_decay):
        impact_decay=75
# /tmp/mfuncs/TF072_GearboxDefect.m:12
    
    if nargin < 12 or isempty(impact_ring_freq):
        impact_ring_freq=125
# /tmp/mfuncs/TF072_GearboxDefect.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF072_GearboxDefect.m:15
    carrierGB=dot(0.32,sin(dot(dot(dot(2,pi),car1_freq),x))) + dot(0.12,sin(dot(dot(dot(2,pi),car2_freq),x) + car2_phase))
# /tmp/mfuncs/TF072_GearboxDefect.m:16
    modGB=1 + dot(mod_amp,sin(dot(dot(dot(2,pi),mod_freq),x) + mod_phase))
# /tmp/mfuncs/TF072_GearboxDefect.m:17
    f=multiply(modGB,carrierGB)
# /tmp/mfuncs/TF072_GearboxDefect.m:18
    for k in arange(1,numel(impact_centers)).reshape(-1):
        c=impact_centers(k)
# /tmp/mfuncs/TF072_GearboxDefect.m:20
        amp=impact_amp_lo + dot(impact_amp_hi,(c > 0.5))
# /tmp/mfuncs/TF072_GearboxDefect.m:21
        u=max(x - c,0)
# /tmp/mfuncs/TF072_GearboxDefect.m:22
        f=f + multiply(multiply(dot(amp,(x >= c)),exp(dot(- impact_decay,u))),sin(dot(dot(dot(2,pi),impact_ring_freq),u)))
# /tmp/mfuncs/TF072_GearboxDefect.m:23
    
    meta=copy(struct)
# /tmp/mfuncs/TF072_GearboxDefect.m:25
    meta.ID = copy('TF072')
# /tmp/mfuncs/TF072_GearboxDefect.m:26
    meta.Name = copy('Gearbox Defect')
# /tmp/mfuncs/TF072_GearboxDefect.m:27
    meta.Category = copy(6)
# /tmp/mfuncs/TF072_GearboxDefect.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF072_GearboxDefect.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF072_GearboxDefect.m:30
    meta.Morphology = copy('Modulated carrier with repeated damped impacts')
# /tmp/mfuncs/TF072_GearboxDefect.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    