# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF113_SpaceWeatherStorm(N=None,base=None,oscAmp=None,oscFreq=None,step1C=None,step1W=None,step2C=None,step2W=None,riseC=None,riseRate=None,dipCs=None,*args,**kwargs):
    varargin = TF113_SpaceWeatherStorm.varargin
    nargin = TF113_SpaceWeatherStorm.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:2
    
    if nargin < 2 or isempty(base):
        base=0.1
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:3
    
    if nargin < 3 or isempty(oscAmp):
        oscAmp=0.025
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:4
    
    if nargin < 4 or isempty(oscFreq):
        oscFreq=3
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:5
    
    if nargin < 5 or isempty(step1C):
        step1C=0.3
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:6
    
    if nargin < 6 or isempty(step1W):
        step1W=0.006
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:7
    
    if nargin < 7 or isempty(step2C):
        step2C=0.38
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:8
    
    if nargin < 8 or isempty(step2W):
        step2W=0.018
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:9
    
    if nargin < 9 or isempty(riseC):
        riseC=0.47
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:10
    
    if nargin < 10 or isempty(riseRate):
        riseRate=3.5
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:11
    
    if nargin < 11 or isempty(dipCs):
        dipCs=concat([0.52,0.61,0.69])
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:14
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:15
    f=base + dot(oscAmp,sin(dot(dot(dot(2,pi),oscFreq),x)))
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:16
    f=f + dot(0.2,S(x,step1C,step1W)) - dot(0.75,S(x,step2C,step2W))
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:17
    u=max(x - riseC,0)
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:18
    f=f + multiply(multiply((x >= riseC),0.55),(1 - exp(dot(- riseRate,u))))
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:19
    for c in dipCs.reshape(-1):
        f=f - dot(0.1,exp(dot(- 0.5,((x - c) / 0.012) ** 2)))
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:21
    
    meta=copy(struct)
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:23
    meta.ID = copy('TF113')
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:24
    meta.Name = copy('Space Weather Storm')
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:25
    meta.Category = copy(6)
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:26
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:27
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:28
    meta.Morphology = copy('Step-like storm with localized dips')
# /tmp/mfuncs/TF113_SpaceWeatherStorm.m:29
    return x,f,meta
    
if __name__ == '__main__':
    pass
    