# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF183_PulsarGlitchRecovery(N=None,c=None,*args,**kwargs):
    varargin = TF183_PulsarGlitchRecovery.varargin
    nargin = TF183_PulsarGlitchRecovery.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:2
    
    if nargin < 2 or isempty(c):
        c=0.43
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:4
    u=max(x - c,0)
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:5
    h=double(x >= c)
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:6
    phase=dot(dot(2,pi),(dot(9,x) + multiply(h,(dot(2.4,u) + dot(0.22,(1 - exp(- u / 0.03))) + dot(0.16,(1 - exp(- u / 0.18)))))))
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:7
    f=sin(phase)
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:9
    meta.ID = copy('TF183')
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:10
    meta.Name = copy('Pulsar Glitch + Recovery')
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:11
    meta.Category = copy(10)
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:13
    meta.Parameters = copy(struct('c',c))
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:14
    meta.Morphology = copy('Phase jump at glitch with multi-timescale recovery')
# /tmp/mfuncs/TF183_PulsarGlitchRecovery.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    