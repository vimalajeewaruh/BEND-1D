# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF214_DrumModePacket(N=None,u0=None,gateCenter=None,gateWidth=None,*args,**kwargs):
    varargin = TF214_DrumModePacket.varargin
    nargin = TF214_DrumModePacket.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF214_DrumModePacket.m:2
    
    if nargin < 2 or isempty(u0):
        u0=0.06
# /tmp/mfuncs/TF214_DrumModePacket.m:3
    
    if nargin < 3 or isempty(gateCenter):
        gateCenter=0.06
# /tmp/mfuncs/TF214_DrumModePacket.m:4
    
    if nargin < 4 or isempty(gateWidth):
        gateWidth=0.002
# /tmp/mfuncs/TF214_DrumModePacket.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF214_DrumModePacket.m:6
    u=max(x - u0,0)
# /tmp/mfuncs/TF214_DrumModePacket.m:7
    gate=S(x,gateCenter,gateWidth)
# /tmp/mfuncs/TF214_DrumModePacket.m:8
    f=multiply(gate,(multiply(dot(0.58,exp(dot(- 4,u))),sin(dot(dot(dot(2,pi),8.5),u))) + multiply(dot(0.4,exp(dot(- 5.8,u))),sin(dot(dot(dot(2,pi),13.7),u) + 0.7)) + multiply(dot(0.27,exp(dot(- 7.5,u))),sin(dot(dot(dot(2,pi),22.4),u) + 0.3)) + multiply(dot(0.16,exp(dot(- 10,u))),sin(dot(dot(dot(2,pi),31.2),u) + 1.0))))
# /tmp/mfuncs/TF214_DrumModePacket.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF214_DrumModePacket.m:14
    meta.ID = copy('TF214')
# /tmp/mfuncs/TF214_DrumModePacket.m:15
    meta.Name = copy('Drum Mode Packet')
# /tmp/mfuncs/TF214_DrumModePacket.m:16
    meta.Category = copy(11)
# /tmp/mfuncs/TF214_DrumModePacket.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF214_DrumModePacket.m:18
    meta.Parameters = copy(struct('u0',u0,'gateCenter',gateCenter,'gateWidth',gateWidth))
# /tmp/mfuncs/TF214_DrumModePacket.m:19
    meta.Morphology = copy('Envelope-gated drum modal packet')
# /tmp/mfuncs/TF214_DrumModePacket.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    