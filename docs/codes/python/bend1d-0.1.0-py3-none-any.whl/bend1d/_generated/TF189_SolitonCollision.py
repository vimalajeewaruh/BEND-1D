# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF189_SolitonCollision(N=None,amp1=None,amp2=None,amp3=None,c1=None,c2=None,c3=None,w1=None,w2=None,w3=None,carrierFreq=None,*args,**kwargs):
    varargin = TF189_SolitonCollision.varargin
    nargin = TF189_SolitonCollision.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF189_SolitonCollision.m:2
    
    if nargin < 2 or isempty(amp1):
        amp1=0.66
# /tmp/mfuncs/TF189_SolitonCollision.m:3
    
    if nargin < 3 or isempty(amp2):
        amp2=0.66
# /tmp/mfuncs/TF189_SolitonCollision.m:4
    
    if nargin < 4 or isempty(amp3):
        amp3=0.82
# /tmp/mfuncs/TF189_SolitonCollision.m:5
    
    if nargin < 5 or isempty(c1):
        c1=0.4
# /tmp/mfuncs/TF189_SolitonCollision.m:6
    
    if nargin < 6 or isempty(c2):
        c2=0.6
# /tmp/mfuncs/TF189_SolitonCollision.m:7
    
    if nargin < 7 or isempty(c3):
        c3=0.5
# /tmp/mfuncs/TF189_SolitonCollision.m:8
    
    if nargin < 8 or isempty(w1):
        w1=0.045
# /tmp/mfuncs/TF189_SolitonCollision.m:9
    
    if nargin < 9 or isempty(w2):
        w2=0.045
# /tmp/mfuncs/TF189_SolitonCollision.m:10
    
    if nargin < 10 or isempty(w3):
        w3=0.03
# /tmp/mfuncs/TF189_SolitonCollision.m:11
    
    if nargin < 11 or isempty(carrierFreq):
        carrierFreq=29
# /tmp/mfuncs/TF189_SolitonCollision.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF189_SolitonCollision.m:13
    sech2=lambda z=None: 1.0 / cosh(z) ** 2
# /tmp/mfuncs/TF189_SolitonCollision.m:14
    f=dot(amp1,sech2((x - c1) / w1)) + dot(amp2,sech2((x - c2) / w2)) + multiply(dot(amp3,sech2((x - c3) / w3)),cos(dot(dot(dot(2,pi),carrierFreq),(x - c3))))
# /tmp/mfuncs/TF189_SolitonCollision.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF189_SolitonCollision.m:16
    meta.ID = copy('TF189')
# /tmp/mfuncs/TF189_SolitonCollision.m:17
    meta.Name = copy('Soliton Collision')
# /tmp/mfuncs/TF189_SolitonCollision.m:18
    meta.Category = copy(10)
# /tmp/mfuncs/TF189_SolitonCollision.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF189_SolitonCollision.m:20
    meta.Parameters = copy(struct('amps',concat([amp1,amp2,amp3]),'centers',concat([c1,c2,c3]),'widths',concat([w1,w2,w3]),'carrierFreq',carrierFreq))
# /tmp/mfuncs/TF189_SolitonCollision.m:21
    meta.Morphology = copy('Two solitons with central oscillatory interaction')
# /tmp/mfuncs/TF189_SolitonCollision.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    