# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF097_MilankovitchCycles(N=None,tKyrScale=None,eccAmp=None,eccFreq=None,oblAmp=None,oblFreq=None,precBaseAmp=None,precModAmp=None,terminationC1=None,terminationW1=None,terminationC2=None,terminationW2=None,*args,**kwargs):
    varargin = TF097_MilankovitchCycles.varargin
    nargin = TF097_MilankovitchCycles.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF097_MilankovitchCycles.m:2
    
    if nargin < 2 or isempty(tKyrScale):
        tKyrScale=500
# /tmp/mfuncs/TF097_MilankovitchCycles.m:3
    
    if nargin < 3 or isempty(eccAmp):
        eccAmp=0.25
# /tmp/mfuncs/TF097_MilankovitchCycles.m:4
    
    if nargin < 4 or isempty(eccFreq):
        eccFreq=100
# /tmp/mfuncs/TF097_MilankovitchCycles.m:5
    
    if nargin < 5 or isempty(oblAmp):
        oblAmp=0.16
# /tmp/mfuncs/TF097_MilankovitchCycles.m:6
    
    if nargin < 6 or isempty(oblFreq):
        oblFreq=41
# /tmp/mfuncs/TF097_MilankovitchCycles.m:7
    
    if nargin < 7 or isempty(precBaseAmp):
        precBaseAmp=0.1
# /tmp/mfuncs/TF097_MilankovitchCycles.m:8
    
    if nargin < 8 or isempty(precModAmp):
        precModAmp=0.55
# /tmp/mfuncs/TF097_MilankovitchCycles.m:9
    
    if nargin < 9 or isempty(terminationC1):
        terminationC1=0.62
# /tmp/mfuncs/TF097_MilankovitchCycles.m:10
    
    if nargin < 10 or isempty(terminationW1):
        terminationW1=0.008
# /tmp/mfuncs/TF097_MilankovitchCycles.m:11
    
    if nargin < 11 or isempty(terminationC2):
        terminationC2=0.71
# /tmp/mfuncs/TF097_MilankovitchCycles.m:12
    
    if nargin < 12 or isempty(terminationW2):
        terminationW2=0.025
# /tmp/mfuncs/TF097_MilankovitchCycles.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF097_MilankovitchCycles.m:15
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF097_MilankovitchCycles.m:16
    tKyr=dot(tKyrScale,x)
# /tmp/mfuncs/TF097_MilankovitchCycles.m:17
    ecc=dot(eccAmp,sin(dot(dot(2,pi),tKyr) / eccFreq + 0.2))
# /tmp/mfuncs/TF097_MilankovitchCycles.m:18
    obl=dot(oblAmp,sin(dot(dot(2,pi),tKyr) / oblFreq - 0.6))
# /tmp/mfuncs/TF097_MilankovitchCycles.m:19
    precAmp=dot(precBaseAmp,(1 + dot(precModAmp,sin(dot(dot(2,pi),tKyr) / 100 + 0.7))))
# /tmp/mfuncs/TF097_MilankovitchCycles.m:20
    prec=multiply(precAmp,sin(dot(dot(2,pi),tKyr) / 23 + 0.4))
# /tmp/mfuncs/TF097_MilankovitchCycles.m:21
    termination=dot(0.18,(sigmoid(x,terminationC1,terminationW1) - sigmoid(x,terminationC2,terminationW2)))
# /tmp/mfuncs/TF097_MilankovitchCycles.m:22
    f=ecc + obl + prec + termination
# /tmp/mfuncs/TF097_MilankovitchCycles.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF097_MilankovitchCycles.m:24
    meta.ID = copy('TF097')
# /tmp/mfuncs/TF097_MilankovitchCycles.m:25
    meta.Name = copy('Milankovitch Cycles')
# /tmp/mfuncs/TF097_MilankovitchCycles.m:26
    meta.Category = copy(6)
# /tmp/mfuncs/TF097_MilankovitchCycles.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF097_MilankovitchCycles.m:28
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF097_MilankovitchCycles.m:29
    meta.Morphology = copy('Climate cycles from orbital parameters with termination')
# /tmp/mfuncs/TF097_MilankovitchCycles.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    