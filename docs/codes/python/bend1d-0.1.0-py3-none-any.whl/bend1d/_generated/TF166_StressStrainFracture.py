# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF166_StressStrainFracture(N=None,*args,**kwargs):
    varargin = TF166_StressStrainFracture.varargin
    nargin = TF166_StressStrainFracture.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF166_StressStrainFracture.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF166_StressStrainFracture.m:3
    f=zeros(size(x))
# /tmp/mfuncs/TF166_StressStrainFracture.m:4
    m1=x < 0.18
# /tmp/mfuncs/TF166_StressStrainFracture.m:5
    m2=logical_and((x >= 0.18),(x < 0.34))
# /tmp/mfuncs/TF166_StressStrainFracture.m:6
    m3=logical_and((x >= 0.34),(x < 0.72))
# /tmp/mfuncs/TF166_StressStrainFracture.m:7
    m4=logical_and((x >= 0.72),(x < 0.9))
# /tmp/mfuncs/TF166_StressStrainFracture.m:8
    m5=x >= 0.9
# /tmp/mfuncs/TF166_StressStrainFracture.m:9
    f[m1]=dot(4,x(m1))
# /tmp/mfuncs/TF166_StressStrainFracture.m:10
    f[m2]=0.72 + dot(0.035,(x(m2) - 0.18)) / (0.34 - 0.18)
# /tmp/mfuncs/TF166_StressStrainFracture.m:11
    u=(x(m3) - 0.34) / (0.72 - 0.34)
# /tmp/mfuncs/TF166_StressStrainFracture.m:12
    f[m3]=0.755 + dot(0.3,u) + dot(0.055,u ** 2)
# /tmp/mfuncs/TF166_StressStrainFracture.m:13
    u=(x(m4) - 0.72) / (0.9 - 0.72)
# /tmp/mfuncs/TF166_StressStrainFracture.m:14
    f[m4]=1.11 - dot(0.22,u) - dot(0.03,u ** 2)
# /tmp/mfuncs/TF166_StressStrainFracture.m:15
    f[m5]=0.15 + dot(0.04,exp(dot(- 18,(x(m5) - 0.9))))
# /tmp/mfuncs/TF166_StressStrainFracture.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF166_StressStrainFracture.m:17
    meta.ID = copy('TF166')
# /tmp/mfuncs/TF166_StressStrainFracture.m:18
    meta.Name = copy('Stress-Strain Fracture')
# /tmp/mfuncs/TF166_StressStrainFracture.m:19
    meta.Category = copy(9)
# /tmp/mfuncs/TF166_StressStrainFracture.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF166_StressStrainFracture.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF166_StressStrainFracture.m:22
    meta.Morphology = copy('Piecewise polynomial stress-strain response with post-fracture decay')
# /tmp/mfuncs/TF166_StressStrainFracture.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    