# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF034_EMGRecruitment(N=None,envEMG=None,oscEMG=None,*args,**kwargs):
    varargin = TF034_EMGRecruitment.varargin
    nargin = TF034_EMGRecruitment.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF034_EMGRecruitment.m:2
    
    if nargin < 2 or isempty(envEMG):
        envEMG=[]
# /tmp/mfuncs/TF034_EMGRecruitment.m:3
    
    if nargin < 3 or isempty(oscEMG):
        oscEMG=[]
# /tmp/mfuncs/TF034_EMGRecruitment.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF034_EMGRecruitment.m:5
    if isempty(envEMG):
        envEMG=0.08 + 0.92 / (1 + exp(dot(- 35,(x - 0.32))))
# /tmp/mfuncs/TF034_EMGRecruitment.m:7
    else:
        if isscalar(envEMG):
            envEMG=repmat(envEMG,size(x))
# /tmp/mfuncs/TF034_EMGRecruitment.m:9
        else:
            envEMG=interp1(linspace(0,1,numel(envEMG)),envEMG,x,'linear',envEMG(end()))
# /tmp/mfuncs/TF034_EMGRecruitment.m:11
    
    if isempty(oscEMG):
        oscEMG=dot(0.62,sin(dot(dot(2,pi),(dot(24,x) + dot(17,x ** 2))))) + dot(0.38,sin(dot(dot(2,pi),(dot(49,x) + dot(0.8,sin(dot(dot(dot(2,pi),1.3),x))))))) + dot(0.23,sin(dot(dot(dot(2,pi),83),x) + 0.35)) + dot(0.12,sin(dot(dot(dot(2,pi),121),x) - 0.8))
# /tmp/mfuncs/TF034_EMGRecruitment.m:14
    else:
        if isscalar(oscEMG):
            oscEMG=repmat(oscEMG,size(x))
# /tmp/mfuncs/TF034_EMGRecruitment.m:16
        else:
            oscEMG=interp1(linspace(0,1,numel(oscEMG)),oscEMG,x,'linear',oscEMG(end()))
# /tmp/mfuncs/TF034_EMGRecruitment.m:18
    
    f=multiply(envEMG,oscEMG)
# /tmp/mfuncs/TF034_EMGRecruitment.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF034_EMGRecruitment.m:21
    meta.ID = copy('TF034')
# /tmp/mfuncs/TF034_EMGRecruitment.m:22
    meta.Name = copy('EMG Recruitment')
# /tmp/mfuncs/TF034_EMGRecruitment.m:23
    meta.Category = copy(3)
# /tmp/mfuncs/TF034_EMGRecruitment.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF034_EMGRecruitment.m:25
    meta.Parameters = copy(struct('envEMG',envEMG,'oscEMG',oscEMG))
# /tmp/mfuncs/TF034_EMGRecruitment.m:26
    meta.Morphology = copy('Progressive recruitment with increasingly dense oscillatory content after onset')
# /tmp/mfuncs/TF034_EMGRecruitment.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    