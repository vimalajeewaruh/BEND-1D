# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF054_FractureAcousticEmission(N=None,eventT=None,eventA=None,ring_base_decay=None,pulse_width=None,ring_freq_base=None,ring_freq_step=None,*args,**kwargs):
    varargin = TF054_FractureAcousticEmission.varargin
    nargin = TF054_FractureAcousticEmission.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:2
    
    if nargin < 2 or isempty(eventT):
        eventT=concat([0.16,0.31,0.47,0.6,0.7,0.775,0.835,0.885,0.925,0.955]).T
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:3
    
    if nargin < 3 or isempty(eventA):
        eventA=concat([0.22,0.28,0.25,0.35,0.42,0.55,0.68,0.82,1.0,1.18]).T
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:4
    
    if nargin < 4 or isempty(ring_base_decay):
        ring_base_decay=30
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:5
    
    if nargin < 5 or isempty(pulse_width):
        pulse_width=0.0025
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:6
    
    if nargin < 6 or isempty(ring_freq_base):
        ring_freq_base=45
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:7
    
    if nargin < 7 or isempty(ring_freq_step):
        ring_freq_step=4
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:10
    f=zeros(size(x))
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:11
    for k in arange(1,numel(eventT)).reshape(-1):
        u=x - eventT(k)
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:13
        ind=u >= 0
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:14
        ring=zeros(size(x))
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:15
        ring[ind]=multiply(dot(eventA(k),exp(multiply(- (ring_base_decay + dot(2,k)),u(ind)))),sin(multiply(dot(dot(2,pi),(ring_freq_base + dot(ring_freq_step,k))),u(ind))))
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:16
        pulse=dot(dot(0.45,eventA(k)),exp(dot(- 0.5,(u / pulse_width) ** 2)))
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:17
        f=f + pulse + ring
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:18
    
    meta=copy(struct)
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:20
    meta.ID = copy('TF054')
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:21
    meta.Name = copy('Fracture Acoustic Emission')
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:22
    meta.Category = copy(4)
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:25
    meta.Morphology = copy('Sparse AE bursts becoming denser/larger near failure')
# /tmp/mfuncs/TF054_FractureAcousticEmission.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    