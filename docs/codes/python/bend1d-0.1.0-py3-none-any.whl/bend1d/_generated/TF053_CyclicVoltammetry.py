# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF053_CyclicVoltammetry(N=None,E_start=None,E_end=None,split_frac=None,scale_a=None,peak1_a=None,peak1_ctr=None,peak1_w=None,peak2_a=None,peak2_ctr=None,peak2_w=None,*args,**kwargs):
    varargin = TF053_CyclicVoltammetry.varargin
    nargin = TF053_CyclicVoltammetry.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:2
    
    if nargin < 2 or isempty(E_start):
        E_start=- 1
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:3
    
    if nargin < 3 or isempty(E_end):
        E_end=3
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:4
    
    if nargin < 4 or isempty(split_frac):
        split_frac=0.5
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:5
    
    if nargin < 5 or isempty(scale_a):
        scale_a=0.07
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:6
    
    if nargin < 6 or isempty(peak1_a):
        peak1_a=1.0
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:7
    
    if nargin < 7 or isempty(peak1_ctr):
        peak1_ctr=0.36
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:8
    
    if nargin < 8 or isempty(peak1_w):
        peak1_w=0.18
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:9
    
    if nargin < 9 or isempty(peak2_a):
        peak2_a=- 0.82
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:10
    
    if nargin < 10 or isempty(peak2_ctr):
        peak2_ctr=0.08
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:11
    
    if nargin < 11 or isempty(peak2_w):
        peak2_w=0.22
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:14
    Ecv=zeros(size(x))
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:15
    forward=x <= split_frac
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:16
    reverse=logical_not(forward)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:17
    Ecv[forward]=E_start + dot((E_end - E_start),(x(forward) / split_frac))
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:18
    Ecv[reverse]=E_end - dot((E_end - E_start),((x(reverse) - split_frac) / (1 - split_frac)))
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:19
    iCV=dot(scale_a,Ecv)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:20
    iCV[forward]=iCV(forward) + dot(peak1_a,exp(dot(- 0.5,((Ecv(forward) - peak1_ctr) / peak1_w) ** 2)))
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:21
    iCV[reverse]=iCV(reverse) + dot(peak2_a,exp(dot(- 0.5,((Ecv(reverse) - peak2_ctr) / peak2_w) ** 2)))
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:22
    f=copy(iCV)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:24
    meta.ID = copy('TF053')
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:25
    meta.Name = copy('Cyclic Voltammetry')
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:26
    meta.Category = copy(4)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:28
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:29
    meta.Morphology = copy('Forward and reverse potential sweep with redox peaks')
# /tmp/mfuncs/TF053_CyclicVoltammetry.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    