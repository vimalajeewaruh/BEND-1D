# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF103_FusionELMSawtooth(N=None,base=None,linSlope=None,period=None,phaseAmp=None,spikeCs=None,spikeAmp=None,spikeW=None,*args,**kwargs):
    varargin = TF103_FusionELMSawtooth.varargin
    nargin = TF103_FusionELMSawtooth.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:2
    
    if nargin < 2 or isempty(base):
        base=0.3
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:3
    
    if nargin < 3 or isempty(linSlope):
        linSlope=0.2
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:4
    
    if nargin < 4 or isempty(period):
        period=0.105
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:5
    
    if nargin < 5 or isempty(phaseAmp):
        phaseAmp=0.18
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:6
    
    if nargin < 6 or isempty(spikeCs):
        spikeCs=arange(0.18,0.9,0.12)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:7
    
    if nargin < 7 or isempty(spikeAmp):
        spikeAmp=0.28
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:8
    
    if nargin < 8 or isempty(spikeW):
        spikeW=0.005
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:11
    f=base + dot(linSlope,x)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:12
    phase=mod(x,period) / period
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:13
    f=f + dot(phaseAmp,phase)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:14
    for c in spikeCs.reshape(-1):
        f=f + dot(spikeAmp,exp(dot(- 0.5,((x - c) / spikeW) ** 2)))
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:16
    
    meta=copy(struct)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:18
    meta.ID = copy('TF103')
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:19
    meta.Name = copy('Fusion ELM Sawtooth')
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:23
    meta.Morphology = copy('Linear ramp with sawtooth phase and narrow spikes')
# /tmp/mfuncs/TF103_FusionELMSawtooth.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    