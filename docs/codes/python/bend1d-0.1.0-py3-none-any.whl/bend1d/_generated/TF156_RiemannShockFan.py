# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF156_RiemannShockFan(N=None,xBreak1=None,xBreak2=None,xBreak3=None,xBreak4=None,v1=None,v2=None,v3=None,v4=None,v5=None,*args,**kwargs):
    varargin = TF156_RiemannShockFan.varargin
    nargin = TF156_RiemannShockFan.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF156_RiemannShockFan.m:2
    
    if nargin < 2 or isempty(xBreak1):
        xBreak1=0.18
# /tmp/mfuncs/TF156_RiemannShockFan.m:3
    
    if nargin < 3 or isempty(xBreak2):
        xBreak2=0.4
# /tmp/mfuncs/TF156_RiemannShockFan.m:4
    
    if nargin < 4 or isempty(xBreak3):
        xBreak3=0.58
# /tmp/mfuncs/TF156_RiemannShockFan.m:5
    
    if nargin < 5 or isempty(xBreak4):
        xBreak4=0.76
# /tmp/mfuncs/TF156_RiemannShockFan.m:6
    
    if nargin < 6 or isempty(v1):
        v1=1.0
# /tmp/mfuncs/TF156_RiemannShockFan.m:7
    
    if nargin < 7 or isempty(v2):
        v2=1.0
# /tmp/mfuncs/TF156_RiemannShockFan.m:8
    
    if nargin < 8 or isempty(v3):
        v3=0.62
# /tmp/mfuncs/TF156_RiemannShockFan.m:9
    
    if nargin < 9 or isempty(v4):
        v4=0.4
# /tmp/mfuncs/TF156_RiemannShockFan.m:10
    
    if nargin < 10 or isempty(v5):
        v5=0.08
# /tmp/mfuncs/TF156_RiemannShockFan.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF156_RiemannShockFan.m:12
    f=zeros(size(x))
# /tmp/mfuncs/TF156_RiemannShockFan.m:13
    m1=x < xBreak1
# /tmp/mfuncs/TF156_RiemannShockFan.m:14
    m2=logical_and((x >= xBreak1),(x < xBreak2))
# /tmp/mfuncs/TF156_RiemannShockFan.m:15
    m3=logical_and((x >= xBreak2),(x < xBreak3))
# /tmp/mfuncs/TF156_RiemannShockFan.m:16
    m4=logical_and((x >= xBreak3),(x < xBreak4))
# /tmp/mfuncs/TF156_RiemannShockFan.m:17
    m5=x >= xBreak4
# /tmp/mfuncs/TF156_RiemannShockFan.m:18
    f[m1]=v1
# /tmp/mfuncs/TF156_RiemannShockFan.m:19
    
    f[m2]=v2 - dot((v2 - v3),(x(m2) - xBreak1)) / (xBreak2 - xBreak1)
# /tmp/mfuncs/TF156_RiemannShockFan.m:21
    f[m3]=v3
# /tmp/mfuncs/TF156_RiemannShockFan.m:22
    f[m4]=v4
# /tmp/mfuncs/TF156_RiemannShockFan.m:23
    f[m5]=v5
# /tmp/mfuncs/TF156_RiemannShockFan.m:24
    meta=copy(struct)
# /tmp/mfuncs/TF156_RiemannShockFan.m:25
    meta.ID = copy('TF156')
# /tmp/mfuncs/TF156_RiemannShockFan.m:26
    meta.Name = copy('Riemann Shock Fan')
# /tmp/mfuncs/TF156_RiemannShockFan.m:27
    meta.Category = copy(9)
# /tmp/mfuncs/TF156_RiemannShockFan.m:28
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF156_RiemannShockFan.m:29
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF156_RiemannShockFan.m:30
    meta.Morphology = copy('Piecewise constant with a linear ramp (shock and fan)')
# /tmp/mfuncs/TF156_RiemannShockFan.m:31
    return x,f,meta
    
if __name__ == '__main__':
    pass
    