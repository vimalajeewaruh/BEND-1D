# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF142_MishMashBeta(N=None,sin1Amp=None,cos1Amp=None,sqrtAmp=None,sqrtOffset=None,sinFreqOffset=None,stepCtr1=None,stepW1=None,negSpikeCtr=None,negSpikeW=None,tailCtr=None,tailW=None,*args,**kwargs):
    varargin = TF142_MishMashBeta.varargin
    nargin = TF142_MishMashBeta.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF142_MishMashBeta.m:2
    
    if nargin < 2 or isempty(sin1Amp):
        sin1Amp=0.22
# /tmp/mfuncs/TF142_MishMashBeta.m:3
    
    if nargin < 3 or isempty(cos1Amp):
        cos1Amp=0.1
# /tmp/mfuncs/TF142_MishMashBeta.m:4
    
    if nargin < 4 or isempty(sqrtAmp):
        sqrtAmp=0.14
# /tmp/mfuncs/TF142_MishMashBeta.m:5
    
    if nargin < 5 or isempty(sqrtOffset):
        sqrtOffset=0.02
# /tmp/mfuncs/TF142_MishMashBeta.m:6
    
    if nargin < 6 or isempty(sinFreqOffset):
        sinFreqOffset=1.15
# /tmp/mfuncs/TF142_MishMashBeta.m:7
    
    if nargin < 7 or isempty(stepCtr1):
        stepCtr1=0.38
# /tmp/mfuncs/TF142_MishMashBeta.m:8
    
    if nargin < 8 or isempty(stepW1):
        stepW1=0.008
# /tmp/mfuncs/TF142_MishMashBeta.m:9
    
    if nargin < 9 or isempty(negSpikeCtr):
        negSpikeCtr=0.73
# /tmp/mfuncs/TF142_MishMashBeta.m:10
    
    if nargin < 10 or isempty(negSpikeW):
        negSpikeW=0.005
# /tmp/mfuncs/TF142_MishMashBeta.m:11
    
    if nargin < 11 or isempty(tailCtr):
        tailCtr=0.82
# /tmp/mfuncs/TF142_MishMashBeta.m:12
    
    if nargin < 12 or isempty(tailW):
        tailW=0.025
# /tmp/mfuncs/TF142_MishMashBeta.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF142_MishMashBeta.m:15
    u=max(x,sqrtOffset)
# /tmp/mfuncs/TF142_MishMashBeta.m:16
    f=dot(sin1Amp,sin(dot(dot(dot(2,pi),3),x))) + dot(cos1Amp,cos(dot(dot(dot(2,pi),5),x))) + multiply(dot(sqrtAmp,sqrt(multiply(u,(1 - u)))),sin(dot(dot(2,pi),sinFreqOffset) / (u + 0.05))) + dot(0.2,(S(x,stepCtr1,stepW1) - S(x,0.6,0.008))) - dot(0.3,exp(dot(- 0.5,((x - negSpikeCtr) / negSpikeW) ** 2))) + dot(0.09,exp(dot(- 0.5,((x - tailCtr) / tailW) ** 2)))
# /tmp/mfuncs/TF142_MishMashBeta.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF142_MishMashBeta.m:18
    meta.ID = copy('TF142')
# /tmp/mfuncs/TF142_MishMashBeta.m:19
    meta.Name = copy('MishMash Beta')
# /tmp/mfuncs/TF142_MishMashBeta.m:20
    meta.Category = copy(9)
# /tmp/mfuncs/TF142_MishMashBeta.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF142_MishMashBeta.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF142_MishMashBeta.m:23
    meta.Morphology = copy('Dense mixture of oscillations, nonlinear amplitude modulation and localized features')
# /tmp/mfuncs/TF142_MishMashBeta.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    