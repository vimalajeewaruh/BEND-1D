# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF196_CavitationCollapse(N=None,c=None,a=None,w=None,fr=None,*args,**kwargs):
    varargin = TF196_CavitationCollapse.varargin
    nargin = TF196_CavitationCollapse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF196_CavitationCollapse.m:2
    
    if nargin < 2 or isempty(c):
        c=concat([0.18,0.225,0.46,0.69,0.735,0.84])
# /tmp/mfuncs/TF196_CavitationCollapse.m:3
    
    if nargin < 3 or isempty(a):
        a=concat([0.7,0.42,0.95,0.52,0.76,0.38])
# /tmp/mfuncs/TF196_CavitationCollapse.m:4
    
    if nargin < 4 or isempty(w):
        w=concat([0.003,0.0025,0.0035,0.0025,0.003,0.002])
# /tmp/mfuncs/TF196_CavitationCollapse.m:5
    
    if nargin < 5 or isempty(fr):
        fr=concat([70,86,62,92,78,105])
# /tmp/mfuncs/TF196_CavitationCollapse.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF196_CavitationCollapse.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF196_CavitationCollapse.m:8
    for k in arange(1,numel(c)).reshape(-1):
        f=f + dot(a(k),G(x,c(k),w(k)))
# /tmp/mfuncs/TF196_CavitationCollapse.m:10
        u=max(x - c(k),0)
# /tmp/mfuncs/TF196_CavitationCollapse.m:11
        f=f + multiply(multiply(multiply((x >= c(k)),(dot(0.18,a(k)))),exp(dot(- 35,u))),sin(dot(dot(dot(2,pi),fr(k)),u)))
# /tmp/mfuncs/TF196_CavitationCollapse.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF196_CavitationCollapse.m:14
    meta.ID = copy('TF196')
# /tmp/mfuncs/TF196_CavitationCollapse.m:15
    meta.Name = copy('Cavitation Collapse')
# /tmp/mfuncs/TF196_CavitationCollapse.m:16
    meta.Category = copy(10)
# /tmp/mfuncs/TF196_CavitationCollapse.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF196_CavitationCollapse.m:18
    meta.Parameters = copy(struct('centers',c,'amps',a,'widths',w,'ringFreqs',fr))
# /tmp/mfuncs/TF196_CavitationCollapse.m:19
    meta.Morphology = copy('Burst-like collapses with damped ringing')
# /tmp/mfuncs/TF196_CavitationCollapse.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    