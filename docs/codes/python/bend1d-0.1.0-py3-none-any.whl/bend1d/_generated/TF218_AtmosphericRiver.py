# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF218_AtmosphericRiver(N=None,u0=None,mainScale=None,*args,**kwargs):
    varargin = TF218_AtmosphericRiver.varargin
    nargin = TF218_AtmosphericRiver.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF218_AtmosphericRiver.m:2
    
    if nargin < 2 or isempty(u0):
        u0=0.12
# /tmp/mfuncs/TF218_AtmosphericRiver.m:3
    
    if nargin < 3 or isempty(mainScale):
        mainScale=0.82
# /tmp/mfuncs/TF218_AtmosphericRiver.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF218_AtmosphericRiver.m:5
    u=max(x - u0,0)
# /tmp/mfuncs/TF218_AtmosphericRiver.m:6
    main=dot(multiply((x >= u0),(u / 0.16) ** 2.0),exp(2 - u / 0.16))
# /tmp/mfuncs/TF218_AtmosphericRiver.m:7
    main=main / max(main)
# /tmp/mfuncs/TF218_AtmosphericRiver.m:8
    f=0.12 + dot(mainScale,main) + dot(0.16,G(x,0.43,0.025)) + dot(0.12,G(x,0.58,0.032)) - dot(0.07,G(x,0.71,0.018))
# /tmp/mfuncs/TF218_AtmosphericRiver.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF218_AtmosphericRiver.m:10
    meta.ID = copy('TF218')
# /tmp/mfuncs/TF218_AtmosphericRiver.m:11
    meta.Name = copy('Atmospheric River')
# /tmp/mfuncs/TF218_AtmosphericRiver.m:12
    meta.Category = copy(11)
# /tmp/mfuncs/TF218_AtmosphericRiver.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF218_AtmosphericRiver.m:14
    meta.Parameters = copy(struct('u0',u0,'mainScale',mainScale))
# /tmp/mfuncs/TF218_AtmosphericRiver.m:15
    meta.Morphology = copy('Normalized main pulse with subsidiary bumps and dips')
# /tmp/mfuncs/TF218_AtmosphericRiver.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    