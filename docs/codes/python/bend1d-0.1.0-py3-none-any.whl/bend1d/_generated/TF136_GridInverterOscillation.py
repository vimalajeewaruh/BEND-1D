# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF136_GridInverterOscillation(N=None,baseline=None,trendAmp=None,onset=None,onsetW=None,onsetAmp=None,onsetDecay=None,onsetFreq=None,negStepCtr=None,negStepW=None,*args,**kwargs):
    varargin = TF136_GridInverterOscillation.varargin
    nargin = TF136_GridInverterOscillation.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF136_GridInverterOscillation.m:2
    
    if nargin < 2 or isempty(baseline):
        baseline=0.3
# /tmp/mfuncs/TF136_GridInverterOscillation.m:3
    
    if nargin < 3 or isempty(trendAmp):
        trendAmp=0.02
# /tmp/mfuncs/TF136_GridInverterOscillation.m:4
    
    if nargin < 4 or isempty(onset):
        onset=0.3
# /tmp/mfuncs/TF136_GridInverterOscillation.m:5
    
    if nargin < 5 or isempty(onsetW):
        onsetW=0.006
# /tmp/mfuncs/TF136_GridInverterOscillation.m:6
    
    if nargin < 6 or isempty(onsetAmp):
        onsetAmp=0.34
# /tmp/mfuncs/TF136_GridInverterOscillation.m:7
    
    if nargin < 7 or isempty(onsetDecay):
        onsetDecay=5
# /tmp/mfuncs/TF136_GridInverterOscillation.m:8
    
    if nargin < 8 or isempty(onsetFreq):
        onsetFreq=10
# /tmp/mfuncs/TF136_GridInverterOscillation.m:9
    
    if nargin < 9 or isempty(negStepCtr):
        negStepCtr=0.64
# /tmp/mfuncs/TF136_GridInverterOscillation.m:10
    
    if nargin < 10 or isempty(negStepW):
        negStepW=0.01
# /tmp/mfuncs/TF136_GridInverterOscillation.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF136_GridInverterOscillation.m:13
    uGI=max(x - onset,0)
# /tmp/mfuncs/TF136_GridInverterOscillation.m:14
    f=baseline + dot(trendAmp,x) + dot(0.16,S(x,onset,onsetW)) + multiply(multiply(multiply((x >= onset),onsetAmp),exp(dot(- onsetDecay,uGI))),sin(dot(dot(2,pi),(dot(onsetFreq,uGI) + dot(4,uGI ** 2))))) - dot(0.1,S(x,negStepCtr,negStepW))
# /tmp/mfuncs/TF136_GridInverterOscillation.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF136_GridInverterOscillation.m:16
    meta.ID = copy('TF136')
# /tmp/mfuncs/TF136_GridInverterOscillation.m:17
    meta.Name = copy('Grid Inverter Oscillation')
# /tmp/mfuncs/TF136_GridInverterOscillation.m:18
    meta.Category = copy(9)
# /tmp/mfuncs/TF136_GridInverterOscillation.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF136_GridInverterOscillation.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF136_GridInverterOscillation.m:21
    meta.Morphology = copy('Onset-triggered decaying nonlinear chirp with baseline step features')
# /tmp/mfuncs/TF136_GridInverterOscillation.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    