# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF195_MeltPoolSpatter(N=None,base=None,c=None,a=None,w=None,*args,**kwargs):
    varargin = TF195_MeltPoolSpatter.varargin
    nargin = TF195_MeltPoolSpatter.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:2
    
    if nargin < 2 or isempty(base):
        base=0.12
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:3
    
    if nargin < 3 or isempty(c):
        c=concat([0.21,0.37,0.49,0.58,0.74,0.79])
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:4
    
    if nargin < 4 or isempty(a):
        a=concat([0.18,0.28,0.2,0.34,0.23,- 0.15])
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:5
    
    if nargin < 5 or isempty(w):
        w=concat([0.004,0.003,0.0025,0.0035,0.0028,0.004])
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:7
    f=base + dot(0.72,G(x,0.55,0.22))
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:8
    for k in arange(1,numel(c)).reshape(-1):
        f=f + dot(a(k),G(x,c(k),w(k)))
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:10
    
    f=f + multiply(dot(0.05,sin(dot(dot(dot(2,pi),18),x))),G(x,0.58,0.2))
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:12
    meta=copy(struct)
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:13
    meta.ID = copy('TF195')
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:14
    meta.Name = copy('Melt-pool Spatter')
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:15
    meta.Category = copy(10)
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:17
    meta.Parameters = copy(struct('base',base,'centers',c,'amps',a,'widths',w))
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:18
    meta.Morphology = copy('Localized spatter peaks with high-frequency modulation')
# /tmp/mfuncs/TF195_MeltPoolSpatter.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    