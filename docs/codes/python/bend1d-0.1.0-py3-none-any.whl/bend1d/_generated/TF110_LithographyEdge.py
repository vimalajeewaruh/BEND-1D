# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF110_LithographyEdge(N=None,base=None,amp1=None,freq1=None,amp2=None,freq2=None,pos1=None,w1=None,pos2=None,w2=None,*args,**kwargs):
    varargin = TF110_LithographyEdge.varargin
    nargin = TF110_LithographyEdge.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF110_LithographyEdge.m:2
    
    if nargin < 2 or isempty(base):
        base=0.5
# /tmp/mfuncs/TF110_LithographyEdge.m:3
    
    if nargin < 3 or isempty(amp1):
        amp1=0.025
# /tmp/mfuncs/TF110_LithographyEdge.m:4
    
    if nargin < 4 or isempty(freq1):
        freq1=7
# /tmp/mfuncs/TF110_LithographyEdge.m:5
    
    if nargin < 5 or isempty(amp2):
        amp2=0.012
# /tmp/mfuncs/TF110_LithographyEdge.m:6
    
    if nargin < 6 or isempty(freq2):
        freq2=43
# /tmp/mfuncs/TF110_LithographyEdge.m:7
    
    if nargin < 7 or isempty(pos1):
        pos1=0.39
# /tmp/mfuncs/TF110_LithographyEdge.m:8
    
    if nargin < 8 or isempty(w1):
        w1=0.01
# /tmp/mfuncs/TF110_LithographyEdge.m:9
    
    if nargin < 9 or isempty(pos2):
        pos2=0.69
# /tmp/mfuncs/TF110_LithographyEdge.m:10
    
    if nargin < 10 or isempty(w2):
        w2=0.008
# /tmp/mfuncs/TF110_LithographyEdge.m:11
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF110_LithographyEdge.m:13
    f=base + dot(amp1,sin(dot(dot(dot(2,pi),freq1),x))) + dot(amp2,sin(dot(dot(dot(2,pi),freq2),x)))
# /tmp/mfuncs/TF110_LithographyEdge.m:14
    f=f + dot(0.14,exp(dot(- 0.5,((x - pos1) / w1) ** 2))) - dot(0.11,exp(dot(- 0.5,((x - pos2) / w2) ** 2)))
# /tmp/mfuncs/TF110_LithographyEdge.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF110_LithographyEdge.m:16
    meta.ID = copy('TF110')
# /tmp/mfuncs/TF110_LithographyEdge.m:17
    meta.Name = copy('Lithography Edge')
# /tmp/mfuncs/TF110_LithographyEdge.m:18
    meta.Category = copy(6)
# /tmp/mfuncs/TF110_LithographyEdge.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF110_LithographyEdge.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF110_LithographyEdge.m:21
    meta.Morphology = copy('Edge oscillations with positive and negative localized features')
# /tmp/mfuncs/TF110_LithographyEdge.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    