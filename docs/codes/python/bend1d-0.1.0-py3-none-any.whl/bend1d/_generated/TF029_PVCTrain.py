# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF029_PVCTrain(N=None,normalCenters=None,normalAmp=None,cPVC=None,*args,**kwargs):
    varargin = TF029_PVCTrain.varargin
    nargin = TF029_PVCTrain.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF029_PVCTrain.m:2
    
    if nargin < 2 or isempty(normalCenters):
        normalCenters=concat([0.09,0.22,0.35,0.48,0.76,0.89])
# /tmp/mfuncs/TF029_PVCTrain.m:3
    
    if nargin < 3 or isempty(normalAmp):
        normalAmp=concat([1.0,0.98,1.03,1.0,0.97,1.02])
# /tmp/mfuncs/TF029_PVCTrain.m:4
    
    if nargin < 4 or isempty(cPVC):
        cPVC=0.595
# /tmp/mfuncs/TF029_PVCTrain.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF029_PVCTrain.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF029_PVCTrain.m:7
    for ib in arange(1,numel(normalCenters)).reshape(-1):
        c=normalCenters(ib)
# /tmp/mfuncs/TF029_PVCTrain.m:9
        aBeat=normalAmp(ib)
# /tmp/mfuncs/TF029_PVCTrain.m:10
        f=f + dot(aBeat,(dot(0.12,exp(dot(- 0.5,((x - (c - 0.036)) / 0.012) ** 2))) - dot(0.14,exp(dot(- 0.5,((x - (c - 0.008)) / 0.0045) ** 2))) + dot(1.0,exp(dot(- 0.5,((x - c) / 0.0055) ** 2))) - dot(0.26,exp(dot(- 0.5,((x - (c + 0.01)) / 0.006) ** 2))) + dot(0.3,exp(dot(- 0.5,((x - (c + 0.042)) / 0.018) ** 2)))))
# /tmp/mfuncs/TF029_PVCTrain.m:11
    
    f=f + dot(1.05,exp(dot(- 0.5,((x - (cPVC - 0.006)) / 0.012) ** 2))) - dot(0.72,exp(dot(- 0.5,((x - (cPVC + 0.011)) / 0.015) ** 2))) + dot(0.42,exp(dot(- 0.5,((x - (cPVC + 0.045)) / 0.028) ** 2)))
# /tmp/mfuncs/TF029_PVCTrain.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF029_PVCTrain.m:22
    meta.ID = copy('TF029')
# /tmp/mfuncs/TF029_PVCTrain.m:23
    meta.Name = copy('PVC Train')
# /tmp/mfuncs/TF029_PVCTrain.m:24
    meta.Category = copy(3)
# /tmp/mfuncs/TF029_PVCTrain.m:25
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF029_PVCTrain.m:26
    meta.Parameters = copy(struct('normalCenters',normalCenters,'normalAmp',normalAmp,'cPVC',cPVC))
# /tmp/mfuncs/TF029_PVCTrain.m:27
    meta.Morphology = copy('Multiple P-QRS-T beats with a premature ventricular contraction and compensatory pause')
# /tmp/mfuncs/TF029_PVCTrain.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    