# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF206_OJIPFluorescence(N=None,amp1=None,amp2=None,amp3=None,*args,**kwargs):
    varargin = TF206_OJIPFluorescence.varargin
    nargin = TF206_OJIPFluorescence.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF206_OJIPFluorescence.m:2
    
    if nargin < 2 or isempty(amp1):
        amp1=0.28
# /tmp/mfuncs/TF206_OJIPFluorescence.m:3
    
    if nargin < 3 or isempty(amp2):
        amp2=0.25
# /tmp/mfuncs/TF206_OJIPFluorescence.m:4
    
    if nargin < 4 or isempty(amp3):
        amp3=0.38
# /tmp/mfuncs/TF206_OJIPFluorescence.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF206_OJIPFluorescence.m:6
    f=0.08 + dot(amp1,(1 - exp(- (x / 0.012) ** 1.25))) + dot(amp2,(1 - exp(- (x / 0.075) ** 1.15))) + dot(amp3,(1 - exp(- (x / 0.32) ** 1.55)))
# /tmp/mfuncs/TF206_OJIPFluorescence.m:7
    f=f + dot(0.035,G(x,0.085,0.018)) - dot(0.025,G(x,0.2,0.032))
# /tmp/mfuncs/TF206_OJIPFluorescence.m:11
    meta=copy(struct)
# /tmp/mfuncs/TF206_OJIPFluorescence.m:12
    meta.ID = copy('TF206')
# /tmp/mfuncs/TF206_OJIPFluorescence.m:13
    meta.Name = copy('OJIP Chlorophyll Fluorescence')
# /tmp/mfuncs/TF206_OJIPFluorescence.m:14
    meta.Category = copy(10)
# /tmp/mfuncs/TF206_OJIPFluorescence.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF206_OJIPFluorescence.m:16
    meta.Parameters = copy(struct('amp1',amp1,'amp2',amp2,'amp3',amp3))
# /tmp/mfuncs/TF206_OJIPFluorescence.m:17
    meta.Morphology = copy('Multi-stage fluorescence rise with small peaks/dips')
# /tmp/mfuncs/TF206_OJIPFluorescence.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    