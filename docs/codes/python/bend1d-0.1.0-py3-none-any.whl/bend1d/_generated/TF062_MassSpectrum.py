# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF062_MassSpectrum(N=None,baseline_slope=None,baseline_amp=None,pkC_MS=None,pkA_MS=None,pkW_MS=None,*args,**kwargs):
    varargin = TF062_MassSpectrum.varargin
    nargin = TF062_MassSpectrum.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF062_MassSpectrum.m:2
    
    if nargin < 2 or isempty(baseline_slope):
        baseline_slope=0.018
# /tmp/mfuncs/TF062_MassSpectrum.m:3
    
    if nargin < 3 or isempty(baseline_amp):
        baseline_amp=0.022
# /tmp/mfuncs/TF062_MassSpectrum.m:4
    
    if nargin < 4 or isempty(pkC_MS):
        pkC_MS=concat([0.11,0.24,0.365,0.492,0.51,0.675,0.82,0.905])
# /tmp/mfuncs/TF062_MassSpectrum.m:5
    
    if nargin < 5 or isempty(pkA_MS):
        pkA_MS=concat([0.28,0.62,0.4,1.0,0.72,0.35,0.78,0.24])
# /tmp/mfuncs/TF062_MassSpectrum.m:6
    
    if nargin < 6 or isempty(pkW_MS):
        pkW_MS=concat([0.0045,0.0065,0.0035,0.005,0.0042,0.0075,0.0055,0.003])
# /tmp/mfuncs/TF062_MassSpectrum.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF062_MassSpectrum.m:9
    f=baseline_amp + dot(baseline_slope,x) + dot(0.035,exp(dot(- 0.5,((x - 0.73) / 0.18) ** 2)))
# /tmp/mfuncs/TF062_MassSpectrum.m:10
    for k in arange(1,numel(pkC_MS)).reshape(-1):
        f=f + dot(pkA_MS(k),exp(dot(- 0.5,((x - pkC_MS(k)) / pkW_MS(k)) ** 2)))
# /tmp/mfuncs/TF062_MassSpectrum.m:12
    
    meta=copy(struct)
# /tmp/mfuncs/TF062_MassSpectrum.m:14
    meta.ID = copy('TF062')
# /tmp/mfuncs/TF062_MassSpectrum.m:15
    meta.Name = copy('Mass Spectrum')
# /tmp/mfuncs/TF062_MassSpectrum.m:16
    meta.Category = copy(5)
# /tmp/mfuncs/TF062_MassSpectrum.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF062_MassSpectrum.m:18
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF062_MassSpectrum.m:19
    meta.Morphology = copy('Sparse narrow peaks of unequal height, a close doublet, and weak broad baseline')
# /tmp/mfuncs/TF062_MassSpectrum.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    