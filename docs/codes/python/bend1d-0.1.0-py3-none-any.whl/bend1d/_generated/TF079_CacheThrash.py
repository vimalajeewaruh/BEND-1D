# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF079_CacheThrash(N=None,base_a=None,base_amp=None,base_freq=None,win_c1=None,win_w1=None,win_c2=None,win_w2=None,switch_amp=None,switch_rate=None,edge_freq=None,edge_amp=None,*args,**kwargs):
    varargin = TF079_CacheThrash.varargin
    nargin = TF079_CacheThrash.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF079_CacheThrash.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=0.28
# /tmp/mfuncs/TF079_CacheThrash.m:3
    
    if nargin < 3 or isempty(base_amp):
        base_amp=0.035
# /tmp/mfuncs/TF079_CacheThrash.m:4
    
    if nargin < 4 or isempty(base_freq):
        base_freq=4
# /tmp/mfuncs/TF079_CacheThrash.m:5
    
    if nargin < 5 or isempty(win_c1):
        win_c1=0.34
# /tmp/mfuncs/TF079_CacheThrash.m:6
    
    if nargin < 6 or isempty(win_w1):
        win_w1=0.005
# /tmp/mfuncs/TF079_CacheThrash.m:7
    
    if nargin < 7 or isempty(win_c2):
        win_c2=0.73
# /tmp/mfuncs/TF079_CacheThrash.m:8
    
    if nargin < 8 or isempty(win_w2):
        win_w2=0.005
# /tmp/mfuncs/TF079_CacheThrash.m:9
    
    if nargin < 9 or isempty(switch_amp):
        switch_amp=0.24
# /tmp/mfuncs/TF079_CacheThrash.m:10
    
    if nargin < 10 or isempty(switch_rate):
        switch_rate=22
# /tmp/mfuncs/TF079_CacheThrash.m:11
    
    if nargin < 11 or isempty(edge_freq):
        edge_freq=7
# /tmp/mfuncs/TF079_CacheThrash.m:12
    
    if nargin < 12 or isempty(edge_amp):
        edge_amp=0.08
# /tmp/mfuncs/TF079_CacheThrash.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF079_CacheThrash.m:15
    baseCT=base_a + dot(base_amp,sin(dot(dot(dot(2,pi),base_freq),x)))
# /tmp/mfuncs/TF079_CacheThrash.m:16
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF079_CacheThrash.m:17
    windowCT=sigmoid(x,win_c1,win_w1) - sigmoid(x,win_c2,win_w2)
# /tmp/mfuncs/TF079_CacheThrash.m:18
    switchCT=dot(switch_amp,tanh(dot(5,sin(dot(dot(dot(2,pi),switch_rate),x)))))
# /tmp/mfuncs/TF079_CacheThrash.m:19
    edgeCT=multiply(dot(edge_amp,sin(dot(dot(dot(2,pi),edge_freq),x))),windowCT)
# /tmp/mfuncs/TF079_CacheThrash.m:20
    f=baseCT + multiply(windowCT,switchCT) + edgeCT
# /tmp/mfuncs/TF079_CacheThrash.m:21
    meta=copy(struct)
# /tmp/mfuncs/TF079_CacheThrash.m:22
    meta.ID = copy('TF079')
# /tmp/mfuncs/TF079_CacheThrash.m:23
    meta.Name = copy('Cache Thrash')
# /tmp/mfuncs/TF079_CacheThrash.m:24
    meta.Category = copy(6)
# /tmp/mfuncs/TF079_CacheThrash.m:25
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF079_CacheThrash.m:26
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF079_CacheThrash.m:27
    meta.Morphology = copy('Windowed switching oscillation with edge modulation')
# /tmp/mfuncs/TF079_CacheThrash.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    