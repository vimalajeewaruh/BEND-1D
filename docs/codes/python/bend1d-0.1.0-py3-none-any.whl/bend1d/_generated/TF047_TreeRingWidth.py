# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF047_TreeRingWidth(N=None,a1=None,p1=None,a2=None,a3=None,d1_ctr=None,d1_w=None,d2_ctr=None,d2_w=None,rec_amp=None,rec_ctr=None,rec_w=None,*args,**kwargs):
    varargin = TF047_TreeRingWidth.varargin
    nargin = TF047_TreeRingWidth.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF047_TreeRingWidth.m:2
    
    if nargin < 2 or isempty(a1):
        a1=0.75
# /tmp/mfuncs/TF047_TreeRingWidth.m:3
    
    if nargin < 3 or isempty(p1):
        p1=0.12
# /tmp/mfuncs/TF047_TreeRingWidth.m:4
    
    if nargin < 4 or isempty(a2):
        a2=0.07
# /tmp/mfuncs/TF047_TreeRingWidth.m:5
    
    if nargin < 5 or isempty(a3):
        a3=0.035
# /tmp/mfuncs/TF047_TreeRingWidth.m:6
    
    if nargin < 6 or isempty(d1_ctr):
        d1_ctr=0.34
# /tmp/mfuncs/TF047_TreeRingWidth.m:7
    
    if nargin < 7 or isempty(d1_w):
        d1_w=0.055
# /tmp/mfuncs/TF047_TreeRingWidth.m:8
    
    if nargin < 8 or isempty(d2_ctr):
        d2_ctr=0.72
# /tmp/mfuncs/TF047_TreeRingWidth.m:9
    
    if nargin < 9 or isempty(d2_w):
        d2_w=0.035
# /tmp/mfuncs/TF047_TreeRingWidth.m:10
    
    if nargin < 10 or isempty(rec_amp):
        rec_amp=0.14
# /tmp/mfuncs/TF047_TreeRingWidth.m:11
    
    if nargin < 11 or isempty(rec_ctr):
        rec_ctr=0.43
# /tmp/mfuncs/TF047_TreeRingWidth.m:12
    
    if nargin < 12 or isempty(rec_w):
        rec_w=0.025
# /tmp/mfuncs/TF047_TreeRingWidth.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF047_TreeRingWidth.m:15
    f=a1 + dot(p1,sin(dot(dot(dot(2,pi),5),x) + 0.3)) + dot(a2,sin(dot(dot(dot(2,pi),13),x))) + dot(a3,sin(dot(dot(dot(2,pi),31),x) + 0.7))
# /tmp/mfuncs/TF047_TreeRingWidth.m:16
    drought1=dot(0.42,exp(dot(- 0.5,((x - d1_ctr) / d1_w) ** 2)))
# /tmp/mfuncs/TF047_TreeRingWidth.m:17
    drought2=dot(0.3,exp(dot(- 0.5,((x - d2_ctr) / d2_w) ** 2)))
# /tmp/mfuncs/TF047_TreeRingWidth.m:18
    recovery=dot(rec_amp,exp(dot(- 0.5,((x - rec_ctr) / rec_w) ** 2)))
# /tmp/mfuncs/TF047_TreeRingWidth.m:19
    f=f - drought1 - drought2 + recovery
# /tmp/mfuncs/TF047_TreeRingWidth.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF047_TreeRingWidth.m:21
    meta.ID = copy('TF047')
# /tmp/mfuncs/TF047_TreeRingWidth.m:22
    meta.Name = copy('Tree-Ring Width')
# /tmp/mfuncs/TF047_TreeRingWidth.m:23
    meta.Category = copy(4)
# /tmp/mfuncs/TF047_TreeRingWidth.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF047_TreeRingWidth.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF047_TreeRingWidth.m:26
    meta.Morphology = copy('Multi-year growth with droughts and recovery')
# /tmp/mfuncs/TF047_TreeRingWidth.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    