# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF024_MuscleTwitch(N=None,*args,**kwargs):
    varargin = TF024_MuscleTwitch.varargin
    nargin = TF024_MuscleTwitch.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF024_MuscleTwitch.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF024_MuscleTwitch.m:3
    tMuscle=concat([0.1,0.24,0.39,0.44,0.67,0.83])
# /tmp/mfuncs/TF024_MuscleTwitch.m:4
    AMuscle=concat([0.7,1.0,0.55,0.85,1.15,0.65])
# /tmp/mfuncs/TF024_MuscleTwitch.m:5
    tauMuscle=concat([0.035,0.05,0.028,0.042,0.06,0.032])
# /tmp/mfuncs/TF024_MuscleTwitch.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF024_MuscleTwitch.m:7
    for k in arange(1,numel(tMuscle)).reshape(-1):
        u=(x - tMuscle(k)) / tauMuscle(k)
# /tmp/mfuncs/TF024_MuscleTwitch.m:9
        ind=u >= 0
# /tmp/mfuncs/TF024_MuscleTwitch.m:10
        tmp=zeros(size(x))
# /tmp/mfuncs/TF024_MuscleTwitch.m:11
        tmp[ind]=multiply(dot(AMuscle(k),u(ind)),exp(1 - u(ind)))
# /tmp/mfuncs/TF024_MuscleTwitch.m:12
        f=f + tmp
# /tmp/mfuncs/TF024_MuscleTwitch.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF024_MuscleTwitch.m:15
    meta.ID = copy('TF024')
# /tmp/mfuncs/TF024_MuscleTwitch.m:16
    meta.Name = copy('Muscle Twitch')
# /tmp/mfuncs/TF024_MuscleTwitch.m:17
    meta.Category = copy(2)
# /tmp/mfuncs/TF024_MuscleTwitch.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF024_MuscleTwitch.m:19
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF024_MuscleTwitch.m:20
    meta.Morphology = copy('Superposition of causal alpha-function responses')
# /tmp/mfuncs/TF024_MuscleTwitch.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    