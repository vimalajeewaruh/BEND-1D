# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF221_ENSOEnvelope(N=None,ampBase=None,ampMod=None,phaseLin=None,phaseQuad=None,*args,**kwargs):
    varargin = TF221_ENSOEnvelope.varargin
    nargin = TF221_ENSOEnvelope.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF221_ENSOEnvelope.m:2
    
    if nargin < 2 or isempty(ampBase):
        ampBase=0.45
# /tmp/mfuncs/TF221_ENSOEnvelope.m:3
    
    if nargin < 3 or isempty(ampMod):
        ampMod=0.2
# /tmp/mfuncs/TF221_ENSOEnvelope.m:4
    
    if nargin < 4 or isempty(phaseLin):
        phaseLin=2.1
# /tmp/mfuncs/TF221_ENSOEnvelope.m:5
    
    if nargin < 5 or isempty(phaseQuad):
        phaseQuad=0.22
# /tmp/mfuncs/TF221_ENSOEnvelope.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF221_ENSOEnvelope.m:7
    amp=ampBase + dot(ampMod,sin(dot(dot(dot(2,pi),0.75),x) + 0.4))
# /tmp/mfuncs/TF221_ENSOEnvelope.m:8
    phase=dot(dot(2,pi),(dot(phaseLin,x) + dot(phaseQuad,x ** 2)))
# /tmp/mfuncs/TF221_ENSOEnvelope.m:9
    f=multiply(amp,sin(phase)) + dot(0.22,G(x,0.28,0.06)) - dot(0.18,G(x,0.57,0.07)) + dot(0.25,G(x,0.83,0.045))
# /tmp/mfuncs/TF221_ENSOEnvelope.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF221_ENSOEnvelope.m:11
    meta.ID = copy('TF221')
# /tmp/mfuncs/TF221_ENSOEnvelope.m:12
    meta.Name = copy('ENSO Envelope')
# /tmp/mfuncs/TF221_ENSOEnvelope.m:13
    meta.Category = copy(12)
# /tmp/mfuncs/TF221_ENSOEnvelope.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF221_ENSOEnvelope.m:15
    meta.Parameters = copy(struct('ampBase',ampBase,'ampMod',ampMod,'phaseLin',phaseLin,'phaseQuad',phaseQuad))
# /tmp/mfuncs/TF221_ENSOEnvelope.m:16
    meta.Morphology = copy('Amplitude-modulated oscillation with localized bumps')
# /tmp/mfuncs/TF221_ENSOEnvelope.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    