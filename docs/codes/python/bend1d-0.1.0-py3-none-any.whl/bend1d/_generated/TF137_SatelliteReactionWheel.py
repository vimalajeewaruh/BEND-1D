# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF137_SatelliteReactionWheel(N=None,a1=None,a2=None,phaseShift1=None,phaseShift2=None,localizedCtr=None,localizedW=None,localizedAmp=None,negSpikeCtr=None,negSpikeW=None,negSpikeAmp=None,*args,**kwargs):
    varargin = TF137_SatelliteReactionWheel.varargin
    nargin = TF137_SatelliteReactionWheel.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:2
    
    if nargin < 2 or isempty(a1):
        a1=0.22
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:3
    
    if nargin < 3 or isempty(a2):
        a2=0.14
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:4
    
    if nargin < 4 or isempty(phaseShift1):
        phaseShift1=0
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:5
    
    if nargin < 5 or isempty(phaseShift2):
        phaseShift2=0.5
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:6
    
    if nargin < 6 or isempty(localizedCtr):
        localizedCtr=0.58
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:7
    
    if nargin < 7 or isempty(localizedW):
        localizedW=0.065
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:8
    
    if nargin < 8 or isempty(localizedAmp):
        localizedAmp=0.2
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:9
    
    if nargin < 9 or isempty(negSpikeCtr):
        negSpikeCtr=0.82
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:10
    
    if nargin < 10 or isempty(negSpikeW):
        negSpikeW=0.008
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:11
    
    if nargin < 11 or isempty(negSpikeAmp):
        negSpikeAmp=0.32
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:14
    phase1SR=dot(dot(2,pi),(dot(18,x) + dot(3,x ** 2)))
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:15
    phase2SR=dot(dot(2,pi),(dot(31,x) - dot(2,x ** 2)))
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:16
    f=dot(a1,sin(phase1SR)) + dot(a2,sin(phase2SR + phaseShift2)) + multiply(dot(localizedAmp,exp(dot(- 0.5,((x - localizedCtr) / localizedW) ** 2))),sin(dot(dot(dot(2,pi),54),x))) - dot(negSpikeAmp,exp(dot(- 0.5,((x - negSpikeCtr) / negSpikeW) ** 2)))
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:18
    meta.ID = copy('TF137')
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:19
    meta.Name = copy('Satellite Reaction Wheel')
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:20
    meta.Category = copy(9)
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:23
    meta.Morphology = copy('Multi-component oscillations with localized destructive transient')
# /tmp/mfuncs/TF137_SatelliteReactionWheel.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    