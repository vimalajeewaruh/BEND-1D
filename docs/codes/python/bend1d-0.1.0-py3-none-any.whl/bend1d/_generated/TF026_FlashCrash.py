# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF026_FlashCrash(N=None,xcFC=None,*args,**kwargs):
    varargin = TF026_FlashCrash.varargin
    nargin = TF026_FlashCrash.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF026_FlashCrash.m:2
    
    if nargin < 2 or isempty(xcFC):
        xcFC=0.58
# /tmp/mfuncs/TF026_FlashCrash.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF026_FlashCrash.m:4
    background=1 + dot(0.12,sqrt(x + 0.02)) + dot(0.025,sin(dot(dot(10,pi),x)))
# /tmp/mfuncs/TF026_FlashCrash.m:5
    drop=dot(- 0.31,(1 + tanh(dot(180,(x - xcFC)))))
# /tmp/mfuncs/TF026_FlashCrash.m:6
    u=max(x - xcFC,0)
# /tmp/mfuncs/TF026_FlashCrash.m:7
    rebound=multiply(dot(0.48,(x >= xcFC)),(1 - exp(dot(- 22,u))))
# /tmp/mfuncs/TF026_FlashCrash.m:8
    volatility=multiply(multiply(dot(0.09,(x >= xcFC)),exp(dot(- 10,u))),sin(dot(dot(65,pi),u)))
# /tmp/mfuncs/TF026_FlashCrash.m:9
    f=background + drop + rebound + volatility
# /tmp/mfuncs/TF026_FlashCrash.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF026_FlashCrash.m:11
    meta.ID = copy('TF026')
# /tmp/mfuncs/TF026_FlashCrash.m:12
    meta.Name = copy('Flash Crash')
# /tmp/mfuncs/TF026_FlashCrash.m:13
    meta.Category = copy(2)
# /tmp/mfuncs/TF026_FlashCrash.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF026_FlashCrash.m:15
    meta.Parameters = copy(struct('xcFC',xcFC))
# /tmp/mfuncs/TF026_FlashCrash.m:16
    meta.Morphology = copy('Slow background, rapid loss, delayed rebound, damped volatility')
# /tmp/mfuncs/TF026_FlashCrash.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 3