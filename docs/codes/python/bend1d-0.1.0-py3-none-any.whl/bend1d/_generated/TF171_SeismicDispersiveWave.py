# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF171_SeismicDispersiveWave(N=None,amp1=None,amp2=None,envAmp=None,envCenter=None,envWidth=None,codaAmp=None,codaDecay=None,*args,**kwargs):
    varargin = TF171_SeismicDispersiveWave.varargin
    nargin = TF171_SeismicDispersiveWave.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:2
    
    if nargin < 2 or isempty(amp1):
        amp1=0.015
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:3
    
    if nargin < 3 or isempty(amp2):
        amp2=0.1
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:4
    
    if nargin < 4 or isempty(envAmp):
        envAmp=0.48
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:5
    
    if nargin < 5 or isempty(envCenter):
        envCenter=0.64
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:6
    
    if nargin < 6 or isempty(envWidth):
        envWidth=0.16
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:7
    
    if nargin < 7 or isempty(codaAmp):
        codaAmp=0.1
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:8
    
    if nargin < 8 or isempty(codaDecay):
        codaDecay=9
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:9
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:10
    f=dot(amp1,sin(dot(dot(dot(2,pi),3),x))) + multiply(dot(amp2,exp(dot(- 0.5,((x - 0.24) / 0.025) ** 2))),sin(dot(dot(dot(2,pi),42),x)))
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:11
    uSD=max(x - 0.39,0)
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:12
    envSD=multiply((x >= 0.39),exp(dot(- 0.5,((x - envCenter) / envWidth) ** 2)))
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:13
    f=f + multiply(dot(envAmp,envSD),sin(dot(dot(2,pi),(dot(34,uSD) - dot(10,uSD ** 2)))))
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:14
    uCoda=max(x - 0.72,0)
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:15
    f=f + multiply(multiply(multiply((x >= 0.72),codaAmp),exp(dot(- codaDecay,uCoda))),sin(dot(dot(dot(2,pi),48),uCoda)))
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:17
    meta.ID = copy('TF171')
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:18
    meta.Name = copy('Seismic Dispersive Wave')
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:19
    meta.Category = copy(9)
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:21
    meta.Parameters = copy(struct('amp1',amp1,'amp2',amp2,'envAmp',envAmp,'envCenter',envCenter,'envWidth',envWidth,'codaAmp',codaAmp,'codaDecay',codaDecay))
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:22
    meta.Morphology = copy('Dispersive seismic wave with localized high-frequency components')
# /tmp/mfuncs/TF171_SeismicDispersiveWave.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    