# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF169_TGADecomposition(N=None,*args,**kwargs):
    varargin = TF169_TGADecomposition.varargin
    nargin = TF169_TGADecomposition.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF169_TGADecomposition.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF169_TGADecomposition.m:3
    f=1 - dot(0.18,S(x,0.2,0.022)) - dot(0.38,S(x,0.49,0.03)) - dot(0.1,S(x,0.61,0.015)) - dot(0.25,S(x,0.77,0.02))
# /tmp/mfuncs/TF169_TGADecomposition.m:4
    meta=copy(struct)
# /tmp/mfuncs/TF169_TGADecomposition.m:5
    meta.ID = copy('TF169')
# /tmp/mfuncs/TF169_TGADecomposition.m:6
    meta.Name = copy('TGA Decomposition')
# /tmp/mfuncs/TF169_TGADecomposition.m:7
    meta.Category = copy(9)
# /tmp/mfuncs/TF169_TGADecomposition.m:8
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF169_TGADecomposition.m:9
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF169_TGADecomposition.m:10
    meta.Morphology = copy('Stepwise mass loss modeled with smooth transitions')
# /tmp/mfuncs/TF169_TGADecomposition.m:11
    return x,f,meta
    
if __name__ == '__main__':
    pass
    