# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF145_DerivativeZoo(N=None,linAmp=None,stepCtr=None,stepW=None,absCtr=None,quadAmp=None,quadCtr=None,sqrtAmp=None,sqrtCtr=None,gaussAmp=None,gaussCtr=None,gaussW=None,*args,**kwargs):
    varargin = TF145_DerivativeZoo.varargin
    nargin = TF145_DerivativeZoo.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF145_DerivativeZoo.m:2
    
    if nargin < 2 or isempty(linAmp):
        linAmp=0.1
# /tmp/mfuncs/TF145_DerivativeZoo.m:3
    
    if nargin < 3 or isempty(stepCtr):
        stepCtr=0.18
# /tmp/mfuncs/TF145_DerivativeZoo.m:4
    
    if nargin < 4 or isempty(stepW):
        stepW=0.0025
# /tmp/mfuncs/TF145_DerivativeZoo.m:5
    
    if nargin < 5 or isempty(absCtr):
        absCtr=0.36
# /tmp/mfuncs/TF145_DerivativeZoo.m:6
    
    if nargin < 6 or isempty(quadAmp):
        quadAmp=0.18
# /tmp/mfuncs/TF145_DerivativeZoo.m:7
    
    if nargin < 7 or isempty(quadCtr):
        quadCtr=0.55
# /tmp/mfuncs/TF145_DerivativeZoo.m:8
    
    if nargin < 8 or isempty(sqrtAmp):
        sqrtAmp=0.25
# /tmp/mfuncs/TF145_DerivativeZoo.m:9
    
    if nargin < 9 or isempty(sqrtCtr):
        sqrtCtr=0.72
# /tmp/mfuncs/TF145_DerivativeZoo.m:10
    
    if nargin < 10 or isempty(gaussAmp):
        gaussAmp=0.16
# /tmp/mfuncs/TF145_DerivativeZoo.m:11
    
    if nargin < 11 or isempty(gaussCtr):
        gaussCtr=0.88
# /tmp/mfuncs/TF145_DerivativeZoo.m:12
    
    if nargin < 12 or isempty(gaussW):
        gaussW=0.025
# /tmp/mfuncs/TF145_DerivativeZoo.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF145_DerivativeZoo.m:15
    f=dot(linAmp,x) + dot(0.28,S(x,stepCtr,stepW)) + dot(0.35,abs(x - absCtr)) + dot(dot(quadAmp,(x - quadCtr) ** 2.0),(x >= quadCtr)) + dot(sqrtAmp,sqrt(abs(x - sqrtCtr))) + dot(gaussAmp,exp(dot(- 0.5,((x - gaussCtr) / gaussW) ** 2)))
# /tmp/mfuncs/TF145_DerivativeZoo.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF145_DerivativeZoo.m:17
    meta.ID = copy('TF145')
# /tmp/mfuncs/TF145_DerivativeZoo.m:18
    meta.Name = copy('Derivative Zoo')
# /tmp/mfuncs/TF145_DerivativeZoo.m:19
    meta.Category = copy(9)
# /tmp/mfuncs/TF145_DerivativeZoo.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF145_DerivativeZoo.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF145_DerivativeZoo.m:22
    meta.Morphology = copy('Mixture of features designed to provoke varied derivative behavior')
# /tmp/mfuncs/TF145_DerivativeZoo.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    