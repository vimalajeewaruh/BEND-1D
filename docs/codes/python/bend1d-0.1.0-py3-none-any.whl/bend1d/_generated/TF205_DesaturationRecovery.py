# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF205_DesaturationRecovery(N=None,c=None,a=None,tf=None,ts=None,*args,**kwargs):
    varargin = TF205_DesaturationRecovery.varargin
    nargin = TF205_DesaturationRecovery.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF205_DesaturationRecovery.m:2
    
    if nargin < 2 or isempty(c):
        c=concat([0.34,0.67])
# /tmp/mfuncs/TF205_DesaturationRecovery.m:3
    
    if nargin < 3 or isempty(a):
        a=concat([0.54,0.34])
# /tmp/mfuncs/TF205_DesaturationRecovery.m:4
    
    if nargin < 4 or isempty(tf):
        tf=concat([0.012,0.018])
# /tmp/mfuncs/TF205_DesaturationRecovery.m:5
    
    if nargin < 5 or isempty(ts):
        ts=concat([0.19,0.14])
# /tmp/mfuncs/TF205_DesaturationRecovery.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF205_DesaturationRecovery.m:7
    f=ones(size(x))
# /tmp/mfuncs/TF205_DesaturationRecovery.m:8
    for k in arange(1,numel(c)).reshape(-1):
        uk=max(x - c(k),0)
# /tmp/mfuncs/TF205_DesaturationRecovery.m:10
        f=f - multiply(multiply(multiply((x >= c(k)),a(k)),(1 - exp(- uk / tf(k)))),exp(- uk / ts(k)))
# /tmp/mfuncs/TF205_DesaturationRecovery.m:11
    
    meta=copy(struct)
# /tmp/mfuncs/TF205_DesaturationRecovery.m:13
    meta.ID = copy('TF205')
# /tmp/mfuncs/TF205_DesaturationRecovery.m:14
    meta.Name = copy('Desaturation + Recovery')
# /tmp/mfuncs/TF205_DesaturationRecovery.m:15
    meta.Category = copy(10)
# /tmp/mfuncs/TF205_DesaturationRecovery.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF205_DesaturationRecovery.m:17
    meta.Parameters = copy(struct('c',c,'a',a,'tf',tf,'ts',ts))
# /tmp/mfuncs/TF205_DesaturationRecovery.m:18
    meta.Morphology = copy('Step-like desaturations with slow recovery')
# /tmp/mfuncs/TF205_DesaturationRecovery.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    