# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF067_FluorescencePhotobleach(N=None,bleach_a_fast=None,bleach_k_fast=None,bleach_a_slow=None,bleach_k_slow=None,bleach_offset=None,recovery_amp=None,recovery_ctr=None,recovery_w=None,smallStep_amp=None,smallStep_k=None,smallStep_ctr=None,*args,**kwargs):
    varargin = TF067_FluorescencePhotobleach.varargin
    nargin = TF067_FluorescencePhotobleach.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:2
    
    if nargin < 2 or isempty(bleach_a_fast):
        bleach_a_fast=0.72
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:3
    
    if nargin < 3 or isempty(bleach_k_fast):
        bleach_k_fast=3.8
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:4
    
    if nargin < 4 or isempty(bleach_a_slow):
        bleach_a_slow=0.3
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:5
    
    if nargin < 5 or isempty(bleach_k_slow):
        bleach_k_slow=0.62
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:6
    
    if nargin < 6 or isempty(bleach_offset):
        bleach_offset=0.035
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:7
    
    if nargin < 7 or isempty(recovery_amp):
        recovery_amp=0.07
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:8
    
    if nargin < 8 or isempty(recovery_ctr):
        recovery_ctr=0.56
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:9
    
    if nargin < 9 or isempty(recovery_w):
        recovery_w=0.045
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:10
    
    if nargin < 10 or isempty(smallStep_amp):
        smallStep_amp=0.03
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:11
    
    if nargin < 11 or isempty(smallStep_k):
        smallStep_k=75
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:12
    
    if nargin < 12 or isempty(smallStep_ctr):
        smallStep_ctr=0.73
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:15
    bleach=dot(bleach_a_fast,exp(dot(- bleach_k_fast,x))) + dot(bleach_a_slow,exp(dot(- bleach_k_slow,x))) + bleach_offset
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:16
    recovery=dot(recovery_amp,exp(dot(- 0.5,((x - recovery_ctr) / recovery_w) ** 2)))
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:17
    smallStep=smallStep_amp / (1 + exp(dot(- smallStep_k,(x - smallStep_ctr))))
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:18
    f=bleach + recovery + smallStep
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:21
    meta.ID = copy('TF067')
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:22
    meta.Name = copy('Fluorescence Photobleaching')
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:23
    meta.Category = copy(6)
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:26
    meta.Morphology = copy('Fast and slow bleaching with weak recovery/rebinding transient')
# /tmp/mfuncs/TF067_FluorescencePhotobleach.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    