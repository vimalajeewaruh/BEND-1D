# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF184_MagnetarBurstStorm(N=None,c=None,a=None,w=None,*args,**kwargs):
    varargin = TF184_MagnetarBurstStorm.varargin
    nargin = TF184_MagnetarBurstStorm.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:2
    
    if nargin < 2 or isempty(c):
        c=concat([0.16,0.28,0.295,0.48,0.67,0.715,0.83])
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:3
    
    if nargin < 3 or isempty(a):
        a=concat([0.55,0.42,0.25,0.92,0.38,0.62,0.3])
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:4
    
    if nargin < 4 or isempty(w):
        w=concat([0.008,0.006,0.0035,0.01,0.005,0.006,0.004])
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:6
    f=dot(0.025,sin(dot(dot(dot(2,pi),3),x)))
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:7
    for k in arange(1,numel(c)).reshape(-1):
        f=f + dot(a(k),G(x,c(k),w(k)))
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:9
    
    for k in arange(1,2).reshape(-1):
        cc=concat([0.48,0.715])
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:12
        aa=concat([0.18,0.12])
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:12
        u=max(x - cc(k),0)
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:13
        f=f + multiply(multiply(multiply((x >= cc(k)),aa(k)),exp(dot(- 22,u))),sin(dot(dot(dot(2,pi),55),u)))
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:14
    
    meta=copy(struct)
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:16
    meta.ID = copy('TF184')
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:17
    meta.Name = copy('Magnetar Burst Storm')
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:18
    meta.Category = copy(10)
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:20
    meta.Parameters = copy(struct('centers',c,'amps',a,'widths',w))
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:21
    meta.Morphology = copy('Burst pulses on background oscillation with decaying transients')
# /tmp/mfuncs/TF184_MagnetarBurstStorm.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    