# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF178_RayleighDoubletLadder(N=None,cRDL=None,dRDL=None,wRDL=None,ampRDL=None,*args,**kwargs):
    varargin = TF178_RayleighDoubletLadder.varargin
    nargin = TF178_RayleighDoubletLadder.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:2
    
    if nargin < 2 or isempty(cRDL):
        cRDL=concat([0.1,0.25,0.4,0.55,0.7,0.85])
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:3
    
    if nargin < 3 or isempty(dRDL):
        dRDL=concat([0.06,0.045,0.032,0.024,0.018,0.012])
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:4
    
    if nargin < 4 or isempty(wRDL):
        wRDL=0.01
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:5
    
    if nargin < 5 or isempty(ampRDL):
        ampRDL=1.0
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:8
    for k in arange(1,numel(cRDL)).reshape(-1):
        f=f + dot(ampRDL,(exp(dot(- 0.5,((x - (cRDL(k) - dRDL(k) / 2)) / wRDL) ** 2)) + exp(dot(- 0.5,((x - (cRDL(k) + dRDL(k) / 2)) / wRDL) ** 2))))
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:10
    
    meta=copy(struct)
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:12
    meta.ID = copy('TF178')
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:13
    meta.Name = copy('Rayleigh Doublet Ladder')
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:14
    meta.Category = copy(9)
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:16
    meta.Parameters = copy(struct('centers',cRDL,'separation',dRDL,'width',wRDL,'amp',ampRDL))
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:17
    meta.Morphology = copy('Ladder of Rayleigh doublets with decreasing spacing')
# /tmp/mfuncs/TF178_RayleighDoubletLadder.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    