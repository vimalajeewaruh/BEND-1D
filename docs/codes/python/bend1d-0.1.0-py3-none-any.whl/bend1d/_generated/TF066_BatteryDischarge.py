# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF066_BatteryDischarge(N=None,plateau_a=None,plateau_b=None,plateau_c=None,phaseDrop_amp=None,phaseDrop_k=None,phaseDrop_ctr=None,phaseRecov_amp=None,phaseRecov_k=None,phaseRecov_ctr=None,shoulder_amp=None,shoulder_ctr=None,shoulder_w=None,terminal_amp=None,terminal_k=None,terminal_ctr=None,micro_amp=None,micro_freq=None,micro_decay=None,*args,**kwargs):
    varargin = TF066_BatteryDischarge.varargin
    nargin = TF066_BatteryDischarge.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF066_BatteryDischarge.m:2
    
    if nargin < 2 or isempty(plateau_a):
        plateau_a=1.05
# /tmp/mfuncs/TF066_BatteryDischarge.m:3
    
    if nargin < 3 or isempty(plateau_b):
        plateau_b=- 0.075
# /tmp/mfuncs/TF066_BatteryDischarge.m:4
    
    if nargin < 4 or isempty(plateau_c):
        plateau_c=- 0.02
# /tmp/mfuncs/TF066_BatteryDischarge.m:5
    
    if nargin < 5 or isempty(phaseDrop_amp):
        phaseDrop_amp=- 0.06
# /tmp/mfuncs/TF066_BatteryDischarge.m:6
    
    if nargin < 6 or isempty(phaseDrop_k):
        phaseDrop_k=55
# /tmp/mfuncs/TF066_BatteryDischarge.m:7
    
    if nargin < 7 or isempty(phaseDrop_ctr):
        phaseDrop_ctr=0.36
# /tmp/mfuncs/TF066_BatteryDischarge.m:8
    
    if nargin < 8 or isempty(phaseRecov_amp):
        phaseRecov_amp=0.036
# /tmp/mfuncs/TF066_BatteryDischarge.m:9
    
    if nargin < 9 or isempty(phaseRecov_k):
        phaseRecov_k=48
# /tmp/mfuncs/TF066_BatteryDischarge.m:10
    
    if nargin < 10 or isempty(phaseRecov_ctr):
        phaseRecov_ctr=0.5
# /tmp/mfuncs/TF066_BatteryDischarge.m:11
    
    if nargin < 11 or isempty(shoulder_amp):
        shoulder_amp=0.018
# /tmp/mfuncs/TF066_BatteryDischarge.m:12
    
    if nargin < 12 or isempty(shoulder_ctr):
        shoulder_ctr=0.62
# /tmp/mfuncs/TF066_BatteryDischarge.m:13
    
    if nargin < 13 or isempty(shoulder_w):
        shoulder_w=0.05
# /tmp/mfuncs/TF066_BatteryDischarge.m:14
    
    if nargin < 14 or isempty(terminal_amp):
        terminal_amp=- 0.55
# /tmp/mfuncs/TF066_BatteryDischarge.m:15
    
    if nargin < 15 or isempty(terminal_k):
        terminal_k=48
# /tmp/mfuncs/TF066_BatteryDischarge.m:16
    
    if nargin < 16 or isempty(terminal_ctr):
        terminal_ctr=0.885
# /tmp/mfuncs/TF066_BatteryDischarge.m:17
    
    if nargin < 17 or isempty(micro_amp):
        micro_amp=0.006
# /tmp/mfuncs/TF066_BatteryDischarge.m:18
    
    if nargin < 18 or isempty(micro_freq):
        micro_freq=6
# /tmp/mfuncs/TF066_BatteryDischarge.m:19
    
    if nargin < 19 or isempty(micro_decay):
        micro_decay=1.2
# /tmp/mfuncs/TF066_BatteryDischarge.m:20
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF066_BatteryDischarge.m:22
    plateau=plateau_a + dot(plateau_b,x) + dot(plateau_c,x ** 2)
# /tmp/mfuncs/TF066_BatteryDischarge.m:23
    phaseDrop=phaseDrop_amp / (1 + exp(dot(- phaseDrop_k,(x - phaseDrop_ctr))))
# /tmp/mfuncs/TF066_BatteryDischarge.m:24
    phaseRecover=phaseRecov_amp / (1 + exp(dot(- phaseRecov_k,(x - phaseRecov_ctr))))
# /tmp/mfuncs/TF066_BatteryDischarge.m:25
    shoulderBattery=dot(shoulder_amp,exp(dot(- 0.5,((x - shoulder_ctr) / shoulder_w) ** 2)))
# /tmp/mfuncs/TF066_BatteryDischarge.m:26
    terminalDrop=terminal_amp / (1 + exp(dot(- terminal_k,(x - terminal_ctr))))
# /tmp/mfuncs/TF066_BatteryDischarge.m:27
    microRipple=multiply(dot(micro_amp,sin(dot(dot(dot(2,pi),micro_freq),x))),exp(dot(- micro_decay,x)))
# /tmp/mfuncs/TF066_BatteryDischarge.m:28
    f=plateau + phaseDrop + phaseRecover + shoulderBattery + terminalDrop + microRipple
# /tmp/mfuncs/TF066_BatteryDischarge.m:29
    meta=copy(struct)
# /tmp/mfuncs/TF066_BatteryDischarge.m:31
    meta.ID = copy('TF066')
# /tmp/mfuncs/TF066_BatteryDischarge.m:32
    meta.Name = copy('Battery Discharge')
# /tmp/mfuncs/TF066_BatteryDischarge.m:33
    meta.Category = copy(6)
# /tmp/mfuncs/TF066_BatteryDischarge.m:34
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF066_BatteryDischarge.m:35
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF066_BatteryDischarge.m:36
    meta.Morphology = copy('Long plateau, phase-transition shoulder, and steep terminal drop with micro-ripple')
# /tmp/mfuncs/TF066_BatteryDischarge.m:37
    return x,f,meta
    
if __name__ == '__main__':
    pass
    