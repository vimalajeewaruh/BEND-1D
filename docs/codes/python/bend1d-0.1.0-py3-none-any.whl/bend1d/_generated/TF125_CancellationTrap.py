# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF125_CancellationTrap(N=None,g1Amp=None,g1C=None,g1W=None,g2Amp=None,g2C=None,g2W=None,residAmp1=None,residFreq=None,residAmp2=None,residC=None,residW=None,*args,**kwargs):
    varargin = TF125_CancellationTrap.varargin
    nargin = TF125_CancellationTrap.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF125_CancellationTrap.m:2
    
    if nargin < 2 or isempty(g1Amp):
        g1Amp=0.85
# /tmp/mfuncs/TF125_CancellationTrap.m:3
    
    if nargin < 3 or isempty(g1C):
        g1C=0.48
# /tmp/mfuncs/TF125_CancellationTrap.m:4
    
    if nargin < 4 or isempty(g1W):
        g1W=0.19
# /tmp/mfuncs/TF125_CancellationTrap.m:5
    
    if nargin < 5 or isempty(g2Amp):
        g2Amp=0.82
# /tmp/mfuncs/TF125_CancellationTrap.m:6
    
    if nargin < 6 or isempty(g2C):
        g2C=0.5
# /tmp/mfuncs/TF125_CancellationTrap.m:7
    
    if nargin < 7 or isempty(g2W):
        g2W=0.2
# /tmp/mfuncs/TF125_CancellationTrap.m:8
    
    if nargin < 8 or isempty(residAmp1):
        residAmp1=0.08
# /tmp/mfuncs/TF125_CancellationTrap.m:9
    
    if nargin < 9 or isempty(residFreq):
        residFreq=7
# /tmp/mfuncs/TF125_CancellationTrap.m:10
    
    if nargin < 10 or isempty(residAmp2):
        residAmp2=0.04
# /tmp/mfuncs/TF125_CancellationTrap.m:11
    
    if nargin < 11 or isempty(residC):
        residC=0.62
# /tmp/mfuncs/TF125_CancellationTrap.m:12
    
    if nargin < 12 or isempty(residW):
        residW=0.01
# /tmp/mfuncs/TF125_CancellationTrap.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF125_CancellationTrap.m:15
    g1=dot(g1Amp,exp(dot(- 0.5,((x - g1C) / g1W) ** 2)))
# /tmp/mfuncs/TF125_CancellationTrap.m:16
    g2=dot(g2Amp,exp(dot(- 0.5,((x - g2C) / g2W) ** 2)))
# /tmp/mfuncs/TF125_CancellationTrap.m:17
    resid=dot(residAmp1,sin(dot(dot(dot(2,pi),residFreq),x))) + dot(residAmp2,exp(dot(- 0.5,((x - residC) / residW) ** 2)))
# /tmp/mfuncs/TF125_CancellationTrap.m:18
    f=g1 - g2 + resid
# /tmp/mfuncs/TF125_CancellationTrap.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF125_CancellationTrap.m:20
    meta.ID = copy('TF125')
# /tmp/mfuncs/TF125_CancellationTrap.m:21
    meta.Name = copy('Cancellation Trap')
# /tmp/mfuncs/TF125_CancellationTrap.m:22
    meta.Category = copy(6)
# /tmp/mfuncs/TF125_CancellationTrap.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF125_CancellationTrap.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF125_CancellationTrap.m:25
    meta.Morphology = copy('Two similar Gaussians that largely cancel plus residuals')
# /tmp/mfuncs/TF125_CancellationTrap.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 8 : 126 - 155
    