# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF176_DyadicPhaseTwins(N=None,idxDPTp=None,ampDPT=None,sigmaDPT=None,freqDPT=None,*args,**kwargs):
    varargin = TF176_DyadicPhaseTwins.varargin
    nargin = TF176_DyadicPhaseTwins.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:2
    
    if nargin < 2 or isempty(idxDPTp):
        idxDPTp=concat([512,1409,2306,3203])
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:3
    
    if nargin < 3 or isempty(ampDPT):
        ampDPT=1.0
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:4
    
    if nargin < 4 or isempty(sigmaDPT):
        sigmaDPT=0.014
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:5
    
    if nargin < 5 or isempty(freqDPT):
        freqDPT=34
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:8
    idxDPT=copy(idxDPTp)
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:9
    cDPT=(idxDPT - 1) / (N - 1)
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:10
    for k in arange(1,numel(cDPT)).reshape(-1):
        u=x - cDPT(k)
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:12
        f=f + multiply(dot(ampDPT,exp(dot(- 0.5,(u / sigmaDPT) ** 2))),cos(dot(dot(dot(2,pi),freqDPT),u)))
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:15
    meta.ID = copy('TF176')
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:16
    meta.Name = copy('Dyadic Phase Twins')
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:17
    meta.Category = copy(9)
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:19
    meta.Parameters = copy(struct('idx',idxDPT,'amp',ampDPT,'sigma',sigmaDPT,'freq',freqDPT))
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:20
    meta.Morphology = copy('Spatially localized phase-shifted cosine twins')
# /tmp/mfuncs/TF176_DyadicPhaseTwins.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    