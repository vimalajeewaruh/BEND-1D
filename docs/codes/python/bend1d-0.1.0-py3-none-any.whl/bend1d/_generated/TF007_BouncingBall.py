# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF007_BouncingBall(N=None,e=None,duration0=None,*args,**kwargs):
    varargin = TF007_BouncingBall.varargin
    nargin = TF007_BouncingBall.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF007_BouncingBall.m:2
    
    if nargin < 2 or isempty(e):
        e=0.72
# /tmp/mfuncs/TF007_BouncingBall.m:3
    
    if nargin < 3 or isempty(duration0):
        duration0=1 - e
# /tmp/mfuncs/TF007_BouncingBall.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF007_BouncingBall.m:5
    f=zeros(size(x))
# /tmp/mfuncs/TF007_BouncingBall.m:6
    left=0
# /tmp/mfuncs/TF007_BouncingBall.m:7
    duration=copy(duration0)
# /tmp/mfuncs/TF007_BouncingBall.m:8
    height=1
# /tmp/mfuncs/TF007_BouncingBall.m:9
    for k in arange(1,30).reshape(-1):
        right=left + duration
# /tmp/mfuncs/TF007_BouncingBall.m:11
        if right > 1:
            right=1
# /tmp/mfuncs/TF007_BouncingBall.m:12
        ind=logical_and((x >= left),(x <= right))
# /tmp/mfuncs/TF007_BouncingBall.m:13
        if right > left:
            u=(x(ind) - left) / (right - left)
# /tmp/mfuncs/TF007_BouncingBall.m:15
            f[ind]=multiply(multiply(dot(4,height),u),(1 - u))
# /tmp/mfuncs/TF007_BouncingBall.m:16
        if right >= 1 - dot(10,eps):
            break
        left=copy(right)
# /tmp/mfuncs/TF007_BouncingBall.m:19
        duration=dot(e,duration)
# /tmp/mfuncs/TF007_BouncingBall.m:20
        height=dot(e ** 2,height)
# /tmp/mfuncs/TF007_BouncingBall.m:21
    
    f[end()]=0
# /tmp/mfuncs/TF007_BouncingBall.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF007_BouncingBall.m:24
    meta.ID = copy('TF007')
# /tmp/mfuncs/TF007_BouncingBall.m:25
    meta.Name = copy('Bouncing Ball')
# /tmp/mfuncs/TF007_BouncingBall.m:26
    meta.Category = copy(6)
# /tmp/mfuncs/TF007_BouncingBall.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF007_BouncingBall.m:28
    meta.Parameters = copy(struct('e',e,'duration0',duration0))
# /tmp/mfuncs/TF007_BouncingBall.m:29
    meta.Morphology = copy('Sequence of decaying ballistic arcs accumulating at 1')
# /tmp/mfuncs/TF007_BouncingBall.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    