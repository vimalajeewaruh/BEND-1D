# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF160_FresnelOccultation(N=None,baseA=None,cFO=None,sgnFO=None,*args,**kwargs):
    varargin = TF160_FresnelOccultation.varargin
    nargin = TF160_FresnelOccultation.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF160_FresnelOccultation.m:2
    
    if nargin < 2 or isempty(baseA):
        baseA=1.0
# /tmp/mfuncs/TF160_FresnelOccultation.m:3
    
    if nargin < 3 or isempty(cFO):
        cFO=concat([0.35,0.68])
# /tmp/mfuncs/TF160_FresnelOccultation.m:4
    
    if nargin < 4 or isempty(sgnFO):
        sgnFO=concat([1,- 1])
# /tmp/mfuncs/TF160_FresnelOccultation.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF160_FresnelOccultation.m:6
    f=baseA - dot(0.82,(S(x,cFO(1),0.004) - S(x,cFO(2),0.004)))
# /tmp/mfuncs/TF160_FresnelOccultation.m:7
    for k in arange(1,numel(cFO)).reshape(-1):
        u=x - cFO(k)
# /tmp/mfuncs/TF160_FresnelOccultation.m:9
        f=f + multiply(dot(dot(sgnFO(k),0.15),exp(dot(- 0.5,(u / 0.052) ** 2))),sin(dot(dot(2,pi),(dot(16,u) + multiply(dot(55,u),abs(u))))))
# /tmp/mfuncs/TF160_FresnelOccultation.m:10
    
    meta=copy(struct)
# /tmp/mfuncs/TF160_FresnelOccultation.m:12
    meta.ID = copy('TF160')
# /tmp/mfuncs/TF160_FresnelOccultation.m:13
    meta.Name = copy('Fresnel Occultation')
# /tmp/mfuncs/TF160_FresnelOccultation.m:14
    meta.Category = copy(9)
# /tmp/mfuncs/TF160_FresnelOccultation.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF160_FresnelOccultation.m:16
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF160_FresnelOccultation.m:17
    meta.Morphology = copy('Occultation step with localized nonlinear oscillations')
# /tmp/mfuncs/TF160_FresnelOccultation.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    