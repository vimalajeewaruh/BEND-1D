# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF163_AuditoryBrainstemResponse(N=None,muABR=None,aABR=None,wABR=None,*args,**kwargs):
    varargin = TF163_AuditoryBrainstemResponse.varargin
    nargin = TF163_AuditoryBrainstemResponse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:2
    
    if nargin < 2 or isempty(muABR):
        muABR=concat([0.18,0.27,0.36,0.47,0.58,0.69,0.79])
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:3
    
    if nargin < 3 or isempty(aABR):
        aABR=concat([0.18,0.15,0.24,0.19,0.31,0.13,0.1])
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:4
    
    if nargin < 4 or isempty(wABR):
        wABR=concat([0.01,0.012,0.011,0.013,0.014,0.015,0.016])
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:6
    f=zeros(size(x))
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:7
    for k in arange(1,numel(muABR)).reshape(-1):
        f=f + dot(aABR(k),exp(dot(- 0.5,((x - muABR(k)) / wABR(k)) ** 2))) - dot(dot(0.52,aABR(k)),exp(dot(- 0.5,((x - (muABR(k) - 0.02)) / (dot(1.15,wABR(k)))) ** 2)))
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:9
    
    f=f + dot(0.03,exp(dot(- 0.5,((x - 0.1) / 0.006) ** 2)))
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:11
    meta=copy(struct)
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:12
    meta.ID = copy('TF163')
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:13
    meta.Name = copy('Auditory Brainstem Response')
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:14
    meta.Category = copy(9)
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:15
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:16
    meta.Parameters = copy(struct('muABR',muABR,'aABR',aABR,'wABR',wABR))
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:17
    meta.Morphology = copy('Sequence of positive peaks each followed by a smaller negative component')
# /tmp/mfuncs/TF163_AuditoryBrainstemResponse.m:18
    return x,f,meta
    
if __name__ == '__main__':
    pass
    