# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF198_ValveChatter(N=None,gain=None,depth=None,*args,**kwargs):
    varargin = TF198_ValveChatter.varargin
    nargin = TF198_ValveChatter.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF198_ValveChatter.m:2
    
    if nargin < 2 or isempty(gain):
        gain=0.48
# /tmp/mfuncs/TF198_ValveChatter.m:3
    
    if nargin < 3 or isempty(depth):
        depth=0.34
# /tmp/mfuncs/TF198_ValveChatter.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF198_ValveChatter.m:5
    gate=S(x,0.3,0.003) - S(x,0.58,0.003)
# /tmp/mfuncs/TF198_ValveChatter.m:6
    chatter=multiply(gate,tanh(dot(2.7,sin(dot(dot(dot(2,pi),47),(x - 0.3))))))
# /tmp/mfuncs/TF198_ValveChatter.m:7
    u=max(x - 0.58,0)
# /tmp/mfuncs/TF198_ValveChatter.m:8
    ring=multiply(multiply(multiply((x >= 0.58),depth),exp(dot(- 18,u))),sin(dot(dot(dot(2,pi),34),u)))
# /tmp/mfuncs/TF198_ValveChatter.m:9
    f=0.12 + dot(0.18,x) + dot(gain,chatter) + ring
# /tmp/mfuncs/TF198_ValveChatter.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF198_ValveChatter.m:11
    meta.ID = copy('TF198')
# /tmp/mfuncs/TF198_ValveChatter.m:12
    meta.Name = copy('Valve Chatter')
# /tmp/mfuncs/TF198_ValveChatter.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF198_ValveChatter.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF198_ValveChatter.m:15
    meta.Parameters = copy(struct('gain',gain,'depth',depth))
# /tmp/mfuncs/TF198_ValveChatter.m:16
    meta.Morphology = copy('Gated chatter with post-event ringing')
# /tmp/mfuncs/TF198_ValveChatter.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    