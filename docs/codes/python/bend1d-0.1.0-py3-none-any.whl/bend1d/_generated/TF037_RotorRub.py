# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF037_RotorRub(N=None,phaseRotor=None,*args,**kwargs):
    varargin = TF037_RotorRub.varargin
    nargin = TF037_RotorRub.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF037_RotorRub.m:2
    
    if nargin < 2 or isempty(phaseRotor):
        x=linspace(0,1,N).T
# /tmp/mfuncs/TF037_RotorRub.m:4
        phaseRotor=dot(dot(2,pi),(dot(7,x) + dot(0.035,sin(dot(dot(dot(2,pi),0.9),x)))))
# /tmp/mfuncs/TF037_RotorRub.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF037_RotorRub.m:7
    
    if isscalar(phaseRotor):
        phaseRotor=repmat(phaseRotor,size(x))
# /tmp/mfuncs/TF037_RotorRub.m:9
    else:
        phaseRotor=interp1(linspace(0,1,numel(phaseRotor)),phaseRotor,x,'linear',phaseRotor(end()))
# /tmp/mfuncs/TF037_RotorRub.m:11
    
    zRotor=sin(phaseRotor) + dot(0.16,sin(dot(2,phaseRotor) - 0.5))
# /tmp/mfuncs/TF037_RotorRub.m:13
    contact=max(zRotor - 0.48,0)
# /tmp/mfuncs/TF037_RotorRub.m:14
    f=zRotor - dot(0.78,contact) + dot(0.09,sin(dot(3,phaseRotor) + 0.3))
# /tmp/mfuncs/TF037_RotorRub.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF037_RotorRub.m:16
    meta.ID = copy('TF037')
# /tmp/mfuncs/TF037_RotorRub.m:17
    meta.Name = copy('Rotor Rub')
# /tmp/mfuncs/TF037_RotorRub.m:18
    meta.Category = copy(3)
# /tmp/mfuncs/TF037_RotorRub.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF037_RotorRub.m:20
    meta.Parameters = copy(struct('phaseRotor',phaseRotor))
# /tmp/mfuncs/TF037_RotorRub.m:21
    meta.Morphology = copy('Periodic rotor motion with nonlinear contact producing harmonics and cusps')
# /tmp/mfuncs/TF037_RotorRub.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
