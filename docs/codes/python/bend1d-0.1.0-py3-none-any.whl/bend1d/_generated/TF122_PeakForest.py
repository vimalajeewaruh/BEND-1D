# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF122_PeakForest(N=None,base=None,centers=None,amps=None,widths=None,*args,**kwargs):
    varargin = TF122_PeakForest.varargin
    nargin = TF122_PeakForest.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF122_PeakForest.m:2
    
    if nargin < 2 or isempty(base):
        base=0.02
# /tmp/mfuncs/TF122_PeakForest.m:3
    
    if nargin < 3 or isempty(centers):
        centers=concat([0.08,0.15,0.24,0.31,0.405,0.47,0.505,0.59,0.69,0.77,0.86,0.93])
# /tmp/mfuncs/TF122_PeakForest.m:4
    
    if nargin < 4 or isempty(amps):
        amps=concat([0.22,- 0.18,0.3,0.5,- 0.25,0.7,0.42,- 0.35,0.55,0.24,- 0.2,0.38])
# /tmp/mfuncs/TF122_PeakForest.m:5
    
    if nargin < 5 or isempty(widths):
        widths=concat([0.03,0.015,0.02,0.01,0.012,0.008,0.006,0.016,0.004,0.01,0.006,0.003])
# /tmp/mfuncs/TF122_PeakForest.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF122_PeakForest.m:8
    f=dot(base,ones(size(x)))
# /tmp/mfuncs/TF122_PeakForest.m:9
    for k in arange(1,numel(centers)).reshape(-1):
        f=f + dot(amps(k),exp(dot(- 0.5,((x - centers(k)) / widths(k)) ** 2)))
# /tmp/mfuncs/TF122_PeakForest.m:11
    
    meta=copy(struct)
# /tmp/mfuncs/TF122_PeakForest.m:13
    meta.ID = copy('TF122')
# /tmp/mfuncs/TF122_PeakForest.m:14
    meta.Name = copy('Peak Forest')
# /tmp/mfuncs/TF122_PeakForest.m:15
    meta.Category = copy(6)
# /tmp/mfuncs/TF122_PeakForest.m:16
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF122_PeakForest.m:17
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF122_PeakForest.m:18
    meta.Morphology = copy('Dense collection of peaks and troughs')
# /tmp/mfuncs/TF122_PeakForest.m:19
    return x,f,meta
    
if __name__ == '__main__':
    pass
    