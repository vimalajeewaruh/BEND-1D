# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF101_QuantumRamseyDrift(N=None,ampDecay=None,phaseA=None,phaseB=None,phaseC=None,jumpC=None,jumpW=None,vis0=None,visSlope=None,*args,**kwargs):
    varargin = TF101_QuantumRamseyDrift.varargin
    nargin = TF101_QuantumRamseyDrift.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:2
    
    if nargin < 2 or isempty(ampDecay):
        ampDecay=0.92
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:3
    
    if nargin < 3 or isempty(phaseA):
        phaseA=10
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:4
    
    if nargin < 4 or isempty(phaseB):
        phaseB=1.8
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:5
    
    if nargin < 5 or isempty(phaseC):
        phaseC=0.1
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:6
    
    if nargin < 6 or isempty(jumpC):
        jumpC=0.64
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:7
    
    if nargin < 7 or isempty(jumpW):
        jumpW=0.004
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:8
    
    if nargin < 8 or isempty(vis0):
        vis0=0.92
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:9
    
    if nargin < 9 or isempty(visSlope):
        visSlope=- 0.28
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:12
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:13
    phaseQR=dot(dot(2,pi),(dot(phaseA,x) + dot(phaseB,x ** 2) + dot(phaseC,sin(dot(dot(dot(2,pi),2),x)))))
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:14
    visQR=vis0 + dot(visSlope,x)
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:15
    jumpQR=dot(0.55,S(x,jumpC,jumpW))
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:16
    f=multiply(visQR,cos(phaseQR + jumpQR))
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:18
    meta.ID = copy('TF101')
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:19
    meta.Name = copy('Quantum Ramsey Drift')
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:23
    meta.Morphology = copy('Drifting phase with visibility decay and phase jump')
# /tmp/mfuncs/TF101_QuantumRamseyDrift.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    