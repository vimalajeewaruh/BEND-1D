# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF130_ShadowedPeaks(N=None,peakCenters=None,peakAmps=None,peakW=None,shadowAmp=None,shadowShift=None,*args,**kwargs):
    varargin = TF130_ShadowedPeaks.varargin
    nargin = TF130_ShadowedPeaks.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF130_ShadowedPeaks.m:2
    
    if nargin < 2 or isempty(peakCenters):
        peakCenters=concat([0.25,0.5,0.75])
# /tmp/mfuncs/TF130_ShadowedPeaks.m:3
    
    if nargin < 3 or isempty(peakAmps):
        peakAmps=concat([0.6,0.9,0.5])
# /tmp/mfuncs/TF130_ShadowedPeaks.m:4
    
    if nargin < 4 or isempty(peakW):
        peakW=0.02
# /tmp/mfuncs/TF130_ShadowedPeaks.m:5
    
    if nargin < 5 or isempty(shadowAmp):
        shadowAmp=- 0.25
# /tmp/mfuncs/TF130_ShadowedPeaks.m:6
    
    if nargin < 6 or isempty(shadowShift):
        shadowShift=0.01
# /tmp/mfuncs/TF130_ShadowedPeaks.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF130_ShadowedPeaks.m:9
    f=zeros(size(x))
# /tmp/mfuncs/TF130_ShadowedPeaks.m:10
    for k in arange(1,numel(peakCenters)).reshape(-1):
        p=dot(peakAmps(k),exp(dot(- 0.5,((x - peakCenters(k)) / peakW) ** 2)))
# /tmp/mfuncs/TF130_ShadowedPeaks.m:12
        s=dot(shadowAmp,exp(dot(- 0.5,(dot((x - (peakCenters(k) + shadowShift)) / peakW,2)) ** 2)))
# /tmp/mfuncs/TF130_ShadowedPeaks.m:13
        f=f + p + s
# /tmp/mfuncs/TF130_ShadowedPeaks.m:14
    
    meta=copy(struct)
# /tmp/mfuncs/TF130_ShadowedPeaks.m:16
    meta.ID = copy('TF130')
# /tmp/mfuncs/TF130_ShadowedPeaks.m:17
    meta.Name = copy('Shadowed Peaks')
# /tmp/mfuncs/TF130_ShadowedPeaks.m:18
    meta.Category = copy(8)
# /tmp/mfuncs/TF130_ShadowedPeaks.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF130_ShadowedPeaks.m:20
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF130_ShadowedPeaks.m:21
    meta.Morphology = copy('Peaks with slight negative shadows offset to one side')
# /tmp/mfuncs/TF130_ShadowedPeaks.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    