# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF005_DiffusionBand(N=None,*args,**kwargs):
    varargin = TF005_DiffusionBand.varargin
    nargin = TF005_DiffusionBand.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF005_DiffusionBand.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF005_DiffusionBand.m:3
    f=dot(0.5,(erf((x - 0.28) / 0.025) - erf((x - 0.72) / 0.07)))
# /tmp/mfuncs/TF005_DiffusionBand.m:4
    meta=copy(struct)
# /tmp/mfuncs/TF005_DiffusionBand.m:5
    meta.ID = copy('TF005')
# /tmp/mfuncs/TF005_DiffusionBand.m:6
    meta.Name = copy('Diffusion Band')
# /tmp/mfuncs/TF005_DiffusionBand.m:7
    meta.Category = copy(4)
# /tmp/mfuncs/TF005_DiffusionBand.m:8
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF005_DiffusionBand.m:9
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF005_DiffusionBand.m:10
    meta.Morphology = copy('Two diffusive fronts of unequal sharpness')
# /tmp/mfuncs/TF005_DiffusionBand.m:11
    return x,f,meta
    
if __name__ == '__main__':
    pass
    