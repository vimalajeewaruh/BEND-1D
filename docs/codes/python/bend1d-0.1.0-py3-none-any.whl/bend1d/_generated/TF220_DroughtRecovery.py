# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF220_DroughtRecovery(N=None,a=None,b=None,c1=None,c2=None,*args,**kwargs):
    varargin = TF220_DroughtRecovery.varargin
    nargin = TF220_DroughtRecovery.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF220_DroughtRecovery.m:2
    
    if nargin < 2 or isempty(a):
        a=1
# /tmp/mfuncs/TF220_DroughtRecovery.m:3
    
    if nargin < 3 or isempty(b):
        b=- 0.62
# /tmp/mfuncs/TF220_DroughtRecovery.m:4
    
    if nargin < 4 or isempty(c1):
        c1=0.78
# /tmp/mfuncs/TF220_DroughtRecovery.m:5
    
    if nargin < 5 or isempty(c2):
        c2=0.92
# /tmp/mfuncs/TF220_DroughtRecovery.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF220_DroughtRecovery.m:7
    f=a + dot(b,x ** 1.35) + dot(0.37,S(x,c1,0.018)) - dot(0.08,S(x,c2,0.03))
# /tmp/mfuncs/TF220_DroughtRecovery.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF220_DroughtRecovery.m:9
    meta.ID = copy('TF220')
# /tmp/mfuncs/TF220_DroughtRecovery.m:10
    meta.Name = copy('Drought Recovery')
# /tmp/mfuncs/TF220_DroughtRecovery.m:11
    meta.Category = copy(12)
# /tmp/mfuncs/TF220_DroughtRecovery.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF220_DroughtRecovery.m:13
    meta.Parameters = copy(struct('a',a,'b',b,'c1',c1,'c2',c2))
# /tmp/mfuncs/TF220_DroughtRecovery.m:14
    meta.Morphology = copy('Long-term decline with late recovery bumps')
# /tmp/mfuncs/TF220_DroughtRecovery.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    