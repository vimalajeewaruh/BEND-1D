# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF170_VanDerPolRelaxation(N=None,*args,**kwargs):
    varargin = TF170_VanDerPolRelaxation.varargin
    nargin = TF170_VanDerPolRelaxation.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:3
    muVDP=7.0
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:4
    dtVDP=20 / (N - 1)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:5
    y1=zeros(1,N)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:6
    y2=zeros(1,N)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:6
    y1[1]=2
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:7
    y2[1]=0
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:7
    rhsVDP=lambda a=None,b=None: concat([[b],[multiply(dot(muVDP,(1 - a ** 2)),b) - a]])
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:8
    for k in arange(1,N - 1).reshape(-1):
        yy=concat([[y1(k)],[y2(k)]])
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:10
        k1=rhsVDP(yy(1),yy(2))
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:11
        q=yy + dot(dot(0.5,dtVDP),k1)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:12
        k2=rhsVDP(q(1),q(2))
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:13
        q=yy + dot(dot(0.5,dtVDP),k2)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:14
        k3=rhsVDP(q(1),q(2))
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:15
        q=yy + dot(dtVDP,k3)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:16
        k4=rhsVDP(q(1),q(2))
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:17
        yn=yy + dot(dtVDP,(k1 + dot(2,k2) + dot(2,k3) + k4)) / 6
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:18
        y1[k + 1]=yn(1)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:19
        y2[k + 1]=yn(2)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:19
    
    f=ravel(y1) / max(abs(y1))
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:21
    meta=copy(struct)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:22
    meta.ID = copy('TF170')
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:23
    meta.Name = copy('Van der Pol Relaxation')
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:24
    meta.Category = copy(9)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:25
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:26
    meta.Parameters = copy(struct('mu',muVDP))
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:27
    meta.Morphology = copy('Nonlinear relaxation oscillator (Van der Pol)')
# /tmp/mfuncs/TF170_VanDerPolRelaxation.m:28
    return x,f,meta
    
if __name__ == '__main__':
    pass
    