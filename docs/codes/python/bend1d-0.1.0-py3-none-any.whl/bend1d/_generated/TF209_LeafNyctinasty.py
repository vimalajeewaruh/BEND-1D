# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF209_LeafNyctinasty(N=None,base=None,c1=None,w1=None,c2=None,w2=None,amp=None,*args,**kwargs):
    varargin = TF209_LeafNyctinasty.varargin
    nargin = TF209_LeafNyctinasty.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF209_LeafNyctinasty.m:2
    
    if nargin < 2 or isempty(base):
        base=0.12
# /tmp/mfuncs/TF209_LeafNyctinasty.m:3
    
    if nargin < 3 or isempty(c1):
        c1=0.08
# /tmp/mfuncs/TF209_LeafNyctinasty.m:4
    
    if nargin < 4 or isempty(w1):
        w1=0.025
# /tmp/mfuncs/TF209_LeafNyctinasty.m:5
    
    if nargin < 5 or isempty(c2):
        c2=0.57
# /tmp/mfuncs/TF209_LeafNyctinasty.m:6
    
    if nargin < 6 or isempty(w2):
        w2=0.022
# /tmp/mfuncs/TF209_LeafNyctinasty.m:7
    
    if nargin < 7 or isempty(amp):
        amp=0.025
# /tmp/mfuncs/TF209_LeafNyctinasty.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF209_LeafNyctinasty.m:9
    f=base + dot(0.78,(S(x,c1,w1) - S(x,0.38,0.05))) + dot(0.72,(S(x,c2,w2) - S(x,0.88,0.06))) + dot(amp,sin(dot(dot(dot(2,pi),5),x)))
# /tmp/mfuncs/TF209_LeafNyctinasty.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF209_LeafNyctinasty.m:14
    meta.ID = copy('TF209')
# /tmp/mfuncs/TF209_LeafNyctinasty.m:15
    meta.Name = copy('Leaf Nyctinasty')
# /tmp/mfuncs/TF209_LeafNyctinasty.m:16
    meta.Category = copy(10)
# /tmp/mfuncs/TF209_LeafNyctinasty.m:17
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF209_LeafNyctinasty.m:18
    meta.Parameters = copy(struct('base',base,'c1',c1,'w1',w1,'c2',c2,'w2',w2,'amp',amp))
# /tmp/mfuncs/TF209_LeafNyctinasty.m:19
    meta.Morphology = copy('Day-night leaf movement with periodic modulation')
# /tmp/mfuncs/TF209_LeafNyctinasty.m:20
    return x,f,meta
    
if __name__ == '__main__':
    pass
    