# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF063_NMRMultiplet(N=None,baseline_amp=None,baseline_slope=None,pkC_NMR=None,pkA_NMR=None,pkG_NMR=None,*args,**kwargs):
    varargin = TF063_NMRMultiplet.varargin
    nargin = TF063_NMRMultiplet.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF063_NMRMultiplet.m:2
    
    if nargin < 2 or isempty(baseline_amp):
        baseline_amp=0.025
# /tmp/mfuncs/TF063_NMRMultiplet.m:3
    
    if nargin < 3 or isempty(baseline_slope):
        baseline_slope=0.01
# /tmp/mfuncs/TF063_NMRMultiplet.m:4
    
    if nargin < 4 or isempty(pkC_NMR):
        pkC_NMR=concat([0.16,0.31,0.455,0.486,0.515,0.545,0.73,0.865])
# /tmp/mfuncs/TF063_NMRMultiplet.m:5
    
    if nargin < 5 or isempty(pkA_NMR):
        pkA_NMR=concat([0.34,0.58,0.52,0.82,1.0,0.67,0.44,0.25])
# /tmp/mfuncs/TF063_NMRMultiplet.m:6
    
    if nargin < 6 or isempty(pkG_NMR):
        pkG_NMR=concat([0.008,0.011,0.007,0.006,0.006,0.007,0.012,0.009])
# /tmp/mfuncs/TF063_NMRMultiplet.m:7
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF063_NMRMultiplet.m:9
    f=baseline_amp + dot(baseline_slope,x)
# /tmp/mfuncs/TF063_NMRMultiplet.m:10
    for k in arange(1,numel(pkC_NMR)).reshape(-1):
        z=(x - pkC_NMR(k)) / pkG_NMR(k)
# /tmp/mfuncs/TF063_NMRMultiplet.m:12
        f=f + pkA_NMR(k) / (1 + z ** 2)
# /tmp/mfuncs/TF063_NMRMultiplet.m:13
    
    zBroad=(x - 0.505) / 0.055
# /tmp/mfuncs/TF063_NMRMultiplet.m:15
    f=f + 0.075 / (1 + zBroad ** 2)
# /tmp/mfuncs/TF063_NMRMultiplet.m:16
    meta=copy(struct)
# /tmp/mfuncs/TF063_NMRMultiplet.m:17
    meta.ID = copy('TF063')
# /tmp/mfuncs/TF063_NMRMultiplet.m:18
    meta.Name = copy('NMR Multiplet')
# /tmp/mfuncs/TF063_NMRMultiplet.m:19
    meta.Category = copy(5)
# /tmp/mfuncs/TF063_NMRMultiplet.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF063_NMRMultiplet.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF063_NMRMultiplet.m:22
    meta.Morphology = copy('Lorentzian resonances with a partially resolved central multiplet')
# /tmp/mfuncs/TF063_NMRMultiplet.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    