# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF027_NasonPlethysmography(N=None,scriptFolder=None,phaseRespCoef=None,wDistMu=None,wDistSigma=None,*args,**kwargs):
    varargin = TF027_NasonPlethysmography.varargin
    nargin = TF027_NasonPlethysmography.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF027_NasonPlethysmography.m:2
    
    if nargin < 2:
        scriptFolder=''
# /tmp/mfuncs/TF027_NasonPlethysmography.m:3
    
    if nargin < 3 or isempty(phaseRespCoef):
        phaseRespCoef=struct('a',10.5,'b',0.2,'c',0.75)
# /tmp/mfuncs/TF027_NasonPlethysmography.m:4
    
    if nargin < 4 or isempty(wDistMu):
        wDistMu=0.51
# /tmp/mfuncs/TF027_NasonPlethysmography.m:5
    
    if nargin < 5 or isempty(wDistSigma):
        wDistSigma=0.105
# /tmp/mfuncs/TF027_NasonPlethysmography.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF027_NasonPlethysmography.m:7
    ipdFile=fullfile(scriptFolder,'ipd.csv')
# /tmp/mfuncs/TF027_NasonPlethysmography.m:8
    usedExactNasonIPD=False
# /tmp/mfuncs/TF027_NasonPlethysmography.m:9
    if exist(ipdFile,'file') == 2:
        z=readmatrix(ipdFile)
# /tmp/mfuncs/TF027_NasonPlethysmography.m:11
        if logical_not(isempty(z)):
            z=z(arange(),end())
# /tmp/mfuncs/TF027_NasonPlethysmography.m:13
            z=z(isfinite(z))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:14
            if numel(z) >= 16:
                xx=linspace(0,1,numel(z))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:16
                f=interp1(xx,ravel(z).T,x,'pchip')
# /tmp/mfuncs/TF027_NasonPlethysmography.m:17
                usedExactNasonIPD=copy(true)
# /tmp/mfuncs/TF027_NasonPlethysmography.m:18
    
    if logical_not(usedExactNasonIPD):
        phaseResp=dot(dot(2,pi),(dot(phaseRespCoef.a,x) + dot(phaseRespCoef.b,sin(dot(dot(dot(2,pi),phaseRespCoef.c),x)))))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:23
        normalResp=multiply((0.92 + dot(0.1,sin(dot(dot(dot(2,pi),0.55),x)))),(sin(phaseResp) + dot(0.18,sin(dot(2,phaseResp) - 0.45))))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:24
        wDist=exp(dot(- 0.5,((x - wDistMu) / wDistSigma) ** 2))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:25
        disturb=multiply(dot(0.48,wDist),sin(dot(dot(2,pi),(dot(4.1,x) + dot(1.6,x ** 2))) + 0.6)) + multiply(dot(0.25,wDist),sin(dot(dot(dot(2,pi),31),x))) + multiply(dot(0.14,wDist),sin(dot(dot(dot(2,pi),53),x) + 0.8))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:26
        f=multiply((1 - dot(0.88,wDist)),normalResp) + disturb
# /tmp/mfuncs/TF027_NasonPlethysmography.m:27
    
    meta=copy(struct)
# /tmp/mfuncs/TF027_NasonPlethysmography.m:29
    meta.ID = copy('TF027')
# /tmp/mfuncs/TF027_NasonPlethysmography.m:30
    meta.Name = copy('Nason Plethysmography')
# /tmp/mfuncs/TF027_NasonPlethysmography.m:31
    meta.Category = copy(3)
# /tmp/mfuncs/TF027_NasonPlethysmography.m:32
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF027_NasonPlethysmography.m:33
    meta.Parameters = copy(struct('usedExactIPD',usedExactNasonIPD,'ipdFile',ipdFile,'phaseRespCoef',phaseRespCoef,'wDistMu',wDistMu,'wDistSigma',wDistSigma))
# /tmp/mfuncs/TF027_NasonPlethysmography.m:34
    meta.Morphology = copy('Respiratory oscillation with central disturbance or exact plethysmogram if provided')
# /tmp/mfuncs/TF027_NasonPlethysmography.m:35
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
