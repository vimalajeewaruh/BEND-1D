# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF064_XRDPeaks(N=None,background_amp=None,background_decay=None,hump_amp=None,hump_ctr=None,hump_w=None,pkC=None,pkA=None,pkW=None,*args,**kwargs):
    varargin = TF064_XRDPeaks.varargin
    nargin = TF064_XRDPeaks.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF064_XRDPeaks.m:2
    
    if nargin < 2 or isempty(background_amp):
        background_amp=0.1
# /tmp/mfuncs/TF064_XRDPeaks.m:3
    
    if nargin < 3 or isempty(background_decay):
        background_decay=2.8
# /tmp/mfuncs/TF064_XRDPeaks.m:4
    
    if nargin < 4 or isempty(hump_amp):
        hump_amp=0.075
# /tmp/mfuncs/TF064_XRDPeaks.m:5
    
    if nargin < 5 or isempty(hump_ctr):
        hump_ctr=0.29
# /tmp/mfuncs/TF064_XRDPeaks.m:6
    
    if nargin < 6 or isempty(hump_w):
        hump_w=0.095
# /tmp/mfuncs/TF064_XRDPeaks.m:7
    
    if nargin < 7 or isempty(pkC):
        pkC=concat([0.18,0.355,0.475,0.565,0.582,0.745,0.89])
# /tmp/mfuncs/TF064_XRDPeaks.m:8
    
    if nargin < 8 or isempty(pkA):
        pkA=concat([0.34,0.62,0.43,0.92,0.7,0.52,0.27])
# /tmp/mfuncs/TF064_XRDPeaks.m:9
    
    if nargin < 9 or isempty(pkW):
        pkW=concat([0.01,0.008,0.012,0.007,0.0075,0.01,0.006])
# /tmp/mfuncs/TF064_XRDPeaks.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF064_XRDPeaks.m:12
    backgroundXRD=background_amp + dot(0.12,exp(dot(- background_decay,x))) + dot(hump_amp,exp(dot(- 0.5,((x - hump_ctr) / hump_w) ** 2)))
# /tmp/mfuncs/TF064_XRDPeaks.m:13
    f=copy(backgroundXRD)
# /tmp/mfuncs/TF064_XRDPeaks.m:14
    for k in arange(1,numel(pkC)).reshape(-1):
        f=f + dot(pkA(k),exp(dot(- 0.5,((x - pkC(k)) / pkW(k)) ** 2)))
# /tmp/mfuncs/TF064_XRDPeaks.m:16
    
    meta=copy(struct)
# /tmp/mfuncs/TF064_XRDPeaks.m:18
    meta.ID = copy('TF064')
# /tmp/mfuncs/TF064_XRDPeaks.m:19
    meta.Name = copy('X-ray Diffraction Peaks')
# /tmp/mfuncs/TF064_XRDPeaks.m:20
    meta.Category = copy(6)
# /tmp/mfuncs/TF064_XRDPeaks.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF064_XRDPeaks.m:22
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF064_XRDPeaks.m:23
    meta.Morphology = copy('Decaying background, broad hump, sharp Bragg peaks with a close doublet')
# /tmp/mfuncs/TF064_XRDPeaks.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    