# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF070_WellLog(N=None,base_a=None,base_b=None,base_osc=None,step1_a=None,step1_ctr=None,step1_w=None,step2_a=None,step2_ctr=None,step2_w=None,step3_a=None,step3_ctr=None,step3_w=None,step4_a=None,step4_ctr=None,step4_w=None,thin_a=None,thin_ctr1=None,thin_ctr2=None,thin_w=None,highfreq_a=None,highfreq_freq=None,highfreq_mask_lo=None,highfreq_mask_hi=None,*args,**kwargs):
    varargin = TF070_WellLog.varargin
    nargin = TF070_WellLog.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF070_WellLog.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=0.48
# /tmp/mfuncs/TF070_WellLog.m:3
    
    if nargin < 3 or isempty(base_b):
        base_b=0.1
# /tmp/mfuncs/TF070_WellLog.m:4
    
    if nargin < 4 or isempty(base_osc):
        base_osc=0.025
# /tmp/mfuncs/TF070_WellLog.m:5
    
    if nargin < 5 or isempty(step1_a):
        step1_a=0.3
# /tmp/mfuncs/TF070_WellLog.m:6
    
    if nargin < 6 or isempty(step1_ctr):
        step1_ctr=0.18
# /tmp/mfuncs/TF070_WellLog.m:7
    
    if nargin < 7 or isempty(step1_w):
        step1_w=0.004
# /tmp/mfuncs/TF070_WellLog.m:8
    
    if nargin < 8 or isempty(step2_a):
        step2_a=- 0.4
# /tmp/mfuncs/TF070_WellLog.m:9
    
    if nargin < 9 or isempty(step2_ctr):
        step2_ctr=0.39
# /tmp/mfuncs/TF070_WellLog.m:10
    
    if nargin < 10 or isempty(step2_w):
        step2_w=0.005
# /tmp/mfuncs/TF070_WellLog.m:11
    
    if nargin < 11 or isempty(step3_a):
        step3_a=0.26
# /tmp/mfuncs/TF070_WellLog.m:12
    
    if nargin < 12 or isempty(step3_ctr):
        step3_ctr=0.64
# /tmp/mfuncs/TF070_WellLog.m:13
    
    if nargin < 13 or isempty(step3_w):
        step3_w=0.0045
# /tmp/mfuncs/TF070_WellLog.m:14
    
    if nargin < 14 or isempty(step4_a):
        step4_a=- 0.2
# /tmp/mfuncs/TF070_WellLog.m:15
    
    if nargin < 15 or isempty(step4_ctr):
        step4_ctr=0.82
# /tmp/mfuncs/TF070_WellLog.m:16
    
    if nargin < 16 or isempty(step4_w):
        step4_w=0.004
# /tmp/mfuncs/TF070_WellLog.m:17
    
    if nargin < 17 or isempty(thin_a):
        thin_a=0.24
# /tmp/mfuncs/TF070_WellLog.m:18
    
    if nargin < 18 or isempty(thin_ctr1):
        thin_ctr1=0.515
# /tmp/mfuncs/TF070_WellLog.m:19
    
    if nargin < 19 or isempty(thin_ctr2):
        thin_ctr2=0.548
# /tmp/mfuncs/TF070_WellLog.m:20
    
    if nargin < 20 or isempty(thin_w):
        thin_w=0.0028
# /tmp/mfuncs/TF070_WellLog.m:21
    
    if nargin < 21 or isempty(highfreq_a):
        highfreq_a=0.02
# /tmp/mfuncs/TF070_WellLog.m:22
    
    if nargin < 22 or isempty(highfreq_freq):
        highfreq_freq=17
# /tmp/mfuncs/TF070_WellLog.m:23
    
    if nargin < 23 or isempty(highfreq_mask_lo):
        highfreq_mask_lo=0.18
# /tmp/mfuncs/TF070_WellLog.m:24
    
    if nargin < 24 or isempty(highfreq_mask_hi):
        highfreq_mask_hi=0.82
# /tmp/mfuncs/TF070_WellLog.m:25
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF070_WellLog.m:27
    s=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF070_WellLog.m:28
    f=base_a + dot(base_b,x) + dot(base_osc,sin(dot(dot(dot(2,pi),3),x)))
# /tmp/mfuncs/TF070_WellLog.m:29
    f=f + dot(step1_a,s(x,step1_ctr,step1_w)) + dot(step2_a,s(x,step2_ctr,step2_w)) + dot(step3_a,s(x,step3_ctr,step3_w)) + dot(step4_a,s(x,step4_ctr,step4_w))
# /tmp/mfuncs/TF070_WellLog.m:30
    thinBed=dot(thin_a,(s(x,thin_ctr1,thin_w) - s(x,thin_ctr2,thin_w)))
# /tmp/mfuncs/TF070_WellLog.m:31
    f=f + thinBed + multiply(dot(highfreq_a,sin(dot(dot(dot(2,pi),highfreq_freq),x))),(logical_and((x > highfreq_mask_lo),(x < highfreq_mask_hi))))
# /tmp/mfuncs/TF070_WellLog.m:32
    meta=copy(struct)
# /tmp/mfuncs/TF070_WellLog.m:33
    meta.ID = copy('TF070')
# /tmp/mfuncs/TF070_WellLog.m:34
    meta.Name = copy('Geophysical Well Log')
# /tmp/mfuncs/TF070_WellLog.m:35
    meta.Category = copy(6)
# /tmp/mfuncs/TF070_WellLog.m:36
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF070_WellLog.m:37
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF070_WellLog.m:38
    meta.Morphology = copy('Stratigraphic shifts, within-layer variation, and a thin bed')
# /tmp/mfuncs/TF070_WellLog.m:39
    return x,f,meta
    
if __name__ == '__main__':
    pass
    
    ## Category 6 : 71 - 100
    