# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF052_StellarTransitFlare(N=None,base_a=None,base_f1=None,base_f2=None,transit_a=None,transit_ctr=None,transit_w=None,flare_a=None,flare_ctr=None,flare_rise=None,flare_decay=None,*args,**kwargs):
    varargin = TF052_StellarTransitFlare.varargin
    nargin = TF052_StellarTransitFlare.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF052_StellarTransitFlare.m:2
    
    if nargin < 2 or isempty(base_a):
        base_a=1
# /tmp/mfuncs/TF052_StellarTransitFlare.m:3
    
    if nargin < 3 or isempty(base_f1):
        base_f1=0.018
# /tmp/mfuncs/TF052_StellarTransitFlare.m:4
    
    if nargin < 4 or isempty(base_f2):
        base_f2=0.008
# /tmp/mfuncs/TF052_StellarTransitFlare.m:5
    
    if nargin < 5 or isempty(transit_a):
        transit_a=- 0.08
# /tmp/mfuncs/TF052_StellarTransitFlare.m:6
    
    if nargin < 6 or isempty(transit_ctr):
        transit_ctr=0.39
# /tmp/mfuncs/TF052_StellarTransitFlare.m:7
    
    if nargin < 7 or isempty(transit_w):
        transit_w=0.037
# /tmp/mfuncs/TF052_StellarTransitFlare.m:8
    
    if nargin < 8 or isempty(flare_a):
        flare_a=0.19
# /tmp/mfuncs/TF052_StellarTransitFlare.m:9
    
    if nargin < 9 or isempty(flare_ctr):
        flare_ctr=0.69
# /tmp/mfuncs/TF052_StellarTransitFlare.m:10
    
    if nargin < 10 or isempty(flare_rise):
        flare_rise=150
# /tmp/mfuncs/TF052_StellarTransitFlare.m:11
    
    if nargin < 11 or isempty(flare_decay):
        flare_decay=18
# /tmp/mfuncs/TF052_StellarTransitFlare.m:12
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF052_StellarTransitFlare.m:14
    stellarBase=base_a + dot(base_f1,sin(dot(dot(dot(2,pi),3),x))) + dot(base_f2,sin(dot(dot(dot(2,pi),11),x) + 0.4))
# /tmp/mfuncs/TF052_StellarTransitFlare.m:15
    transit=dot(transit_a,exp(- ((x - transit_ctr) / transit_w) ** 8))
# /tmp/mfuncs/TF052_StellarTransitFlare.m:16
    uFlare=max(x - flare_ctr,0)
# /tmp/mfuncs/TF052_StellarTransitFlare.m:17
    flare=multiply(multiply(multiply((x >= flare_ctr),flare_a),(1 - exp(dot(- flare_rise,uFlare)))),exp(dot(- flare_decay,uFlare)))
# /tmp/mfuncs/TF052_StellarTransitFlare.m:18
    f=stellarBase + transit + flare
# /tmp/mfuncs/TF052_StellarTransitFlare.m:19
    meta=copy(struct)
# /tmp/mfuncs/TF052_StellarTransitFlare.m:20
    meta.ID = copy('TF052')
# /tmp/mfuncs/TF052_StellarTransitFlare.m:21
    meta.Name = copy('Stellar Transit + Flare')
# /tmp/mfuncs/TF052_StellarTransitFlare.m:22
    meta.Category = copy(4)
# /tmp/mfuncs/TF052_StellarTransitFlare.m:23
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF052_StellarTransitFlare.m:24
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF052_StellarTransitFlare.m:25
    meta.Morphology = copy('Transit dip followed by rapid flare and slow decay')
# /tmp/mfuncs/TF052_StellarTransitFlare.m:26
    return x,f,meta
    
if __name__ == '__main__':
    pass
    