# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF109_SemiconductorMetrology(N=None,base=None,slope=None,amp1=None,freq1=None,amp2=None,freq2=None,stepC=None,stepW=None,defC=None,defW=None,defAmp=None,*args,**kwargs):
    varargin = TF109_SemiconductorMetrology.varargin
    nargin = TF109_SemiconductorMetrology.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:2
    
    if nargin < 2 or isempty(base):
        base=0.62
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:3
    
    if nargin < 3 or isempty(slope):
        slope=0.11
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:4
    
    if nargin < 4 or isempty(amp1):
        amp1=0.035
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:5
    
    if nargin < 5 or isempty(freq1):
        freq1=9
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:6
    
    if nargin < 6 or isempty(amp2):
        amp2=0.018
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:7
    
    if nargin < 7 or isempty(freq2):
        freq2=31
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:8
    
    if nargin < 8 or isempty(stepC):
        stepC=0.58
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:9
    
    if nargin < 9 or isempty(stepW):
        stepW=0.004
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:10
    
    if nargin < 10 or isempty(defC):
        defC=0.76
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:11
    
    if nargin < 11 or isempty(defW):
        defW=0.01
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:12
    
    if nargin < 12 or isempty(defAmp):
        defAmp=0.12
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:15
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:16
    f=base + dot(slope,x) + dot(amp1,sin(dot(dot(dot(2,pi),freq1),x))) + dot(amp2,sin(dot(dot(dot(2,pi),freq2),x)))
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:17
    f=f - dot(0.08,S(x,stepC,stepW)) + dot(defAmp,exp(dot(- 0.5,((x - defC) / defW) ** 2)))
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:18
    meta=copy(struct)
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:19
    meta.ID = copy('TF109')
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:20
    meta.Name = copy('Semiconductor Metrology')
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:21
    meta.Category = copy(6)
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:22
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:23
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:24
    meta.Morphology = copy('Trend with multi-scale oscillations and localized defect')
# /tmp/mfuncs/TF109_SemiconductorMetrology.m:25
    return x,f,meta
    
if __name__ == '__main__':
    pass
    