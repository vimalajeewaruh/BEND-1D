# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF006_Fano(N=None,q=None,*args,**kwargs):
    varargin = TF006_Fano.varargin
    nargin = TF006_Fano.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF006_Fano.m:2
    
    if nargin < 2 or isempty(q):
        q=1.5
# /tmp/mfuncs/TF006_Fano.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF006_Fano.m:4
    epsF=(x - 0.58) / 0.025
# /tmp/mfuncs/TF006_Fano.m:5
    f=dot(0.35,exp(- ((x - 0.26) / 0.12) ** 2)) + dot(0.75,((q + epsF) ** 2.0 / (1 + epsF ** 2) - 1))
# /tmp/mfuncs/TF006_Fano.m:6
    meta=copy(struct)
# /tmp/mfuncs/TF006_Fano.m:7
    meta.ID = copy('TF006')
# /tmp/mfuncs/TF006_Fano.m:8
    meta.Name = copy('Fano')
# /tmp/mfuncs/TF006_Fano.m:9
    meta.Category = copy(5)
# /tmp/mfuncs/TF006_Fano.m:10
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF006_Fano.m:11
    meta.Parameters = copy(struct('q',q))
# /tmp/mfuncs/TF006_Fano.m:12
    meta.Morphology = copy('Broad background plus asymmetric resonance')
# /tmp/mfuncs/TF006_Fano.m:13
    return x,f,meta
    
if __name__ == '__main__':
    pass
    