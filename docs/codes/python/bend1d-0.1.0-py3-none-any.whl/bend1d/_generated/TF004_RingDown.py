# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF004_RingDown(N=None,x0=None,alpha=None,nu=None,*args,**kwargs):
    varargin = TF004_RingDown.varargin
    nargin = TF004_RingDown.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF004_RingDown.m:2
    
    if nargin < 2 or isempty(x0):
        x0=0.28
# /tmp/mfuncs/TF004_RingDown.m:3
    
    if nargin < 3 or isempty(alpha):
        alpha=7
# /tmp/mfuncs/TF004_RingDown.m:4
    
    if nargin < 4 or isempty(nu):
        nu=16
# /tmp/mfuncs/TF004_RingDown.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF004_RingDown.m:6
    u=max(x - x0,0)
# /tmp/mfuncs/TF004_RingDown.m:7
    f=multiply(multiply((x >= x0),exp(multiply(- alpha,u))),sin(multiply(dot(dot(2,pi),nu),u)))
# /tmp/mfuncs/TF004_RingDown.m:8
    meta=copy(struct)
# /tmp/mfuncs/TF004_RingDown.m:9
    meta.ID = copy('TF004')
# /tmp/mfuncs/TF004_RingDown.m:10
    meta.Name = copy('Ring-Down')
# /tmp/mfuncs/TF004_RingDown.m:11
    meta.Category = copy(3)
# /tmp/mfuncs/TF004_RingDown.m:12
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF004_RingDown.m:13
    meta.Parameters = copy(struct('x0',x0,'alpha',alpha,'nu',nu))
# /tmp/mfuncs/TF004_RingDown.m:14
    meta.Morphology = copy('Damped resonant transient')
# /tmp/mfuncs/TF004_RingDown.m:15
    return x,f,meta
    
if __name__ == '__main__':
    pass
    