# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF190_CriticalSlowing(N=None,*args,**kwargs):
    varargin = TF190_CriticalSlowing.varargin
    nargin = TF190_CriticalSlowing.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF190_CriticalSlowing.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF190_CriticalSlowing.m:3
    f=0.1 + dot(0.04,x)
# /tmp/mfuncs/TF190_CriticalSlowing.m:4
    c=concat([0.16,0.38,0.6])
# /tmp/mfuncs/TF190_CriticalSlowing.m:5
    a=concat([0.35,0.33,0.3])
# /tmp/mfuncs/TF190_CriticalSlowing.m:5
    tau=concat([0.025,0.06,0.12])
# /tmp/mfuncs/TF190_CriticalSlowing.m:5
    for k in arange(1,3).reshape(-1):
        u=max(x - c(k),0)
# /tmp/mfuncs/TF190_CriticalSlowing.m:7
        f=f + multiply(multiply((x >= c(k)),a(k)),exp(- u / tau(k)))
# /tmp/mfuncs/TF190_CriticalSlowing.m:8
    
    f=f - dot(0.48,S(x,0.83,0.006)) + dot(0.2,S(x,0.89,0.025))
# /tmp/mfuncs/TF190_CriticalSlowing.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF190_CriticalSlowing.m:11
    meta.ID = copy('TF190')
# /tmp/mfuncs/TF190_CriticalSlowing.m:12
    meta.Name = copy('Critical Slowing')
# /tmp/mfuncs/TF190_CriticalSlowing.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF190_CriticalSlowing.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF190_CriticalSlowing.m:15
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF190_CriticalSlowing.m:16
    meta.Morphology = copy('Step-like activations with slow relaxations')
# /tmp/mfuncs/TF190_CriticalSlowing.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    