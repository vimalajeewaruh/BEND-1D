# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF028_VasospasmTCD(N=None,phaseTCDcoef=None,onsetGain=None,*args,**kwargs):
    varargin = TF028_VasospasmTCD.varargin
    nargin = TF028_VasospasmTCD.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF028_VasospasmTCD.m:2
    
    if nargin < 2 or isempty(phaseTCDcoef):
        phaseTCDcoef=struct('a',9.0,'b',0.06,'c',0.8)
# /tmp/mfuncs/TF028_VasospasmTCD.m:3
    
    if nargin < 3 or isempty(onsetGain):
        onsetGain=struct('k',65,'xc',0.56,'scale',0.48)
# /tmp/mfuncs/TF028_VasospasmTCD.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF028_VasospasmTCD.m:5
    phaseTCD=dot(dot(2,pi),(dot(phaseTCDcoef.a,x) + dot(phaseTCDcoef.b,sin(dot(dot(dot(2,pi),phaseTCDcoef.c),x)))))
# /tmp/mfuncs/TF028_VasospasmTCD.m:6
    pulseTCD=dot(0.55,sin(phaseTCD)) + dot(0.23,sin(dot(2,phaseTCD) - 0.55)) + dot(0.1,sin(dot(3,phaseTCD) - 1.0))
# /tmp/mfuncs/TF028_VasospasmTCD.m:7
    onsetVS=1.0 / (1 + exp(dot(- onsetGain.k,(x - onsetGain.xc))))
# /tmp/mfuncs/TF028_VasospasmTCD.m:8
    f=0.35 + dot(0.18,pulseTCD) + multiply(onsetVS,(onsetGain.scale + dot(0.18,pulseTCD))) + dot(0.035,sin(dot(dot(dot(2,pi),1.1),x)))
# /tmp/mfuncs/TF028_VasospasmTCD.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF028_VasospasmTCD.m:10
    meta.ID = copy('TF028')
# /tmp/mfuncs/TF028_VasospasmTCD.m:11
    meta.Name = copy('Vasospasm TCD')
# /tmp/mfuncs/TF028_VasospasmTCD.m:12
    meta.Category = copy(3)
# /tmp/mfuncs/TF028_VasospasmTCD.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF028_VasospasmTCD.m:14
    meta.Parameters = copy(struct('phaseTCDcoef',phaseTCDcoef,'onsetGain',onsetGain))
# /tmp/mfuncs/TF028_VasospasmTCD.m:15
    meta.Morphology = copy('TCD velocity with smooth pathological onset increasing mean and pulsatility')
# /tmp/mfuncs/TF028_VasospasmTCD.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    