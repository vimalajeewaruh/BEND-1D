# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF035_BearingFault(N=None,baseTimes=None,*args,**kwargs):
    varargin = TF035_BearingFault.varargin
    nargin = TF035_BearingFault.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF035_BearingFault.m:2
    
    if nargin < 2 or isempty(baseTimes):
        baseTimes=arange(0.075,0.97,0.112)
# /tmp/mfuncs/TF035_BearingFault.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF035_BearingFault.m:4
    f=zeros(size(x))
# /tmp/mfuncs/TF035_BearingFault.m:5
    for k in arange(1,numel(baseTimes)).reshape(-1):
        tk=baseTimes(k) + dot(0.0045,sin(dot(dot(2,pi),(k - 1)) / 5))
# /tmp/mfuncs/TF035_BearingFault.m:7
        u=x - tk
# /tmp/mfuncs/TF035_BearingFault.m:8
        ind=u >= 0
# /tmp/mfuncs/TF035_BearingFault.m:9
        impact=dot(0.65,exp(dot(- 0.5,(u / 0.0035) ** 2)))
# /tmp/mfuncs/TF035_BearingFault.m:10
        ring=zeros(size(x))
# /tmp/mfuncs/TF035_BearingFault.m:11
        ring[ind]=multiply(exp(dot(- 48,u(ind))),(sin(dot(dot(dot(2,pi),58),u(ind))) + dot(0.32,sin(dot(dot(dot(2,pi),103),u(ind))))))
# /tmp/mfuncs/TF035_BearingFault.m:12
        f=f + impact + ring
# /tmp/mfuncs/TF035_BearingFault.m:13
    
    meta=copy(struct)
# /tmp/mfuncs/TF035_BearingFault.m:15
    meta.ID = copy('TF035')
# /tmp/mfuncs/TF035_BearingFault.m:16
    meta.Name = copy('Bearing Fault')
# /tmp/mfuncs/TF035_BearingFault.m:17
    meta.Category = copy(3)
# /tmp/mfuncs/TF035_BearingFault.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF035_BearingFault.m:19
    meta.Parameters = copy(struct('baseTimes',baseTimes))
# /tmp/mfuncs/TF035_BearingFault.m:20
    meta.Morphology = copy('Localized defect producing impacts and damped high-frequency resonance')
# /tmp/mfuncs/TF035_BearingFault.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    