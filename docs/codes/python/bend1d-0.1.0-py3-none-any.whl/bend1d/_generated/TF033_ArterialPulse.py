# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF033_ArterialPulse(N=None,pulseCenters=None,*args,**kwargs):
    varargin = TF033_ArterialPulse.varargin
    nargin = TF033_ArterialPulse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF033_ArterialPulse.m:2
    
    if nargin < 2 or isempty(pulseCenters):
        pulseCenters=arange(0.07,0.99,0.115)
# /tmp/mfuncs/TF033_ArterialPulse.m:3
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF033_ArterialPulse.m:4
    f=zeros(size(x))
# /tmp/mfuncs/TF033_ArterialPulse.m:5
    for k in arange(1,numel(pulseCenters)).reshape(-1):
        c=pulseCenters(k)
# /tmp/mfuncs/TF033_ArterialPulse.m:7
        ak=0.92 + dot(0.08,sin(dot(dot(2,pi),(k - 1)) / numel(pulseCenters)))
# /tmp/mfuncs/TF033_ArterialPulse.m:8
        systolic=dot(1.05,exp(dot(- 0.5,((x - c) / 0.01) ** 2)))
# /tmp/mfuncs/TF033_ArterialPulse.m:9
        shoulder=dot(0.48,exp(dot(- 0.5,((x - (c + 0.022)) / 0.02) ** 2)))
# /tmp/mfuncs/TF033_ArterialPulse.m:10
        notch=dot(0.23,exp(dot(- 0.5,((x - (c + 0.039)) / 0.006) ** 2)))
# /tmp/mfuncs/TF033_ArterialPulse.m:11
        reflect=dot(0.2,exp(dot(- 0.5,((x - (c + 0.056)) / 0.016) ** 2)))
# /tmp/mfuncs/TF033_ArterialPulse.m:12
        f=f + dot(ak,(systolic + shoulder - notch + reflect))
# /tmp/mfuncs/TF033_ArterialPulse.m:13
    
    f=f + 0.08
# /tmp/mfuncs/TF033_ArterialPulse.m:15
    meta=copy(struct)
# /tmp/mfuncs/TF033_ArterialPulse.m:16
    meta.ID = copy('TF033')
# /tmp/mfuncs/TF033_ArterialPulse.m:17
    meta.Name = copy('Arterial Pulse')
# /tmp/mfuncs/TF033_ArterialPulse.m:18
    meta.Category = copy(3)
# /tmp/mfuncs/TF033_ArterialPulse.m:19
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF033_ArterialPulse.m:20
    meta.Parameters = copy(struct('pulseCenters',pulseCenters))
# /tmp/mfuncs/TF033_ArterialPulse.m:21
    meta.Morphology = copy('Repeated asymmetric arterial-pressure pulses with dicrotic notch and reflected wave')
# /tmp/mfuncs/TF033_ArterialPulse.m:22
    return x,f,meta
    
if __name__ == '__main__':
    pass
    