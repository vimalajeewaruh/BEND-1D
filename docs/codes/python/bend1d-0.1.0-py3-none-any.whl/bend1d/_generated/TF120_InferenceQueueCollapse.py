# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF120_InferenceQueueCollapse(N=None,base=None,slope=None,stepAmp=None,stepC1=None,stepW1=None,stepAmp2=None,stepC2=None,stepW2=None,burstAmp=None,burstDecay=None,burstFreq=None,*args,**kwargs):
    varargin = TF120_InferenceQueueCollapse.varargin
    nargin = TF120_InferenceQueueCollapse.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:2
    
    if nargin < 2 or isempty(base):
        base=0.12
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:3
    
    if nargin < 3 or isempty(slope):
        slope=0.22
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:4
    
    if nargin < 4 or isempty(stepAmp):
        stepAmp=0.55
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:5
    
    if nargin < 5 or isempty(stepC1):
        stepC1=0.5
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:6
    
    if nargin < 6 or isempty(stepW1):
        stepW1=0.018
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:7
    
    if nargin < 7 or isempty(stepAmp2):
        stepAmp2=0.35
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:8
    
    if nargin < 8 or isempty(stepC2):
        stepC2=0.72
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:9
    
    if nargin < 9 or isempty(stepW2):
        stepW2=0.025
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:10
    
    if nargin < 10 or isempty(burstAmp):
        burstAmp=0.12
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:11
    
    if nargin < 11 or isempty(burstDecay):
        burstDecay=5
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:12
    
    if nargin < 12 or isempty(burstFreq):
        burstFreq=13
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:13
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:15
    S=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:16
    f=base + dot(slope,x)
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:17
    f=f + dot(stepAmp,S(x,stepC1,stepW1)) - dot(stepAmp2,S(x,stepC2,stepW2))
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:18
    u=max(x - stepC1,0)
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:19
    f=f + multiply(multiply(multiply((x >= stepC1),burstAmp),exp(dot(- burstDecay,u))),sin(dot(dot(dot(2,pi),burstFreq),u)))
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:21
    meta.ID = copy('TF120')
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:22
    meta.Name = copy('Inference Queue Collapse')
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:23
    meta.Category = copy(6)
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:25
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:26
    meta.Morphology = copy('Queue buildup with oscillatory decay')
# /tmp/mfuncs/TF120_InferenceQueueCollapse.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    