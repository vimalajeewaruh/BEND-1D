# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF199_NetworkCongestionBurst(N=None,loadBase=None,burstAmp=None,*args,**kwargs):
    varargin = TF199_NetworkCongestionBurst.varargin
    nargin = TF199_NetworkCongestionBurst.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:2
    
    if nargin < 2 or isempty(loadBase):
        loadBase=0.15
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:3
    
    if nargin < 3 or isempty(burstAmp):
        burstAmp=0.17
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:4
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:5
    loadCurve=loadBase + dot(0.78,S(x,0.22,0.065)) - dot(0.62,S(x,0.82,0.035))
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:6
    gate=S(x,0.46,0.01) - S(x,0.78,0.01)
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:7
    q=dot(18,(x - 0.46))
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:8
    saw=dot(2,(q - floor(q))) - 1
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:9
    f=loadCurve + multiply(dot(burstAmp,gate),saw)
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:10
    meta=copy(struct)
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:11
    meta.ID = copy('TF199')
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:12
    meta.Name = copy('Network Congestion Burst')
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:13
    meta.Category = copy(10)
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:14
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:15
    meta.Parameters = copy(struct('loadBase',loadBase,'burstAmp',burstAmp))
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:16
    meta.Morphology = copy('Load curve with gated sawtooth bursts')
# /tmp/mfuncs/TF199_NetworkCongestionBurst.m:17
    return x,f,meta
    
if __name__ == '__main__':
    pass
    