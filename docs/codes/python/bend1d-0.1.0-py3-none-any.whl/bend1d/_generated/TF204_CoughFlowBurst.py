# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF204_CoughFlowBurst(N=None,c=None,a=None,tau=None,p=None,*args,**kwargs):
    varargin = TF204_CoughFlowBurst.varargin
    nargin = TF204_CoughFlowBurst.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF204_CoughFlowBurst.m:2
    
    if nargin < 2 or isempty(c):
        c=concat([0.28,0.405,0.53])
# /tmp/mfuncs/TF204_CoughFlowBurst.m:3
    
    if nargin < 3 or isempty(a):
        a=concat([1.0,0.48,0.32])
# /tmp/mfuncs/TF204_CoughFlowBurst.m:4
    
    if nargin < 4 or isempty(tau):
        tau=concat([0.035,0.027,0.045])
# /tmp/mfuncs/TF204_CoughFlowBurst.m:5
    
    if nargin < 5 or isempty(p):
        p=concat([1.2,1.4,1.1])
# /tmp/mfuncs/TF204_CoughFlowBurst.m:6
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF204_CoughFlowBurst.m:7
    f=zeros(size(x))
# /tmp/mfuncs/TF204_CoughFlowBurst.m:8
    for k in arange(1,numel(c)).reshape(-1):
        uk=max(x - c(k),0)
# /tmp/mfuncs/TF204_CoughFlowBurst.m:10
        resp=multiply(multiply((x >= c(k)),(uk / tau(k)) ** p(k)),exp(p(k) - uk / tau(k)))
# /tmp/mfuncs/TF204_CoughFlowBurst.m:11
        f=f + dot(a(k),resp)
# /tmp/mfuncs/TF204_CoughFlowBurst.m:12
    
    f=multiply(f,(1 + dot(0.08,sin(dot(dot(dot(2,pi),23),x)))))
# /tmp/mfuncs/TF204_CoughFlowBurst.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF204_CoughFlowBurst.m:15
    meta.ID = copy('TF204')
# /tmp/mfuncs/TF204_CoughFlowBurst.m:16
    meta.Name = copy('Cough Flow Burst')
# /tmp/mfuncs/TF204_CoughFlowBurst.m:17
    meta.Category = copy(10)
# /tmp/mfuncs/TF204_CoughFlowBurst.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF204_CoughFlowBurst.m:19
    meta.Parameters = copy(struct('c',c,'a',a,'tau',tau,'p',p))
# /tmp/mfuncs/TF204_CoughFlowBurst.m:20
    meta.Morphology = copy('Burst-like respiratory flows with modulation')
# /tmp/mfuncs/TF204_CoughFlowBurst.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    