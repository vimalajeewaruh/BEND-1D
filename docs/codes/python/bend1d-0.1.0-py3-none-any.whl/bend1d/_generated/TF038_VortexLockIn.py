# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF038_VortexLockIn(N=None,freqVL=None,envVL=None,*args,**kwargs):
    varargin = TF038_VortexLockIn.varargin
    nargin = TF038_VortexLockIn.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF038_VortexLockIn.m:2
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF038_VortexLockIn.m:3
    if nargin < 2 or isempty(freqVL):
        freqVL=7 + dot(20,min(x,0.55))
# /tmp/mfuncs/TF038_VortexLockIn.m:5
        freqVL[x > 0.55]=18
# /tmp/mfuncs/TF038_VortexLockIn.m:6
    else:
        if isscalar(freqVL):
            freqVL=repmat(freqVL,size(x))
# /tmp/mfuncs/TF038_VortexLockIn.m:8
        else:
            freqVL=interp1(linspace(0,1,numel(freqVL)),freqVL,x,'linear',freqVL(end()))
# /tmp/mfuncs/TF038_VortexLockIn.m:10
    
    if nargin < 3 or isempty(envVL):
        envVL=0.16 + 0.84 / (1 + exp(dot(- 28,(x - 0.33))))
# /tmp/mfuncs/TF038_VortexLockIn.m:13
    else:
        if isscalar(envVL):
            envVL=repmat(envVL,size(x))
# /tmp/mfuncs/TF038_VortexLockIn.m:15
        else:
            envVL=interp1(linspace(0,1,numel(envVL)),envVL,x,'linear',envVL(end()))
# /tmp/mfuncs/TF038_VortexLockIn.m:17
    
    phaseVL=dot(dot(2,pi),cumtrapz(x,freqVL))
# /tmp/mfuncs/TF038_VortexLockIn.m:19
    f=multiply(envVL,(sin(phaseVL) + dot(0.16,sin(dot(2,phaseVL) - 0.4))))
# /tmp/mfuncs/TF038_VortexLockIn.m:20
    meta=copy(struct)
# /tmp/mfuncs/TF038_VortexLockIn.m:21
    meta.ID = copy('TF038')
# /tmp/mfuncs/TF038_VortexLockIn.m:22
    meta.Name = copy('Vortex Lock-In')
# /tmp/mfuncs/TF038_VortexLockIn.m:23
    meta.Category = copy(3)
# /tmp/mfuncs/TF038_VortexLockIn.m:24
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF038_VortexLockIn.m:25
    meta.Parameters = copy(struct('freqVL',freqVL,'envVL',envVL))
# /tmp/mfuncs/TF038_VortexLockIn.m:26
    meta.Morphology = copy('Frequency rise then lock-in with growing amplitude')
# /tmp/mfuncs/TF038_VortexLockIn.m:27
    return x,f,meta
    
if __name__ == '__main__':
    pass
    