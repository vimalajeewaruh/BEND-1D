# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF032_TremorOnset(N=None,onsetSlope=None,center=None,ampModFreq=None,*args,**kwargs):
    varargin = TF032_TremorOnset.varargin
    nargin = TF032_TremorOnset.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF032_TremorOnset.m:2
    
    if nargin < 2 or isempty(onsetSlope):
        onsetSlope=75
# /tmp/mfuncs/TF032_TremorOnset.m:3
    
    if nargin < 3 or isempty(center):
        center=0.42
# /tmp/mfuncs/TF032_TremorOnset.m:4
    
    if nargin < 4 or isempty(ampModFreq):
        ampModFreq=1.25
# /tmp/mfuncs/TF032_TremorOnset.m:5
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF032_TremorOnset.m:6
    envTremor=1.0 / (1 + exp(dot(- onsetSlope,(x - center))))
# /tmp/mfuncs/TF032_TremorOnset.m:7
    ampTremor=0.78 + dot(0.15,sin(dot(dot(dot(2,pi),ampModFreq),x)))
# /tmp/mfuncs/TF032_TremorOnset.m:8
    f=dot(0.025,sin(dot(dot(dot(2,pi),3),x))) + multiply(multiply(envTremor,ampTremor),(sin(dot(dot(dot(2,pi),18),x)) + dot(0.24,sin(dot(dot(dot(2,pi),36),x) + 0.65))))
# /tmp/mfuncs/TF032_TremorOnset.m:9
    meta=copy(struct)
# /tmp/mfuncs/TF032_TremorOnset.m:10
    meta.ID = copy('TF032')
# /tmp/mfuncs/TF032_TremorOnset.m:11
    meta.Name = copy('Tremor Onset')
# /tmp/mfuncs/TF032_TremorOnset.m:12
    meta.Category = copy(3)
# /tmp/mfuncs/TF032_TremorOnset.m:13
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF032_TremorOnset.m:14
    meta.Parameters = copy(struct('onsetSlope',onsetSlope,'center',center,'ampModFreq',ampModFreq))
# /tmp/mfuncs/TF032_TremorOnset.m:15
    meta.Morphology = copy('Onset of sustained amplitude-modulated tremor with a weak harmonic')
# /tmp/mfuncs/TF032_TremorOnset.m:16
    return x,f,meta
    
if __name__ == '__main__':
    pass
    