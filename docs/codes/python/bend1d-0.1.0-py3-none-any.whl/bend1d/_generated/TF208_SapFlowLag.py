# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF208_SapFlowLag(N=None,base=None,c=None,a=None,tr=None,td=None,lfAmp=None,lfFreq=None,phase=None,*args,**kwargs):
    varargin = TF208_SapFlowLag.varargin
    nargin = TF208_SapFlowLag.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF208_SapFlowLag.m:2
    
    if nargin < 2 or isempty(base):
        base=0.12
# /tmp/mfuncs/TF208_SapFlowLag.m:3
    
    if nargin < 3 or isempty(c):
        c=concat([0.08,0.57])
# /tmp/mfuncs/TF208_SapFlowLag.m:4
    
    if nargin < 4 or isempty(a):
        a=concat([0.78,0.7])
# /tmp/mfuncs/TF208_SapFlowLag.m:5
    
    if nargin < 5 or isempty(tr):
        tr=concat([0.04,0.05])
# /tmp/mfuncs/TF208_SapFlowLag.m:6
    
    if nargin < 6 or isempty(td):
        td=concat([0.17,0.19])
# /tmp/mfuncs/TF208_SapFlowLag.m:7
    
    if nargin < 7 or isempty(lfAmp):
        lfAmp=0.03
# /tmp/mfuncs/TF208_SapFlowLag.m:8
    
    if nargin < 8 or isempty(lfFreq):
        lfFreq=2
# /tmp/mfuncs/TF208_SapFlowLag.m:9
    
    if nargin < 9 or isempty(phase):
        phase=- 0.4
# /tmp/mfuncs/TF208_SapFlowLag.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF208_SapFlowLag.m:11
    f=dot(base,ones(size(x)))
# /tmp/mfuncs/TF208_SapFlowLag.m:12
    for k in arange(1,numel(c)).reshape(-1):
        uk=max(x - c(k),0)
# /tmp/mfuncs/TF208_SapFlowLag.m:14
        f=f + multiply(multiply(multiply((x >= c(k)),a(k)),(1 - exp(- uk / tr(k)))),exp(- uk / td(k)))
# /tmp/mfuncs/TF208_SapFlowLag.m:15
    
    f=f + dot(lfAmp,sin(dot(dot(dot(2,pi),lfFreq),x) + phase))
# /tmp/mfuncs/TF208_SapFlowLag.m:17
    meta=copy(struct)
# /tmp/mfuncs/TF208_SapFlowLag.m:18
    meta.ID = copy('TF208')
# /tmp/mfuncs/TF208_SapFlowLag.m:19
    meta.Name = copy('Sap Flow Lag')
# /tmp/mfuncs/TF208_SapFlowLag.m:20
    meta.Category = copy(10)
# /tmp/mfuncs/TF208_SapFlowLag.m:21
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF208_SapFlowLag.m:22
    meta.Parameters = copy(struct('base',base,'c',c,'a',a,'tr',tr,'td',td,'lfAmp',lfAmp,'lfFreq',lfFreq,'phase',phase))
# /tmp/mfuncs/TF208_SapFlowLag.m:23
    meta.Morphology = copy('Delayed rise with slow decay and low-frequency modulation')
# /tmp/mfuncs/TF208_SapFlowLag.m:24
    return x,f,meta
    
if __name__ == '__main__':
    pass
    