# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF098_TurbiditeSequence(N=None,baselineSlope=None,baselineIntercept=None,baselineOscAmp=None,c=None,c_a=None,tau=None,*args,**kwargs):
    varargin = TF098_TurbiditeSequence.varargin
    nargin = TF098_TurbiditeSequence.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF098_TurbiditeSequence.m:2
    
    if nargin < 2 or isempty(baselineSlope):
        baselineSlope=0.12
# /tmp/mfuncs/TF098_TurbiditeSequence.m:3
    
    if nargin < 3 or isempty(baselineIntercept):
        baselineIntercept=0.3
# /tmp/mfuncs/TF098_TurbiditeSequence.m:4
    
    if nargin < 4 or isempty(baselineOscAmp):
        baselineOscAmp=0.035
# /tmp/mfuncs/TF098_TurbiditeSequence.m:5
    
    if nargin < 5 or isempty(c):
        c=concat([0.15,0.31,0.48,0.64,0.79,0.9])
# /tmp/mfuncs/TF098_TurbiditeSequence.m:6
    
    if nargin < 6 or isempty(c_a):
        c_a=concat([0.28,0.42,0.22,0.5,0.35,0.2])
# /tmp/mfuncs/TF098_TurbiditeSequence.m:7
    
    if nargin < 7 or isempty(tau):
        tau=concat([0.045,0.065,0.03,0.075,0.05,0.028])
# /tmp/mfuncs/TF098_TurbiditeSequence.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF098_TurbiditeSequence.m:10
    f=baselineIntercept + dot(baselineSlope,x) + dot(baselineOscAmp,sin(dot(dot(dot(2,pi),3),x)))
# /tmp/mfuncs/TF098_TurbiditeSequence.m:11
    for k in arange(1,numel(c)).reshape(-1):
        u=max(x - c(k),0)
# /tmp/mfuncs/TF098_TurbiditeSequence.m:13
        event=multiply(dot(c_a(k),(x >= c(k))),exp(- u / tau(k)))
# /tmp/mfuncs/TF098_TurbiditeSequence.m:14
        f=f + event
# /tmp/mfuncs/TF098_TurbiditeSequence.m:15
    
    meta=copy(struct)
# /tmp/mfuncs/TF098_TurbiditeSequence.m:17
    meta.ID = copy('TF098')
# /tmp/mfuncs/TF098_TurbiditeSequence.m:18
    meta.Name = copy('Turbidite Sequence')
# /tmp/mfuncs/TF098_TurbiditeSequence.m:19
    meta.Category = copy(6)
# /tmp/mfuncs/TF098_TurbiditeSequence.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF098_TurbiditeSequence.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF098_TurbiditeSequence.m:22
    meta.Morphology = copy('Baseline trend with episodic turbidite events')
# /tmp/mfuncs/TF098_TurbiditeSequence.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    