# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF091_InventoryStockout(N=None,baseSlope=None,baseIntercept=None,baseAmp=None,stockC1=None,stockW1=None,stockLevelBase=None,stockLevelAmp=None,adjAmp1=None,adjC1=None,adjW1=None,adjAmp2=None,adjC2=None,adjW2=None,*args,**kwargs):
    varargin = TF091_InventoryStockout.varargin
    nargin = TF091_InventoryStockout.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF091_InventoryStockout.m:2
    
    if nargin < 2 or isempty(baseSlope):
        baseSlope=0.34
# /tmp/mfuncs/TF091_InventoryStockout.m:3
    
    if nargin < 3 or isempty(baseIntercept):
        baseIntercept=0.26
# /tmp/mfuncs/TF091_InventoryStockout.m:4
    
    if nargin < 4 or isempty(baseAmp):
        baseAmp=0.035
# /tmp/mfuncs/TF091_InventoryStockout.m:5
    
    if nargin < 5 or isempty(stockC1):
        stockC1=0.42
# /tmp/mfuncs/TF091_InventoryStockout.m:6
    
    if nargin < 6 or isempty(stockW1):
        stockW1=0.006
# /tmp/mfuncs/TF091_InventoryStockout.m:7
    
    if nargin < 7 or isempty(stockLevelBase):
        stockLevelBase=0.18
# /tmp/mfuncs/TF091_InventoryStockout.m:8
    
    if nargin < 8 or isempty(stockLevelAmp):
        stockLevelAmp=0.01
# /tmp/mfuncs/TF091_InventoryStockout.m:9
    
    if nargin < 9 or isempty(adjAmp1):
        adjAmp1=0.2
# /tmp/mfuncs/TF091_InventoryStockout.m:10
    
    if nargin < 10 or isempty(adjC1):
        adjC1=0.61
# /tmp/mfuncs/TF091_InventoryStockout.m:11
    
    if nargin < 11 or isempty(adjW1):
        adjW1=0.005
# /tmp/mfuncs/TF091_InventoryStockout.m:12
    
    if nargin < 12 or isempty(adjAmp2):
        adjAmp2=- 0.13
# /tmp/mfuncs/TF091_InventoryStockout.m:13
    
    if nargin < 13 or isempty(adjC2):
        adjC2=0.72
# /tmp/mfuncs/TF091_InventoryStockout.m:14
    
    if nargin < 14 or isempty(adjW2):
        adjW2=0.04
# /tmp/mfuncs/TF091_InventoryStockout.m:15
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF091_InventoryStockout.m:17
    sigmoid=lambda z=None,c=None,w=None: 1.0 / (1 + exp(- (z - c) / w))
# /tmp/mfuncs/TF091_InventoryStockout.m:18
    baseIS=baseIntercept + dot(baseSlope,x) + dot(baseAmp,sin(dot(dot(dot(2,pi),4),x)))
# /tmp/mfuncs/TF091_InventoryStockout.m:19
    stockWin=sigmoid(x,stockC1,stockW1) - sigmoid(x,stockC1 + 0.19,stockW1)
# /tmp/mfuncs/TF091_InventoryStockout.m:20
    
    stockLevel=stockLevelBase + dot(stockLevelAmp,sin(dot(dot(dot(2,pi),13),x)))
# /tmp/mfuncs/TF091_InventoryStockout.m:21
    f=multiply(baseIS,(1 - stockWin)) + multiply(stockLevel,stockWin)
# /tmp/mfuncs/TF091_InventoryStockout.m:22
    f=f + dot(adjAmp1,sigmoid(x,adjC1,adjW1)) + dot(adjAmp2,sigmoid(x,adjC2,adjW2))
# /tmp/mfuncs/TF091_InventoryStockout.m:23
    meta=copy(struct)
# /tmp/mfuncs/TF091_InventoryStockout.m:24
    meta.ID = copy('TF091')
# /tmp/mfuncs/TF091_InventoryStockout.m:25
    meta.Name = copy('Inventory Stockout')
# /tmp/mfuncs/TF091_InventoryStockout.m:26
    meta.Category = copy(6)
# /tmp/mfuncs/TF091_InventoryStockout.m:27
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF091_InventoryStockout.m:28
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF091_InventoryStockout.m:29
    meta.Morphology = copy('Baseline with stockout window and level adjustments')
# /tmp/mfuncs/TF091_InventoryStockout.m:30
    return x,f,meta
    
if __name__ == '__main__':
    pass
    