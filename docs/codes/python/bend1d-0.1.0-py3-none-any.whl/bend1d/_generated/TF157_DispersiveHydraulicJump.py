# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF157_DispersiveHydraulicJump(N=None,stepCtr=None,stepWidth=None,baseA=None,linA=None,stepA=None,oscA=None,oscDecay=None,oscPhase=None,*args,**kwargs):
    varargin = TF157_DispersiveHydraulicJump.varargin
    nargin = TF157_DispersiveHydraulicJump.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:2
    
    if nargin < 2 or isempty(stepCtr):
        stepCtr=0.34
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:3
    
    if nargin < 3 or isempty(stepWidth):
        stepWidth=0.006
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:4
    
    if nargin < 4 or isempty(baseA):
        baseA=0.12
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:5
    
    if nargin < 5 or isempty(linA):
        linA=0.07
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:6
    
    if nargin < 6 or isempty(stepA):
        stepA=0.64
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:7
    
    if nargin < 7 or isempty(oscA):
        oscA=0.22
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:8
    
    if nargin < 8 or isempty(oscDecay):
        oscDecay=7.5
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:9
    
    if nargin < 9 or isempty(oscPhase):
        oscPhase=0
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:10
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:11
    uDH=max(x - stepCtr,0)
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:12
    f=baseA + dot(linA,x) + dot(stepA,S(x,stepCtr,stepWidth))
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:13
    f=f + multiply(multiply(multiply((x >= stepCtr),oscA),exp(dot(- oscDecay,uDH))),sin(dot(dot(2,pi),(dot(17,uDH) + dot(12,uDH ** 2))) + oscPhase))
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:14
    meta=copy(struct)
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:15
    meta.ID = copy('TF157')
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:16
    meta.Name = copy('Dispersive Hydraulic Jump')
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:17
    meta.Category = copy(9)
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:18
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:19
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:20
    meta.Morphology = copy('Step with decaying oscillatory wake')
# /tmp/mfuncs/TF157_DispersiveHydraulicJump.m:21
    return x,f,meta
    
if __name__ == '__main__':
    pass
    