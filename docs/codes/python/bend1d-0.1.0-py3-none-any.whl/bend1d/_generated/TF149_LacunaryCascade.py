# Generated with SMOP  0.41
from .._runtime import *
# 

    
@function
def TF149_LacunaryCascade(N=None,cLC=None,baseAmp=None,ampDecay=None,baseWid=None,widDecay=None,baseline=None,*args,**kwargs):
    varargin = TF149_LacunaryCascade.varargin
    nargin = TF149_LacunaryCascade.nargin

    if nargin < 1 or isempty(N):
        N=1024
# /tmp/mfuncs/TF149_LacunaryCascade.m:2
    
    if nargin < 2 or isempty(cLC):
        cLC=concat([0.18,0.37,0.52,0.63,0.71,0.77,0.815,0.848,0.872,0.89])
# /tmp/mfuncs/TF149_LacunaryCascade.m:3
    
    if nargin < 3 or isempty(baseAmp):
        baseAmp=0.3
# /tmp/mfuncs/TF149_LacunaryCascade.m:4
    
    if nargin < 4 or isempty(ampDecay):
        ampDecay=0.87
# /tmp/mfuncs/TF149_LacunaryCascade.m:5
    
    if nargin < 5 or isempty(baseWid):
        baseWid=0.025
# /tmp/mfuncs/TF149_LacunaryCascade.m:6
    
    if nargin < 6 or isempty(widDecay):
        widDecay=0.7
# /tmp/mfuncs/TF149_LacunaryCascade.m:7
    
    if nargin < 7 or isempty(baseline):
        baseline=0.02
# /tmp/mfuncs/TF149_LacunaryCascade.m:8
    
    x=linspace(0,1,N).T
# /tmp/mfuncs/TF149_LacunaryCascade.m:10
    f=dot(baseline,ones(size(x)))
# /tmp/mfuncs/TF149_LacunaryCascade.m:11
    for k in arange(1,numel(cLC)).reshape(-1):
        amp=dot(baseAmp,(ampDecay ** (k - 1)))
# /tmp/mfuncs/TF149_LacunaryCascade.m:13
        wid=dot(baseWid,(widDecay ** (k - 1)))
# /tmp/mfuncs/TF149_LacunaryCascade.m:14
        f=f + dot(dot(amp,(- 1) ** (k + 1)),exp(dot(- 0.5,((x - cLC(k)) / wid) ** 2)))
# /tmp/mfuncs/TF149_LacunaryCascade.m:15
    
    meta=copy(struct)
# /tmp/mfuncs/TF149_LacunaryCascade.m:17
    meta.ID = copy('TF149')
# /tmp/mfuncs/TF149_LacunaryCascade.m:18
    meta.Name = copy('Lacunary Cascade')
# /tmp/mfuncs/TF149_LacunaryCascade.m:19
    meta.Category = copy(9)
# /tmp/mfuncs/TF149_LacunaryCascade.m:20
    meta.RecommendedN = copy(1024)
# /tmp/mfuncs/TF149_LacunaryCascade.m:21
    meta.Parameters = copy(struct)
# /tmp/mfuncs/TF149_LacunaryCascade.m:22
    meta.Morphology = copy('Cascade of alternating-signed Gaussians with geometrically changing scale')
# /tmp/mfuncs/TF149_LacunaryCascade.m:23
    return x,f,meta
    
if __name__ == '__main__':
    pass
    