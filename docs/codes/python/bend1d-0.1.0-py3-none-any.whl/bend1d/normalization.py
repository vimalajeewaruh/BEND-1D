"""Signal-to-noise-ratio normalization."""

from __future__ import annotations

import numpy as np


def normalize_snr(f, sigma, target_snr, units="linear"):
    """Rescale the centered component of *f* to a target SNR.

    The mean is preserved. ``units`` may be ``"linear"`` or ``"db"``.
    Returns ``(scaled_signal, details)``.
    """
    values = np.asarray(f, dtype=float)
    if values.ndim != 1 or values.size < 2 or not np.all(np.isfinite(values)):
        raise ValueError("f must be a finite one-dimensional array with at least two values")
    if not np.isscalar(sigma) or not np.isfinite(sigma) or sigma <= 0:
        raise ValueError("sigma must be a positive finite scalar")
    if not np.isscalar(target_snr) or not np.isfinite(target_snr):
        raise ValueError("target_snr must be a finite scalar")

    units = str(units).strip().lower()
    if units in {"linear", "lin"}:
        linear_snr = float(target_snr)
        if linear_snr <= 0:
            raise ValueError("a linear target_snr must be positive")
    elif units in {"db", "decibel", "decibels"}:
        linear_snr = 10.0 ** (float(target_snr) / 10.0)
    else:
        raise ValueError("units must be 'linear' or 'db'")

    signal_mean = float(np.mean(values))
    centered = values - signal_mean
    original_power = float(np.mean(centered**2))
    if original_power <= 0:
        raise ValueError("f must not be constant")
    target_power = linear_snr * float(sigma) ** 2
    scale_factor = np.sqrt(target_power / original_power)
    scaled = signal_mean + scale_factor * centered
    details = {
        "sigma": float(sigma),
        "target_snr": float(target_snr),
        "snr_units": units,
        "linear_snr": linear_snr,
        "original_mean": signal_mean,
        "original_centered_power": original_power,
        "target_centered_power": target_power,
        "scale_factor": float(scale_factor),
        "achieved_centered_power": float(np.mean((scaled - np.mean(scaled)) ** 2)),
    }
    return scaled, details
