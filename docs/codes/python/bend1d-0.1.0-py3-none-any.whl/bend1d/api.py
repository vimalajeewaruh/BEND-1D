"""Public catalog and signal-generation API."""

from __future__ import annotations

import importlib
import re
from functools import lru_cache

import numpy as np
import pandas as pd

from ._catalog_data import CATALOG_ROWS

_COLUMNS = ["ID", "Name", "Category", "RecommendedN"]


def _normalize_name(value):
    return re.sub(r"[\s_-]+", "", str(value).strip()).upper()


@lru_cache(maxsize=1)
def _records():
    return tuple(dict(zip(_COLUMNS, row)) for row in CATALOG_ROWS)


def list_signals(category=None):
    """Return the catalog as a pandas DataFrame, optionally filtered by category."""
    frame = pd.DataFrame(_records(), columns=_COLUMNS)
    if category is None:
        return frame
    if isinstance(category, bool) or not isinstance(category, (int, np.integer)):
        raise ValueError("category must be an integer")
    result = frame.loc[frame["Category"] == int(category)].reset_index(drop=True)
    if result.empty:
        raise ValueError(f"Unknown or empty category: {category}")
    return result


def _find_record(signal):
    key = _normalize_name(signal)
    matches = []
    for record in _records():
        full_name = record["ID"] + record["Name"]
        if key in {
            _normalize_name(record["ID"]),
            _normalize_name(record["Name"]),
            _normalize_name(full_name),
        }:
            matches.append(record)
    if not matches:
        raise ValueError(f"Unknown signal identifier or name: {signal}")
    if len(matches) > 1:
        ids = ", ".join(record["ID"] for record in matches)
        raise ValueError(f"Ambiguous signal name {signal!r}; matching IDs: {ids}")
    return matches[0]


def info(signal):
    """Return one authoritative catalog record as a dictionary."""
    return dict(_find_record(signal))


@lru_cache(maxsize=None)
def _implementation(signal_id):
    number = int(signal_id[2:])
    # Each generated filename begins with the unique catalog identifier.
    from pathlib import Path

    folder = Path(__file__).with_name("_generated")
    matches = list(folder.glob(f"{signal_id}_*.py"))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one implementation for {signal_id}, found {len(matches)}")
    module_name = f"{__package__}._generated.{matches[0].stem}"
    module = importlib.import_module(module_name)
    return getattr(module, matches[0].stem)


def _plain(value):
    if hasattr(value, "__dict__"):
        return {key: _plain(item) for key, item in vars(value).items()}
    if isinstance(value, np.ndarray):
        array = np.asarray(value)
        if array.size == 1:
            return _plain(array.reshape(-1)[0])
        return array.reshape(-1, order="F").tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def generate(signal, n=None, *parameters):
    """Generate a BEND-1D signal.

    Parameters after ``n`` are forwarded positionally to the signal-specific
    equation, matching the MATLAB implementation.
    """
    record = _find_record(signal)
    if n is None:
        n = record["RecommendedN"]
    if isinstance(n, bool) or not isinstance(n, (int, np.integer)) or n < 2:
        raise ValueError("n must be an integer greater than or equal to 2")
    implementation = _implementation(record["ID"])
    x, f, raw_metadata = implementation(int(n), *parameters)
    x = np.asarray(x, dtype=float).reshape(-1, order="F")
    f = np.asarray(f, dtype=float).reshape(-1, order="F")
    metadata = _plain(raw_metadata)
    if not isinstance(metadata, dict):
        metadata = {}
    metadata.update(record)
    return x, f, metadata
