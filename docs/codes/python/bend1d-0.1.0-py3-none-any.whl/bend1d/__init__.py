"""BEND-1D benchmark signals for Python."""

from .api import generate, info, list_signals
from .normalization import normalize_snr

__all__ = ["generate", "info", "list_signals", "normalize_snr"]
__version__ = "0.1.0"
