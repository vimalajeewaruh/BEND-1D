import bend1d

x, f, metadata = bend1d.generate("TF001", 1024)

print(metadata)