import numpy as np
import pytest

import bend1d


def test_catalog_has_230_signals():
    table = bend1d.list_signals()
    assert len(table) == 230
    assert table.iloc[0]["ID"] == "TF001"
    assert table.iloc[-1]["ID"] == "TF230"


def test_generate_by_id_and_name_agree():
    x1, f1, m1 = bend1d.generate("TF001", 128)
    x2, f2, m2 = bend1d.generate("Percolation", 128)
    np.testing.assert_allclose(x1, x2)
    np.testing.assert_allclose(f1, f2)
    assert m1 == m2


def test_normalize_snr():
    _, f, _ = bend1d.generate("TF001", 128)
    scaled, details = bend1d.normalize_snr(f, 0.2, 5)
    assert np.mean((scaled - scaled.mean()) ** 2) == pytest.approx(5 * 0.2**2)
    assert details["linear_snr"] == 5


def test_unknown_signal():
    with pytest.raises(ValueError, match="Unknown signal"):
        bend1d.generate("not-a-signal")
