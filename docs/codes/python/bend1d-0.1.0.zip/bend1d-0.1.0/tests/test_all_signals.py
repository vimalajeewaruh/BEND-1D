import numpy as np

import bend1d


def test_every_catalog_signal_has_valid_default_output():
    """Python counterpart of MATLAB's category integration test."""
    for row in bend1d.list_signals().itertuples(index=False):
        x, f, metadata = bend1d.generate(row.ID)
        n = row.RecommendedN

        assert x.shape == (n,), row.ID
        assert f.shape == (n,), row.ID
        assert np.isrealobj(x) and np.isrealobj(f), row.ID
        assert np.all(np.isfinite(x)) and np.all(np.isfinite(f)), row.ID
        assert x[0] == 0 and x[-1] == 1, row.ID
        assert np.all(np.diff(x) > 0), row.ID
        assert np.ptp(f) > 0, row.ID
        assert metadata["ID"] == row.ID
        assert metadata["Name"] == row.Name
        assert metadata["Category"] == row.Category
